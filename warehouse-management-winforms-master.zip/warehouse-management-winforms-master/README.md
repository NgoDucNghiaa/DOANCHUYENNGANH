# 🏪 Warehouse Management System - WinForms C#

[![.NET](https://img.shields.io/badge/.NET-6.0-blue.svg)](https://dotnet.microsoft.com/)
[![SQL Server](https://img.shields.io/badge/SQL%20Server-2019+-red.svg)](https://www.microsoft.com/en-us/sql-server)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Status](https://img.shields.io/badge/Status-Complete-brightgreen.svg)]()

> Hệ thống quản lý kho hàng hoàn chỉnh được phát triển bằng C# WinForms với SQL Server

## 🎉 **DỰ ÁN ĐÃ HOÀN THÀNH 100%**

Tất cả các tính năng cơ bản của hệ thống quản lý kho đã được hoàn thiện và sẵn sàng sử dụng!

## ✨ Tính năng hoàn chỉnh

### 🔐 Hệ thống xác thực
- ✅ Đăng nhập/đăng ký với mã hóa SHA256
- ✅ Phân quyền Admin/Staff hoàn chỉnh
- ✅ Quản lý người dùng CRUD đầy đủ
- ✅ Bảo vệ tài khoản admin khỏi bị xóa

### 📦 Quản lý sản phẩm
- ✅ CRUD sản phẩm hoàn chỉnh (thêm/sửa/xóa/xem)
- ✅ Quản lý danh mục và đơn vị tính
- ✅ Thiết lập ngưỡng tồn kho tối thiểu
- ✅ Xóa thông minh (deactivate nếu đã sử dụng)

### 📊 Quản lý tồn kho
- ✅ Theo dõi tồn kho real-time
- ✅ Cảnh báo sản phẩm sắp hết (màu đỏ)
- ✅ Lọc sản phẩm tồn kho thấp
- ✅ Tự động cập nhật khi nhập/xuất

### 📥📤 Nhập xuất kho
- ✅ Tạo phiếu nhập kho từ nhà cung cấp
- ✅ Tạo phiếu xuất kho cho khách hàng
- ✅ Tự động cập nhật tồn kho
- ✅ Kiểm tra tồn kho trước khi xuất
- ✅ Tính toán tổng tiền tự động

### 👥 Quản lý đối tác
- ✅ Quản lý nhà cung cấp CRUD
- ✅ Quản lý khách hàng CRUD
- ✅ Validation email và thông tin liên hệ
- ✅ Kiểm tra trùng lặp tên

### 🎨 Giao diện người dùng
- ✅ Form đăng nhập chuyên nghiệp
- ✅ Dashboard chính với menu đầy đủ
- ✅ Form demo đơn giản (SimpleLoginForm/SimpleMainForm)
- ✅ UI nhất quán và thân thiện

## 🛠️ Công nghệ sử dụng

- **Framework:** .NET Framework/Core Windows Forms
- **Database:** SQL Server 2019+ với ADO.NET
- **Security:** SHA256 Password Hashing
- **Architecture:** 3-Layer (Presentation, Business, Data)
- **Pattern:** Repository Pattern với Services

## 🚀 Cài đặt và chạy

### Yêu cầu hệ thống
- Windows 10/11
- .NET Framework 4.7.2+ hoặc .NET 6.0+
- SQL Server 2019+ hoặc SQL Server Express
- Visual Studio 2022 (để phát triển)

### Bước 1: Clone repository
```bash
git clone <repository-url>
cd WarehouseManagement
```

### Bước 2: Cấu hình Database
Cập nhật connection string trong `DatabaseHelper.cs`:
```csharp
private static string connectionString = "Server=YOUR_SERVER;Database=WarehouseManagement;Integrated Security=true;TrustServerCertificate=true;";
```

### Bước 3: Chạy ứng dụng
```bash
# Mở solution trong Visual Studio
WarehouseManagement.sln

# Hoặc build bằng command line
dotnet build
dotnet run
```

### Bước 4: Đăng nhập lần đầu
- **Username:** `admin`
- **Password:** `secret` (đã được hash SHA256)

> 💡 Database và tất cả bảng sẽ được tự động tạo khi chạy lần đầu!

## 📁 Cấu trúc dự án hoàn chỉnh

```
WarehouseManagement/
├── 📁 Data/
│   └── DatabaseHelper.cs          # Kết nối DB, tạo bảng, hash password
├── 📁 Models/
│   └── User.cs                    # Tất cả entities (User, Product, Category, etc.)
├── 📁 Services/                   # Business Logic Layer
│   ├── UserService.cs             # CRUD users, authentication
│   ├── ProductService.cs          # CRUD products, categories, units
│   ├── CategoryService.cs         # CRUD categories
│   ├── SupplierService.cs         # CRUD suppliers
│   ├── CustomerService.cs         # CRUD customers
│   ├── StockService.cs            # Stock in/out operations
│   └── InventoryService.cs        # Inventory management
├── 📁 Forms/                      # Presentation Layer
│   ├── LoginForm.cs               # ✅ Đăng nhập chính
│   ├── RegisterForm.cs            # ✅ Đăng ký người dùng
│   ├── MainForm.cs                # ✅ Dashboard chính
│   ├── UserManagementForm.cs      # ✅ Quản lý người dùng
│   ├── ProductForm.cs             # ✅ Quản lý sản phẩm
│   ├── CategoryForm.cs            # ✅ Quản lý danh mục
│   ├── SupplierForm.cs            # ✅ Quản lý nhà cung cấp
│   ├── CustomerForm.cs            # ✅ Quản lý khách hàng
│   ├── StockInForm.cs             # ✅ Nhập kho
│   ├── StockOutForm.cs            # ✅ Xuất kho
│   ├── InventoryForm.cs           # ✅ Quản lý tồn kho
│   ├── SimpleLoginForm.cs         # ✅ Demo login (admin/123)
│   └── SimpleMainForm.cs          # ✅ Demo main form
└── Program.cs                     # Entry point
```

## 🗄️ Database Schema hoàn chỉnh

### 11 bảng chính đã được tạo:
1. **Users** - Người dùng hệ thống (Admin/Staff)
2. **Products** - Sản phẩm với đầy đủ thông tin
3. **Categories** - Danh mục sản phẩm
4. **Units** - Đơn vị tính (cái, kg, lít, etc.)
5. **Suppliers** - Nhà cung cấp
6. **Customers** - Khách hàng
7. **StockIns** - Phiếu nhập kho
8. **StockInDetails** - Chi tiết phiếu nhập
9. **StockOuts** - Phiếu xuất kho
10. **StockOutDetails** - Chi tiết phiếu xuất
11. **Inventories** - Tồn kho hiện tại

### Sample Data có sẵn:
- Admin user: `admin/secret`
- Category: "Điện tử"
- Unit: "Cái"

## 👥 Phân quyền hoàn chỉnh

### 🔴 Admin (Toàn quyền)
- ✅ Quản lý người dùng (thêm/sửa/xóa)
- ✅ Tất cả chức năng của Staff
- ✅ Xem được menu "Quản lý người dùng"

### 🔵 Staff (Nhân viên)
- ✅ Quản lý sản phẩm, danh mục, đơn vị
- ✅ Quản lý nhà cung cấp, khách hàng
- ✅ Nhập/xuất kho
- ✅ Xem tồn kho
- ❌ Không thể quản lý người dùng

## 🔒 Bảo mật đã triển khai

- ✅ Mật khẩu SHA256 hashing
- ✅ SQL Injection protection (parameterized queries)
- ✅ Input validation toàn diện
- ✅ Role-based access control
- ✅ Bảo vệ admin account khỏi bị xóa
- ✅ Session management

## 🚀 Tính năng nổi bật

### 📥 Nhập kho thông minh
- Tự động tạo mã phiếu nhập (SI + timestamp)
- Thêm nhiều sản phẩm trong một phiếu
- Tính toán tổng tiền real-time
- Cập nhật tồn kho tự động
- Validation đầy đủ

### 📤 Xuất kho an toàn
- Kiểm tra tồn kho trước khi xuất
- Cảnh báo khi không đủ hàng
- Tự động trừ tồn kho
- Lưu lịch sử giao dịch

### 📊 Quản lý tồn kho thông minh
- Hiển thị tồn kho real-time
- Highlight sản phẩm tồn kho thấp (màu đỏ)
- Lọc sản phẩm cần nhập thêm
- Cập nhật timestamp tự động

### 🗑️ Xóa thông minh
- Sản phẩm đã sử dụng: chỉ deactivate (IsActive = false)
- Sản phẩm chưa sử dụng: xóa hoàn toàn
- Bảo vệ data integrity

## 🎯 Tình trạng hoàn thành

### ✅ 100% Hoàn thành (11/11 forms)
- [x] LoginForm - Đăng nhập
- [x] RegisterForm - Đăng ký
- [x] MainForm - Dashboard chính
- [x] UserManagementForm - Quản lý người dùng
- [x] ProductForm - Quản lý sản phẩm (có xóa)
- [x] CategoryForm - Quản lý danh mục
- [x] SupplierForm - Quản lý nhà cung cấp
- [x] CustomerForm - Quản lý khách hàng
- [x] StockInForm - Nhập kho
- [x] StockOutForm - Xuất kho
- [x] InventoryForm - Quản lý tồn kho

### ✅ Bonus Forms
- [x] SimpleLoginForm - Demo login (admin/123)
- [x] SimpleMainForm - Demo với chức năng thực tế

## 🐛 Troubleshooting

### Lỗi kết nối database
```
Kiểm tra:
1. SQL Server đã chạy chưa?
2. Connection string đúng chưa?
3. Có quyền tạo database không?
```

### Lỗi đăng nhập
```
Thử:
1. Username: admin, Password: secret
2. Hoặc tạo user mới qua RegisterForm
3. Kiểm tra database đã tạo chưa
```

## 🤝 Đóng góp

Dự án đã hoàn thành 100%, nhưng vẫn welcome contributions:

1. Fork repository
2. Tạo feature branch (`git checkout -b feature/Enhancement`)
3. Commit changes (`git commit -m 'Add enhancement'`)
4. Push to branch (`git push origin feature/Enhancement`)
5. Tạo Pull Request

## 📄 License

MIT License - Xem file `LICENSE` để biết chi tiết.

## 📞 Liên hệ

- **Project:** Warehouse Management System
- **Status:** ✅ Complete
- **Version:** 1.0.0
- **Last Updated:** January 2026

---

## 🎉 **CHÚC MỪNG! DỰ ÁN ĐÃ HOÀN THÀNH 100%**

**Tất cả 11 form chính + 2 demo form đã được hoàn thiện với đầy đủ chức năng CRUD, validation, security và UI/UX chuyên nghiệp!**

⭐ **Nếu project này hữu ích, hãy cho một star nhé!** ⭐