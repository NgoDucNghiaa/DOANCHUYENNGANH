# 🗄️ Hướng dẫn cài đặt SQL Server cho Warehouse Management

## 📋 Yêu cầu hệ thống
- Windows 10/11
- .NET 6.0 hoặc cao hơn
- SQL Server 2019 Express hoặc cao hơn

## 🚀 Bước 1: Cài đặt SQL Server Express (MIỄN PHÍ)

### Tải SQL Server Express:
1. Truy cập: https://www.microsoft.com/en-us/sql-server/sql-server-downloads
2. Chọn **"Download now"** ở mục **SQL Server 2022 Express**
3. Chạy file `SQL2022-SSEI-Expr.exe`

### Cài đặt:
1. Chọn **"Basic"** installation
2. Chấp nhận license terms
3. Chọn thư mục cài đặt (mặc định OK)
4. Đợi quá trình cài đặt hoàn tất
5. **Ghi nhớ Instance name:** `SQLEXPRESS`

## 🔧 Bước 2: Cài đặt SQL Server Management Studio (SSMS)

### Tải SSMS:
1. Truy cập: https://docs.microsoft.com/en-us/sql/ssms/download-sql-server-management-studio-ssms
2. Tải **SSMS-Setup-ENU.exe**
3. Chạy và cài đặt

## ⚙️ Bước 3: Cấu hình kết nối

### Kiểm tra SQL Server đang chạy:
1. Mở **Services** (Windows + R → `services.msc`)
2. Tìm **"SQL Server (SQLEXPRESS)"**
3. Đảm bảo Status = **"Running"**
4. Nếu chưa chạy: Right-click → **Start**

### Test kết nối bằng SSMS:
1. Mở **SQL Server Management Studio**
2. Server name: `.\SQLEXPRESS` hoặc `localhost\SQLEXPRESS`
3. Authentication: **Windows Authentication**
4. Click **Connect**

## 🎯 Bước 4: Chạy ứng dụng Warehouse Management

### Tự động tạo database:
1. Chạy ứng dụng: `dotnet run`
2. Ứng dụng sẽ **TỰ ĐỘNG**:
   - Tạo database `WarehouseManagement`
   - Tạo tất cả các bảng
   - Thêm dữ liệu mẫu
   - Tạo tài khoản admin

### Thông tin đăng nhập mặc định:
- **Username:** `admin`
- **Password:** `admin123`

## 🔍 Bước 5: Kiểm tra database (Tùy chọn)

### Trong SSMS:
1. Refresh **Databases**
2. Mở **WarehouseManagement**
3. Kiểm tra **Tables**:
   - Categories
   - Units  
   - Users
   - Products
   - Inventories
   - Suppliers
   - Customers

### Kiểm tra dữ liệu mẫu:
```sql
-- Kiểm tra user admin
SELECT * FROM Users WHERE Username = 'admin'

-- Kiểm tra categories
SELECT * FROM Categories

-- Kiểm tra units
SELECT * FROM Units
```

## 🛠️ Xử lý sự cố

### Lỗi kết nối database:
1. **Kiểm tra SQL Server đang chạy**
2. **Kiểm tra tên server:** `.\SQLEXPRESS`
3. **Kiểm tra Windows Authentication**

### Lỗi "Login failed":
1. Đảm bảo dùng **Windows Authentication**
2. User Windows phải có quyền trên SQL Server

### Lỗi "Network-related error":
1. Kiểm tra **SQL Server Configuration Manager**
2. Enable **TCP/IP** protocol
3. Restart SQL Server service

## 📝 Connection String

Mặc định trong ứng dụng:
```
Server=.;Database=WarehouseManagement;Integrated Security=true;TrustServerCertificate=true;
```

### Tùy chỉnh connection string:
Sửa trong file `DatabaseHelper.cs`:
```csharp
private static string connectionString = "Server=YOUR_SERVER;Database=WarehouseManagement;Integrated Security=true;TrustServerCertificate=true;";
```

## ✅ Hoàn tất!

Sau khi hoàn thành các bước trên:
1. ✅ SQL Server Express đã cài đặt
2. ✅ Database tự động tạo
3. ✅ Ứng dụng kết nối thành công
4. ✅ Đăng nhập với admin/admin123

**Chúc mừng! Bạn đã có hệ thống quản lý kho hoàn chỉnh với database thật!** 🎉