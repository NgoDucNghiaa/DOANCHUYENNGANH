# 🚀 How to Run Warehouse Management System

## ✅ Your System Status:
- ✅ SQL Server Management Studio 22 installed
- ✅ SQL Server (MSSQLSERVER) running
- ✅ Application built successfully

## 🎯 Quick Start:

### Method 1: Run from Visual Studio 2022
1. Open **Visual Studio 2022**
2. Open **WarehouseManagement.sln**
3. Press **F5** or click **Start**

### Method 2: Run from Command Line
```bash
cd WarehouseManagement
dotnet run
```

### Method 3: Run EXE directly
```bash
.\WarehouseManagement\bin\Debug\net6.0-windows\WarehouseManagement.exe
```

## 🔑 Login Information:
- **Username:** admin
- **Password:** admin123

## 🗄️ Database:
- **Server:** localhost (MSSQLSERVER)
- **Database:** WarehouseManagement (auto-created)
- **Authentication:** Windows Authentication

## ✨ Features Working:
- ✅ Login/Register with real database
- ✅ Product management (Add/Edit/View)
- ✅ Inventory tracking
- ✅ Low stock alerts (red highlighting)
- ✅ User roles (Admin/Staff)

## 🎨 View Forms in Visual Studio:
1. Open **Visual Studio 2022**
2. Open **WarehouseManagement.sln**
3. In **Solution Explorer** → **Forms** folder
4. **Double-click** any `.cs` file (e.g., LoginForm.cs)
5. Click **"Design"** tab at bottom to see visual designer

## 🔧 If Issues:
1. **Check SQL Server running:** Services → SQL Server (MSSQLSERVER)
2. **Rebuild:** Build → Rebuild Solution
3. **Check connection:** App will show error message if database fails

**You now have a fully functional warehouse management system!** 🎉