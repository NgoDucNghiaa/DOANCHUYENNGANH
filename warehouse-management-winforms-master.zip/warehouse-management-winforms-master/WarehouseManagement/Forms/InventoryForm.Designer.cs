namespace WarehouseManagement.Forms
{
    partial class InventoryForm
    {
        private System.ComponentModel.IContainer components = null;
        private DataGridView dgvInventory;
        private Button btnRefresh;
        private Button btnLowStock;
        private Button btnShowAll;
        private Label lblTitle;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvInventory = new DataGridView();
            this.btnRefresh = new Button();
            this.btnLowStock = new Button();
            this.btnShowAll = new Button();
            this.lblTitle = new Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventory)).BeginInit();
            this.SuspendLayout();
            
            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Bold);
            this.lblTitle.Location = new Point(20, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new Size(200, 24);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "QUẢN LÝ TỒN KHO";
            
            // dgvInventory
            this.dgvInventory.AllowUserToAddRows = false;
            this.dgvInventory.AllowUserToDeleteRows = false;
            this.dgvInventory.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvInventory.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInventory.Location = new Point(20, 60);
            this.dgvInventory.MultiSelect = false;
            this.dgvInventory.Name = "dgvInventory";
            this.dgvInventory.ReadOnly = true;
            this.dgvInventory.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvInventory.Size = new Size(760, 400);
            this.dgvInventory.TabIndex = 1;
            
            // btnRefresh
            this.btnRefresh.BackColor = Color.FromArgb(0, 123, 255);
            this.btnRefresh.ForeColor = Color.White;
            this.btnRefresh.Location = new Point(20, 480);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new Size(120, 35);
            this.btnRefresh.TabIndex = 2;
            this.btnRefresh.Text = "Làm mới";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new EventHandler(this.btnRefresh_Click);
            
            // btnLowStock
            this.btnLowStock.BackColor = Color.FromArgb(220, 53, 69);
            this.btnLowStock.ForeColor = Color.White;
            this.btnLowStock.Location = new Point(160, 480);
            this.btnLowStock.Name = "btnLowStock";
            this.btnLowStock.Size = new Size(150, 35);
            this.btnLowStock.TabIndex = 3;
            this.btnLowStock.Text = "Sản phẩm sắp hết";
            this.btnLowStock.UseVisualStyleBackColor = false;
            this.btnLowStock.Click += new EventHandler(this.btnLowStock_Click);
            
            // btnShowAll
            this.btnShowAll.BackColor = Color.FromArgb(40, 167, 69);
            this.btnShowAll.ForeColor = Color.White;
            this.btnShowAll.Location = new Point(330, 480);
            this.btnShowAll.Name = "btnShowAll";
            this.btnShowAll.Size = new Size(120, 35);
            this.btnShowAll.TabIndex = 4;
            this.btnShowAll.Text = "Hiển thị tất cả";
            this.btnShowAll.UseVisualStyleBackColor = false;
            this.btnShowAll.Click += new EventHandler(this.btnShowAll_Click);
            
            // InventoryForm
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new Size(800, 540);
            this.Controls.Add(this.btnShowAll);
            this.Controls.Add(this.btnLowStock);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.dgvInventory);
            this.Controls.Add(this.lblTitle);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "InventoryForm";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Quản lý tồn kho";
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventory)).EndInit();
            this.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}