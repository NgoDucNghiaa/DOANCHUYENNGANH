using WarehouseManagement.Models;
using WarehouseManagement.Services;

namespace WarehouseManagement.Forms
{
    public partial class CategoryForm : Form
    {
        private CategoryService categoryService;
        private bool isEditing = false;
        private int editingCategoryId = 0;

        public CategoryForm()
        {
            InitializeComponent();
            categoryService = new CategoryService();
            LoadData();
            SetupUI();
        }

        private void SetupUI()
        {
            this.Text = "Quản lý danh mục sản phẩm";
            this.WindowState = FormWindowState.Maximized;
            this.StartPosition = FormStartPosition.CenterScreen;
            
            // Setup DataGridView
            dgvCategories.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvCategories.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCategories.MultiSelect = false;
            dgvCategories.AllowUserToAddRows = false;
            dgvCategories.ReadOnly = true;
        }

        private void LoadData()
        {
            try
            {
                dgvCategories.DataSource = categoryService.GetAllCategories();
                
                // Setup columns after data is loaded
                if (dgvCategories.Columns.Count > 0)
                {
                    dgvCategories.Columns["CategoryID"].HeaderText = "Mã danh mục";
                    dgvCategories.Columns["CategoryID"].Width = 100;
                    dgvCategories.Columns["CategoryName"].HeaderText = "Tên danh mục";
                    dgvCategories.Columns["CategoryName"].Width = 200;
                    dgvCategories.Columns["Description"].HeaderText = "Mô tả";
                    dgvCategories.Columns["Description"].Width = 300;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi tải dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                if (categoryService.IsCategoryNameExists(txtCategoryName.Text.Trim()))
                {
                    MessageBox.Show("Tên danh mục đã tồn tại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                Category category = new Category
                {
                    CategoryName = txtCategoryName.Text.Trim(),
                    Description = txtDescription.Text.Trim()
                };

                if (categoryService.AddCategory(category))
                {
                    MessageBox.Show("Thêm danh mục thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearInputs();
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Thêm danh mục thất bại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!isEditing)
            {
                MessageBox.Show("Vui lòng chọn danh mục cần sửa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (ValidateInput())
            {
                if (categoryService.IsCategoryNameExists(txtCategoryName.Text.Trim(), editingCategoryId))
                {
                    MessageBox.Show("Tên danh mục đã tồn tại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                Category category = new Category
                {
                    CategoryID = editingCategoryId,
                    CategoryName = txtCategoryName.Text.Trim(),
                    Description = txtDescription.Text.Trim()
                };

                if (categoryService.UpdateCategory(category))
                {
                    MessageBox.Show("Cập nhật danh mục thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearInputs();
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Cập nhật danh mục thất bại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvCategories.SelectedRows.Count > 0)
            {
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa danh mục này?", 
                    "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                
                if (result == DialogResult.Yes)
                {
                    int categoryId = (int)dgvCategories.SelectedRows[0].Cells["CategoryID"].Value;
                    
                    if (categoryService.DeleteCategory(categoryId))
                    {
                        MessageBox.Show("Xóa danh mục thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ClearInputs();
                        LoadData();
                    }
                    else
                    {
                        MessageBox.Show("Không thể xóa danh mục này vì có sản phẩm đang sử dụng!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn danh mục cần xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void dgvCategories_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvCategories.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvCategories.SelectedRows[0];
                editingCategoryId = (int)row.Cells["CategoryID"].Value;
                txtCategoryName.Text = row.Cells["CategoryName"].Value?.ToString() ?? "";
                txtDescription.Text = row.Cells["Description"].Value?.ToString() ?? "";
                isEditing = true;
                
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearInputs();
        }

        private void ClearInputs()
        {
            txtCategoryName.Clear();
            txtDescription.Clear();
            isEditing = false;
            editingCategoryId = 0;
            
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            
            if (dgvCategories.Rows.Count > 0)
            {
                dgvCategories.ClearSelection();
            }
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(txtCategoryName.Text))
            {
                MessageBox.Show("Vui lòng nhập tên danh mục!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCategoryName.Focus();
                return false;
            }

            return true;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}