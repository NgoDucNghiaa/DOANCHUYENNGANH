using WarehouseManagement.Models;

namespace WarehouseManagement.Forms
{
    public partial class SimpleMainForm : Form
    {
        private User currentUser;

        public SimpleMainForm()
        {
            InitializeComponent();
            // Create a simple user for demo
            currentUser = new User 
            { 
                UserID = 1, 
                Username = "admin", 
                FullName = "Administrator", 
                Role = "Admin" 
            };
        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            try
            {
                ProductForm productForm = new ProductForm();
                productForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi mở form sản phẩm: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnInventory_Click(object sender, EventArgs e)
        {
            try
            {
                InventoryForm inventoryForm = new InventoryForm();
                inventoryForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi mở form tồn kho: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnStockIn_Click(object sender, EventArgs e)
        {
            try
            {
                StockInForm stockInForm = new StockInForm(currentUser);
                stockInForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi mở form nhập kho: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnStockOut_Click(object sender, EventArgs e)
        {
            try
            {
                StockOutForm stockOutForm = new StockOutForm(currentUser);
                stockOutForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi mở form xuất kho: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SimpleMainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void SimpleMainForm_Load(object sender, EventArgs e)
        {
            this.Text = $"Warehouse Management - {currentUser.FullName}";
        }
    }
}