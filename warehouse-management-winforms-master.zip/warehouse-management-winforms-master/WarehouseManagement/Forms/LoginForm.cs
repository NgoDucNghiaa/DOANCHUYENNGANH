using WarehouseManagement.Services;
using WarehouseManagement.Models;
using WarehouseManagement.Data;

namespace WarehouseManagement.Forms
{
    public partial class LoginForm : Form
    {
        private UserService userService;

        public LoginForm()
        {
            InitializeComponent();
            userService = new UserService();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text) || string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Vui lòng nhập tên đăng nhập và mật khẩu!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                User? user = userService.Login(txtUsername.Text.Trim(), txtPassword.Text);
                
                if (user != null)
                {
                    MessageBox.Show($"Đăng nhập thành công! Chào mừng {user.FullName}", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    MainForm mainForm = new MainForm(user);
                    this.Hide();
                    mainForm.ShowDialog();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Tên đăng nhập hoặc mật khẩu không đúng!\n\nMặc định: admin / admin123\n\nNếu không được, nhấn 'Reset Admin Password'", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtPassword.Clear();
                    txtUsername.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi đăng nhập: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnResetAdmin_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Bạn có chắc muốn reset mật khẩu admin về 'admin123'?", 
                "Xác nhận Reset", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            
            if (result == DialogResult.Yes)
            {
                try
                {
                    if (DatabaseHelper.ResetAdminPassword())
                    {
                        MessageBox.Show("Reset mật khẩu admin thành công!\n\nUsername: admin\nPassword: admin123", 
                            "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtUsername.Text = "admin";
                        txtPassword.Text = "admin123";
                    }
                    else
                    {
                        MessageBox.Show("Reset mật khẩu thất bại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            RegisterForm registerForm = new RegisterForm();
            registerForm.ShowDialog();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            try
            {
                DatabaseHelper.CreateDatabaseAndTables();
                // Không hiển thị thông báo nữa, chỉ khởi tạo database im lặng
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khởi tạo database: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}