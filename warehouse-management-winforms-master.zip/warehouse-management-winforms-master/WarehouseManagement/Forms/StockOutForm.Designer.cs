namespace WarehouseManagement.Forms
{
    partial class StockOutForm
    {
        private System.ComponentModel.IContainer components = null;
        private GroupBox gbStockOutInfo;
        private GroupBox gbProductInfo;
        private GroupBox gbDetails;
        private Label lblStockOutID;
        private TextBox txtStockOutID;
        private Label lblDateExport;
        private DateTimePicker dtpDateExport;
        private Label lblCustomer;
        private ComboBox cmbCustomer;
        private Label lblUser;
        private Label lblProduct;
        private ComboBox cmbProduct;
        private Label lblQuantity;
        private TextBox txtQuantity;
        private Label lblUnitPrice;
        private TextBox txtUnitPrice;
        private Label lblAmount;
        private TextBox txtAmount;
        private Label lblAvailableStock;
        private Button btnAddProduct;
        private Button btnRemoveProduct;
        private DataGridView dgvDetails;
        private Label lblTotal;
        private Label lblNotes;
        private TextBox txtNotes;
        private Button btnSave;
        private Button btnCancel;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.gbStockOutInfo = new GroupBox();
            this.gbProductInfo = new GroupBox();
            this.gbDetails = new GroupBox();
            this.lblStockOutID = new Label();
            this.txtStockOutID = new TextBox();
            this.lblDateExport = new Label();
            this.dtpDateExport = new DateTimePicker();
            this.lblCustomer = new Label();
            this.cmbCustomer = new ComboBox();
            this.lblUser = new Label();
            this.lblProduct = new Label();
            this.cmbProduct = new ComboBox();
            this.lblQuantity = new Label();
            this.txtQuantity = new TextBox();
            this.lblUnitPrice = new Label();
            this.txtUnitPrice = new TextBox();
            this.lblAmount = new Label();
            this.txtAmount = new TextBox();
            this.lblAvailableStock = new Label();
            this.btnAddProduct = new Button();
            this.btnRemoveProduct = new Button();
            this.dgvDetails = new DataGridView();
            this.lblTotal = new Label();
            this.lblNotes = new Label();
            this.txtNotes = new TextBox();
            this.btnSave = new Button();
            this.btnCancel = new Button();
            this.gbStockOutInfo.SuspendLayout();
            this.gbProductInfo.SuspendLayout();
            this.gbDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetails)).BeginInit();
            this.SuspendLayout();

            // gbStockOutInfo
            this.gbStockOutInfo.Controls.Add(this.lblStockOutID);
            this.gbStockOutInfo.Controls.Add(this.txtStockOutID);
            this.gbStockOutInfo.Controls.Add(this.lblDateExport);
            this.gbStockOutInfo.Controls.Add(this.dtpDateExport);
            this.gbStockOutInfo.Controls.Add(this.lblCustomer);
            this.gbStockOutInfo.Controls.Add(this.cmbCustomer);
            this.gbStockOutInfo.Controls.Add(this.lblUser);
            this.gbStockOutInfo.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.gbStockOutInfo.ForeColor = Color.DarkBlue;
            this.gbStockOutInfo.Location = new Point(12, 12);
            this.gbStockOutInfo.Name = "gbStockOutInfo";
            this.gbStockOutInfo.Size = new Size(960, 120);
            this.gbStockOutInfo.TabIndex = 0;
            this.gbStockOutInfo.TabStop = false;
            this.gbStockOutInfo.Text = "Thông tin phiếu xuất";

            // lblStockOutID
            this.lblStockOutID.AutoSize = true;
            this.lblStockOutID.Font = new Font("Segoe UI", 9F);
            this.lblStockOutID.ForeColor = Color.Black;
            this.lblStockOutID.Location = new Point(20, 30);
            this.lblStockOutID.Name = "lblStockOutID";
            this.lblStockOutID.Size = new Size(80, 15);
            this.lblStockOutID.TabIndex = 0;
            this.lblStockOutID.Text = "Mã phiếu xuất:";

            // txtStockOutID
            this.txtStockOutID.Font = new Font("Segoe UI", 9F);
            this.txtStockOutID.Location = new Point(120, 27);
            this.txtStockOutID.Name = "txtStockOutID";
            this.txtStockOutID.ReadOnly = true;
            this.txtStockOutID.Size = new Size(150, 23);
            this.txtStockOutID.TabIndex = 1;
            this.txtStockOutID.BackColor = Color.LightGray;

            // lblDateExport
            this.lblDateExport.AutoSize = true;
            this.lblDateExport.Font = new Font("Segoe UI", 9F);
            this.lblDateExport.ForeColor = Color.Black;
            this.lblDateExport.Location = new Point(300, 30);
            this.lblDateExport.Name = "lblDateExport";
            this.lblDateExport.Size = new Size(70, 15);
            this.lblDateExport.TabIndex = 2;
            this.lblDateExport.Text = "Ngày xuất:";

            // dtpDateExport
            this.dtpDateExport.Font = new Font("Segoe UI", 9F);
            this.dtpDateExport.Format = DateTimePickerFormat.Short;
            this.dtpDateExport.Location = new Point(380, 27);
            this.dtpDateExport.Name = "dtpDateExport";
            this.dtpDateExport.Size = new Size(150, 23);
            this.dtpDateExport.TabIndex = 3;

            // lblCustomer
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.Font = new Font("Segoe UI", 9F);
            this.lblCustomer.ForeColor = Color.Black;
            this.lblCustomer.Location = new Point(20, 70);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new Size(80, 15);
            this.lblCustomer.TabIndex = 4;
            this.lblCustomer.Text = "Khách hàng:";

            // cmbCustomer
            this.cmbCustomer.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbCustomer.Font = new Font("Segoe UI", 9F);
            this.cmbCustomer.Location = new Point(120, 67);
            this.cmbCustomer.Name = "cmbCustomer";
            this.cmbCustomer.Size = new Size(250, 23);
            this.cmbCustomer.TabIndex = 5;

            // lblUser
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new Font("Segoe UI", 9F);
            this.lblUser.ForeColor = Color.Black;
            this.lblUser.Location = new Point(400, 70);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new Size(80, 15);
            this.lblUser.TabIndex = 6;
            this.lblUser.Text = "Người xuất:";

            // gbProductInfo
            this.gbProductInfo.Controls.Add(this.lblProduct);
            this.gbProductInfo.Controls.Add(this.cmbProduct);
            this.gbProductInfo.Controls.Add(this.lblQuantity);
            this.gbProductInfo.Controls.Add(this.txtQuantity);
            this.gbProductInfo.Controls.Add(this.lblUnitPrice);
            this.gbProductInfo.Controls.Add(this.txtUnitPrice);
            this.gbProductInfo.Controls.Add(this.lblAmount);
            this.gbProductInfo.Controls.Add(this.txtAmount);
            this.gbProductInfo.Controls.Add(this.lblAvailableStock);
            this.gbProductInfo.Controls.Add(this.btnAddProduct);
            this.gbProductInfo.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.gbProductInfo.ForeColor = Color.DarkGreen;
            this.gbProductInfo.Location = new Point(12, 150);
            this.gbProductInfo.Name = "gbProductInfo";
            this.gbProductInfo.Size = new Size(960, 120);
            this.gbProductInfo.TabIndex = 1;
            this.gbProductInfo.TabStop = false;
            this.gbProductInfo.Text = "Thông tin sản phẩm";

            // lblProduct
            this.lblProduct.AutoSize = true;
            this.lblProduct.Font = new Font("Segoe UI", 9F);
            this.lblProduct.ForeColor = Color.Black;
            this.lblProduct.Location = new Point(20, 30);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new Size(70, 15);
            this.lblProduct.TabIndex = 0;
            this.lblProduct.Text = "Sản phẩm:";

            // cmbProduct
            this.cmbProduct.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbProduct.Font = new Font("Segoe UI", 9F);
            this.cmbProduct.Location = new Point(100, 27);
            this.cmbProduct.Name = "cmbProduct";
            this.cmbProduct.Size = new Size(250, 23);
            this.cmbProduct.TabIndex = 1;
            this.cmbProduct.SelectedIndexChanged += new EventHandler(this.cmbProduct_SelectedIndexChanged);

            // lblAvailableStock
            this.lblAvailableStock.AutoSize = true;
            this.lblAvailableStock.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.lblAvailableStock.ForeColor = Color.Green;
            this.lblAvailableStock.Location = new Point(370, 30);
            this.lblAvailableStock.Name = "lblAvailableStock";
            this.lblAvailableStock.Size = new Size(70, 15);
            this.lblAvailableStock.TabIndex = 2;
            this.lblAvailableStock.Text = "Tồn kho: 0";

            // lblQuantity
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new Font("Segoe UI", 9F);
            this.lblQuantity.ForeColor = Color.Black;
            this.lblQuantity.Location = new Point(20, 70);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new Size(60, 15);
            this.lblQuantity.TabIndex = 3;
            this.lblQuantity.Text = "Số lượng:";

            // txtQuantity
            this.txtQuantity.Font = new Font("Segoe UI", 9F);
            this.txtQuantity.Location = new Point(100, 67);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new Size(80, 23);
            this.txtQuantity.TabIndex = 4;
            this.txtQuantity.TextAlign = HorizontalAlignment.Right;
            this.txtQuantity.TextChanged += new EventHandler(this.txtQuantity_TextChanged);

            // lblUnitPrice
            this.lblUnitPrice.AutoSize = true;
            this.lblUnitPrice.Font = new Font("Segoe UI", 9F);
            this.lblUnitPrice.ForeColor = Color.Black;
            this.lblUnitPrice.Location = new Point(200, 70);
            this.lblUnitPrice.Name = "lblUnitPrice";
            this.lblUnitPrice.Size = new Size(55, 15);
            this.lblUnitPrice.TabIndex = 5;
            this.lblUnitPrice.Text = "Đơn giá:";

            // txtUnitPrice
            this.txtUnitPrice.Font = new Font("Segoe UI", 9F);
            this.txtUnitPrice.Location = new Point(270, 67);
            this.txtUnitPrice.Name = "txtUnitPrice";
            this.txtUnitPrice.Size = new Size(100, 23);
            this.txtUnitPrice.TabIndex = 6;
            this.txtUnitPrice.TextAlign = HorizontalAlignment.Right;
            this.txtUnitPrice.TextChanged += new EventHandler(this.txtUnitPrice_TextChanged);

            // lblAmount
            this.lblAmount.AutoSize = true;
            this.lblAmount.Font = new Font("Segoe UI", 9F);
            this.lblAmount.ForeColor = Color.Black;
            this.lblAmount.Location = new Point(390, 70);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new Size(70, 15);
            this.lblAmount.TabIndex = 7;
            this.lblAmount.Text = "Thành tiền:";

            // txtAmount
            this.txtAmount.Font = new Font("Segoe UI", 9F);
            this.txtAmount.Location = new Point(470, 67);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.ReadOnly = true;
            this.txtAmount.Size = new Size(120, 23);
            this.txtAmount.TabIndex = 8;
            this.txtAmount.TextAlign = HorizontalAlignment.Right;
            this.txtAmount.BackColor = Color.LightGray;

            // btnAddProduct
            this.btnAddProduct.BackColor = Color.FromArgb(0, 123, 255);
            this.btnAddProduct.FlatStyle = FlatStyle.Flat;
            this.btnAddProduct.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnAddProduct.ForeColor = Color.White;
            this.btnAddProduct.Location = new Point(620, 65);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new Size(100, 28);
            this.btnAddProduct.TabIndex = 9;
            this.btnAddProduct.Text = "Thêm SP";
            this.btnAddProduct.UseVisualStyleBackColor = false;
            this.btnAddProduct.Click += new EventHandler(this.btnAddProduct_Click);

            // gbDetails
            this.gbDetails.Controls.Add(this.dgvDetails);
            this.gbDetails.Controls.Add(this.btnRemoveProduct);
            this.gbDetails.Controls.Add(this.lblTotal);
            this.gbDetails.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.gbDetails.ForeColor = Color.DarkRed;
            this.gbDetails.Location = new Point(12, 290);
            this.gbDetails.Name = "gbDetails";
            this.gbDetails.Size = new Size(960, 300);
            this.gbDetails.TabIndex = 2;
            this.gbDetails.TabStop = false;
            this.gbDetails.Text = "Chi tiết xuất kho";

            // dgvDetails
            this.dgvDetails.AllowUserToAddRows = false;
            this.dgvDetails.AllowUserToDeleteRows = false;
            this.dgvDetails.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDetails.BackgroundColor = Color.White;
            this.dgvDetails.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDetails.Font = new Font("Segoe UI", 9F);
            this.dgvDetails.Location = new Point(20, 30);
            this.dgvDetails.MultiSelect = false;
            this.dgvDetails.Name = "dgvDetails";
            this.dgvDetails.ReadOnly = true;
            this.dgvDetails.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvDetails.Size = new Size(920, 200);
            this.dgvDetails.TabIndex = 0;

            // btnRemoveProduct
            this.btnRemoveProduct.BackColor = Color.FromArgb(220, 53, 69);
            this.btnRemoveProduct.FlatStyle = FlatStyle.Flat;
            this.btnRemoveProduct.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnRemoveProduct.ForeColor = Color.White;
            this.btnRemoveProduct.Location = new Point(20, 240);
            this.btnRemoveProduct.Name = "btnRemoveProduct";
            this.btnRemoveProduct.Size = new Size(100, 28);
            this.btnRemoveProduct.TabIndex = 1;
            this.btnRemoveProduct.Text = "Xóa SP";
            this.btnRemoveProduct.UseVisualStyleBackColor = false;
            this.btnRemoveProduct.Click += new EventHandler(this.btnRemoveProduct_Click);

            // lblTotal
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            this.lblTotal.ForeColor = Color.Red;
            this.lblTotal.Location = new Point(700, 245);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new Size(120, 21);
            this.lblTotal.TabIndex = 2;
            this.lblTotal.Text = "Tổng tiền: 0 VNĐ";

            // lblNotes
            this.lblNotes.AutoSize = true;
            this.lblNotes.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.lblNotes.Location = new Point(32, 610);
            this.lblNotes.Name = "lblNotes";
            this.lblNotes.Size = new Size(60, 15);
            this.lblNotes.TabIndex = 3;
            this.lblNotes.Text = "Ghi chú:";

            // txtNotes
            this.txtNotes.Font = new Font("Segoe UI", 9F);
            this.txtNotes.Location = new Point(100, 607);
            this.txtNotes.Multiline = true;
            this.txtNotes.Name = "txtNotes";
            this.txtNotes.Size = new Size(500, 60);
            this.txtNotes.TabIndex = 4;

            // btnSave
            this.btnSave.BackColor = Color.FromArgb(40, 167, 69);
            this.btnSave.FlatStyle = FlatStyle.Flat;
            this.btnSave.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.btnSave.ForeColor = Color.White;
            this.btnSave.Location = new Point(700, 610);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new Size(120, 35);
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "Lưu phiếu xuất";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new EventHandler(this.btnSave_Click);

            // btnCancel
            this.btnCancel.BackColor = Color.FromArgb(108, 117, 125);
            this.btnCancel.FlatStyle = FlatStyle.Flat;
            this.btnCancel.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.btnCancel.ForeColor = Color.White;
            this.btnCancel.Location = new Point(840, 610);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new Size(120, 35);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "Hủy";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new EventHandler(this.btnCancel_Click);

            // StockOutForm
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.FromArgb(248, 249, 250);
            this.ClientSize = new Size(984, 681);
            this.Controls.Add(this.gbStockOutInfo);
            this.Controls.Add(this.gbProductInfo);
            this.Controls.Add(this.gbDetails);
            this.Controls.Add(this.lblNotes);
            this.Controls.Add(this.txtNotes);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Font = new Font("Segoe UI", 9F);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "StockOutForm";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Xuất kho - Warehouse Management System";
            this.Load += new EventHandler(this.StockOutForm_Load);
            this.gbStockOutInfo.ResumeLayout(false);
            this.gbStockOutInfo.PerformLayout();
            this.gbProductInfo.ResumeLayout(false);
            this.gbProductInfo.PerformLayout();
            this.gbDetails.ResumeLayout(false);
            this.gbDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetails)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}