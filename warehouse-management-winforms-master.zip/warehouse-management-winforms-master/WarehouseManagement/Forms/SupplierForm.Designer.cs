namespace WarehouseManagement.Forms
{
    partial class SupplierForm
    {
        private System.ComponentModel.IContainer components = null;
        private Panel pnlTop;
        private Panel pnlBottom;
        private GroupBox gbInfo;
        private GroupBox gbList;
        private Label lblSupplierName;
        private Label lblPhone;
        private Label lblEmail;
        private Label lblAddress;
        private TextBox txtSupplierName;
        private TextBox txtPhone;
        private TextBox txtEmail;
        private TextBox txtAddress;
        private Button btnAdd;
        private Button btnUpdate;
        private Button btnDelete;
        private Button btnClear;
        private Button btnClose;
        private DataGridView dgvSuppliers;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.pnlTop = new Panel();
            this.gbInfo = new GroupBox();
            this.lblSupplierName = new Label();
            this.lblPhone = new Label();
            this.lblEmail = new Label();
            this.lblAddress = new Label();
            this.txtSupplierName = new TextBox();
            this.txtPhone = new TextBox();
            this.txtEmail = new TextBox();
            this.txtAddress = new TextBox();
            this.btnAdd = new Button();
            this.btnUpdate = new Button();
            this.btnDelete = new Button();
            this.btnClear = new Button();
            this.btnClose = new Button();
            this.pnlBottom = new Panel();
            this.gbList = new GroupBox();
            this.dgvSuppliers = new DataGridView();
            
            this.pnlTop.SuspendLayout();
            this.gbInfo.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.gbList.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSuppliers)).BeginInit();
            this.SuspendLayout();

            // pnlTop
            this.pnlTop.Controls.Add(this.gbInfo);
            this.pnlTop.Dock = DockStyle.Top;
            this.pnlTop.Location = new Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new Size(1200, 220);
            this.pnlTop.TabIndex = 0;
            this.pnlTop.BackColor = Color.FromArgb(240, 248, 255);

            // gbInfo
            this.gbInfo.Controls.Add(this.lblSupplierName);
            this.gbInfo.Controls.Add(this.txtSupplierName);
            this.gbInfo.Controls.Add(this.lblPhone);
            this.gbInfo.Controls.Add(this.txtPhone);
            this.gbInfo.Controls.Add(this.lblEmail);
            this.gbInfo.Controls.Add(this.txtEmail);
            this.gbInfo.Controls.Add(this.lblAddress);
            this.gbInfo.Controls.Add(this.txtAddress);
            this.gbInfo.Controls.Add(this.btnAdd);
            this.gbInfo.Controls.Add(this.btnUpdate);
            this.gbInfo.Controls.Add(this.btnDelete);
            this.gbInfo.Controls.Add(this.btnClear);
            this.gbInfo.Controls.Add(this.btnClose);
            this.gbInfo.Dock = DockStyle.Fill;
            this.gbInfo.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.gbInfo.ForeColor = Color.FromArgb(0, 102, 204);
            this.gbInfo.Location = new Point(10, 10);
            this.gbInfo.Margin = new Padding(10);
            this.gbInfo.Name = "gbInfo";
            this.gbInfo.Padding = new Padding(10);
            this.gbInfo.Size = new Size(1180, 200);
            this.gbInfo.TabIndex = 0;
            this.gbInfo.TabStop = false;
            this.gbInfo.Text = "Thông tin nhà cung cấp";

            // lblSupplierName
            this.lblSupplierName.AutoSize = true;
            this.lblSupplierName.Font = new Font("Segoe UI", 9F);
            this.lblSupplierName.ForeColor = Color.Black;
            this.lblSupplierName.Location = new Point(20, 35);
            this.lblSupplierName.Name = "lblSupplierName";
            this.lblSupplierName.Size = new Size(110, 15);
            this.lblSupplierName.TabIndex = 0;
            this.lblSupplierName.Text = "Tên nhà cung cấp:";

            // txtSupplierName
            this.txtSupplierName.Font = new Font("Segoe UI", 9F);
            this.txtSupplierName.Location = new Point(140, 32);
            this.txtSupplierName.Name = "txtSupplierName";
            this.txtSupplierName.Size = new Size(300, 23);
            this.txtSupplierName.TabIndex = 1;

            // lblPhone
            this.lblPhone.AutoSize = true;
            this.lblPhone.Font = new Font("Segoe UI", 9F);
            this.lblPhone.ForeColor = Color.Black;
            this.lblPhone.Location = new Point(460, 35);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new Size(70, 15);
            this.lblPhone.TabIndex = 2;
            this.lblPhone.Text = "Điện thoại:";

            // txtPhone
            this.txtPhone.Font = new Font("Segoe UI", 9F);
            this.txtPhone.Location = new Point(540, 32);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new Size(200, 23);
            this.txtPhone.TabIndex = 3;

            // lblEmail
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new Font("Segoe UI", 9F);
            this.lblEmail.ForeColor = Color.Black;
            this.lblEmail.Location = new Point(20, 70);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new Size(39, 15);
            this.lblEmail.TabIndex = 4;
            this.lblEmail.Text = "Email:";

            // txtEmail
            this.txtEmail.Font = new Font("Segoe UI", 9F);
            this.txtEmail.Location = new Point(140, 67);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new Size(300, 23);
            this.txtEmail.TabIndex = 5;

            // lblAddress
            this.lblAddress.AutoSize = true;
            this.lblAddress.Font = new Font("Segoe UI", 9F);
            this.lblAddress.ForeColor = Color.Black;
            this.lblAddress.Location = new Point(20, 105);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new Size(48, 15);
            this.lblAddress.TabIndex = 6;
            this.lblAddress.Text = "Địa chỉ:";

            // txtAddress
            this.txtAddress.Font = new Font("Segoe UI", 9F);
            this.txtAddress.Location = new Point(140, 102);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new Size(600, 50);
            this.txtAddress.TabIndex = 7;

            // btnAdd
            this.btnAdd.BackColor = Color.FromArgb(46, 125, 50);
            this.btnAdd.FlatStyle = FlatStyle.Flat;
            this.btnAdd.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnAdd.ForeColor = Color.White;
            this.btnAdd.Location = new Point(140, 165);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new Size(80, 30);
            this.btnAdd.TabIndex = 8;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new EventHandler(this.btnAdd_Click);

            // btnUpdate
            this.btnUpdate.BackColor = Color.FromArgb(255, 152, 0);
            this.btnUpdate.Enabled = false;
            this.btnUpdate.FlatStyle = FlatStyle.Flat;
            this.btnUpdate.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnUpdate.ForeColor = Color.White;
            this.btnUpdate.Location = new Point(230, 165);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new Size(80, 30);
            this.btnUpdate.TabIndex = 9;
            this.btnUpdate.Text = "Sửa";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new EventHandler(this.btnUpdate_Click);

            // btnDelete
            this.btnDelete.BackColor = Color.FromArgb(244, 67, 54);
            this.btnDelete.Enabled = false;
            this.btnDelete.FlatStyle = FlatStyle.Flat;
            this.btnDelete.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnDelete.ForeColor = Color.White;
            this.btnDelete.Location = new Point(320, 165);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new Size(80, 30);
            this.btnDelete.TabIndex = 10;
            this.btnDelete.Text = "Xóa";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new EventHandler(this.btnDelete_Click);

            // btnClear
            this.btnClear.BackColor = Color.FromArgb(96, 125, 139);
            this.btnClear.FlatStyle = FlatStyle.Flat;
            this.btnClear.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnClear.ForeColor = Color.White;
            this.btnClear.Location = new Point(410, 165);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new Size(80, 30);
            this.btnClear.TabIndex = 11;
            this.btnClear.Text = "Làm mới";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new EventHandler(this.btnClear_Click);

            // btnClose
            this.btnClose.BackColor = Color.FromArgb(158, 158, 158);
            this.btnClose.FlatStyle = FlatStyle.Flat;
            this.btnClose.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnClose.ForeColor = Color.White;
            this.btnClose.Location = new Point(500, 165);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new Size(80, 30);
            this.btnClose.TabIndex = 12;
            this.btnClose.Text = "Đóng";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new EventHandler(this.btnClose_Click);

            // pnlBottom
            this.pnlBottom.Controls.Add(this.gbList);
            this.pnlBottom.Dock = DockStyle.Fill;
            this.pnlBottom.Location = new Point(0, 220);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new Size(1200, 400);
            this.pnlBottom.TabIndex = 1;
            this.pnlBottom.BackColor = Color.White;

            // gbList
            this.gbList.Controls.Add(this.dgvSuppliers);
            this.gbList.Dock = DockStyle.Fill;
            this.gbList.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.gbList.ForeColor = Color.FromArgb(0, 102, 204);
            this.gbList.Location = new Point(10, 10);
            this.gbList.Margin = new Padding(10);
            this.gbList.Name = "gbList";
            this.gbList.Padding = new Padding(10);
            this.gbList.Size = new Size(1180, 380);
            this.gbList.TabIndex = 0;
            this.gbList.TabStop = false;
            this.gbList.Text = "Danh sách nhà cung cấp";

            // dgvSuppliers
            this.dgvSuppliers.BackgroundColor = Color.White;
            this.dgvSuppliers.BorderStyle = BorderStyle.None;
            this.dgvSuppliers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSuppliers.Dock = DockStyle.Fill;
            this.dgvSuppliers.Font = new Font("Segoe UI", 9F);
            this.dgvSuppliers.GridColor = Color.FromArgb(224, 224, 224);
            this.dgvSuppliers.Location = new Point(10, 26);
            this.dgvSuppliers.Name = "dgvSuppliers";
            this.dgvSuppliers.RowHeadersWidth = 51;
            this.dgvSuppliers.Size = new Size(1160, 344);
            this.dgvSuppliers.TabIndex = 0;
            this.dgvSuppliers.SelectionChanged += new EventHandler(this.dgvSuppliers_SelectionChanged);

            // SupplierForm
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.White;
            this.ClientSize = new Size(1200, 620);
            this.Controls.Add(this.pnlBottom);
            this.Controls.Add(this.pnlTop);
            this.Font = new Font("Segoe UI", 9F);
            this.Name = "SupplierForm";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Quản lý nhà cung cấp";
            
            this.pnlTop.ResumeLayout(false);
            this.gbInfo.ResumeLayout(false);
            this.gbInfo.PerformLayout();
            this.pnlBottom.ResumeLayout(false);
            this.gbList.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSuppliers)).EndInit();
            this.ResumeLayout(false);
        }
    }
}