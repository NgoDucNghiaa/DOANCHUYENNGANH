using WarehouseManagement.Models;
using WarehouseManagement.Services;

namespace WarehouseManagement.Forms
{
    public partial class ProductForm : Form
    {
        private ProductService productService;
        private User? currentUser;

        public ProductForm()
        {
            InitializeComponent();
            productService = new ProductService();
            currentUser = null;
            LoadData();
        }

        public ProductForm(User user)
        {
            InitializeComponent();
            productService = new ProductService();
            currentUser = user;
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                // Load products
                dgvProducts.DataSource = productService.GetAllProducts();
                
                // Load categories
                var categories = productService.GetAllCategories();
                cmbCategory.DataSource = categories;
                cmbCategory.DisplayMember = "CategoryName";
                cmbCategory.ValueMember = "CategoryID";
                
                // Load units
                var units = productService.GetAllUnits();
                cmbUnit.DataSource = units;
                cmbUnit.DisplayMember = "UnitName";
                cmbUnit.ValueMember = "UnitID";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi tải dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                if (productService.IsProductIdExists(txtProductId.Text.Trim()))
                {
                    MessageBox.Show("Mã sản phẩm đã tồn tại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                Product product = new Product
                {
                    ProductID = txtProductId.Text.Trim(),
                    ProductName = txtProductName.Text.Trim(),
                    CategoryID = (int)cmbCategory.SelectedValue,
                    UnitID = (int)cmbUnit.SelectedValue,
                    UnitPrice = decimal.Parse(txtUnitPrice.Text),
                    MinStock = int.Parse(txtMinStock.Text),
                    IsActive = true
                };

                if (productService.AddProduct(product))
                {
                    MessageBox.Show("Thêm sản phẩm thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearInputs();
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Thêm sản phẩm thất bại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgvProducts.SelectedRows.Count > 0 && ValidateInput())
            {
                Product product = new Product
                {
                    ProductID = txtProductId.Text.Trim(),
                    ProductName = txtProductName.Text.Trim(),
                    CategoryID = (int)cmbCategory.SelectedValue,
                    UnitID = (int)cmbUnit.SelectedValue,
                    UnitPrice = decimal.Parse(txtUnitPrice.Text),
                    MinStock = int.Parse(txtMinStock.Text),
                    IsActive = true
                };

                if (productService.UpdateProduct(product))
                {
                    MessageBox.Show("Cập nhật sản phẩm thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearInputs();
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Cập nhật sản phẩm thất bại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (dgvProducts.SelectedRows.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn sản phẩm cần cập nhật!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvProducts.SelectedRows.Count > 0)
            {
                var selectedRow = dgvProducts.SelectedRows[0];
                var productId = selectedRow.Cells["ProductID"].Value?.ToString();
                var productName = selectedRow.Cells["ProductName"].Value?.ToString();
                
                if (string.IsNullOrEmpty(productId))
                {
                    MessageBox.Show("Không thể xác định sản phẩm cần xóa!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                
                var result = MessageBox.Show($"Bạn có chắc chắn muốn xóa sản phẩm '{productName}' (Mã: {productId})?", 
                    "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                
                if (result == DialogResult.Yes)
                {
                    try
                    {
                        if (productService.DeleteProduct(productId))
                        {
                            MessageBox.Show("Xóa sản phẩm thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearInputs();
                            LoadData();
                        }
                        else
                        {
                            MessageBox.Show("Xóa sản phẩm thất bại! Có thể sản phẩm đang được sử dụng trong giao dịch.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn sản phẩm cần xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void dgvProducts_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvProducts.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvProducts.SelectedRows[0];
                txtProductId.Text = row.Cells["ProductID"].Value?.ToString() ?? "";
                txtProductName.Text = row.Cells["ProductName"].Value?.ToString() ?? "";
                cmbCategory.SelectedValue = row.Cells["CategoryID"].Value;
                cmbUnit.SelectedValue = row.Cells["UnitID"].Value;
                txtUnitPrice.Text = row.Cells["UnitPrice"].Value?.ToString() ?? "";
                txtMinStock.Text = row.Cells["MinStock"].Value?.ToString() ?? "";
                
                txtProductId.ReadOnly = true; // Không cho sửa mã sản phẩm
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;
            }
            else
            {
                btnUpdate.Enabled = false;
                btnDelete.Enabled = false;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearInputs();
        }

        private void ClearInputs()
        {
            txtProductId.Clear();
            txtProductName.Clear();
            txtUnitPrice.Clear();
            txtMinStock.Clear();
            txtProductId.ReadOnly = false;
            
            if (cmbCategory.Items.Count > 0) cmbCategory.SelectedIndex = 0;
            if (cmbUnit.Items.Count > 0) cmbUnit.SelectedIndex = 0;
            
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(txtProductId.Text) ||
                string.IsNullOrWhiteSpace(txtProductName.Text) ||
                string.IsNullOrWhiteSpace(txtUnitPrice.Text) ||
                string.IsNullOrWhiteSpace(txtMinStock.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!decimal.TryParse(txtUnitPrice.Text, out _))
            {
                MessageBox.Show("Giá bán phải là số!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (!int.TryParse(txtMinStock.Text, out _))
            {
                MessageBox.Show("Tồn kho tối thiểu phải là số nguyên!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }
    }
}