using WarehouseManagement.Models;
using WarehouseManagement.Services;

namespace WarehouseManagement.Forms
{
    public partial class SupplierForm : Form
    {
        private SupplierService supplierService;
        private bool isEditing = false;
        private int editingSupplierId = 0;

        public SupplierForm()
        {
            InitializeComponent();
            supplierService = new SupplierService();
            LoadData();
            SetupUI();
        }

        private void SetupUI()
        {
            this.Text = "Quản lý nhà cung cấp";
            this.WindowState = FormWindowState.Maximized;
            this.StartPosition = FormStartPosition.CenterScreen;
            
            // Setup DataGridView
            dgvSuppliers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvSuppliers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvSuppliers.MultiSelect = false;
            dgvSuppliers.AllowUserToAddRows = false;
            dgvSuppliers.ReadOnly = true;
        }

        private void LoadData()
        {
            try
            {
                dgvSuppliers.DataSource = supplierService.GetAllSuppliers();
                
                // Setup columns after data is loaded
                if (dgvSuppliers.Columns.Count > 0)
                {
                    dgvSuppliers.Columns["SupplierID"].HeaderText = "Mã NCC";
                    dgvSuppliers.Columns["SupplierID"].Width = 80;
                    dgvSuppliers.Columns["SupplierName"].HeaderText = "Tên nhà cung cấp";
                    dgvSuppliers.Columns["SupplierName"].Width = 200;
                    dgvSuppliers.Columns["Phone"].HeaderText = "Điện thoại";
                    dgvSuppliers.Columns["Phone"].Width = 120;
                    dgvSuppliers.Columns["Email"].HeaderText = "Email";
                    dgvSuppliers.Columns["Email"].Width = 150;
                    dgvSuppliers.Columns["Address"].HeaderText = "Địa chỉ";
                    dgvSuppliers.Columns["Address"].Width = 250;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi tải dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                if (supplierService.IsSupplierNameExists(txtSupplierName.Text.Trim()))
                {
                    MessageBox.Show("Tên nhà cung cấp đã tồn tại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                Supplier supplier = new Supplier
                {
                    SupplierName = txtSupplierName.Text.Trim(),
                    Phone = txtPhone.Text.Trim(),
                    Email = txtEmail.Text.Trim(),
                    Address = txtAddress.Text.Trim()
                };

                if (supplierService.AddSupplier(supplier))
                {
                    MessageBox.Show("Thêm nhà cung cấp thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearInputs();
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Thêm nhà cung cấp thất bại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!isEditing)
            {
                MessageBox.Show("Vui lòng chọn nhà cung cấp cần sửa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (ValidateInput())
            {
                if (supplierService.IsSupplierNameExists(txtSupplierName.Text.Trim(), editingSupplierId))
                {
                    MessageBox.Show("Tên nhà cung cấp đã tồn tại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                Supplier supplier = new Supplier
                {
                    SupplierID = editingSupplierId,
                    SupplierName = txtSupplierName.Text.Trim(),
                    Phone = txtPhone.Text.Trim(),
                    Email = txtEmail.Text.Trim(),
                    Address = txtAddress.Text.Trim()
                };

                if (supplierService.UpdateSupplier(supplier))
                {
                    MessageBox.Show("Cập nhật nhà cung cấp thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearInputs();
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Cập nhật nhà cung cấp thất bại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvSuppliers.SelectedRows.Count > 0)
            {
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa nhà cung cấp này?", 
                    "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                
                if (result == DialogResult.Yes)
                {
                    int supplierId = (int)dgvSuppliers.SelectedRows[0].Cells["SupplierID"].Value;
                    
                    if (supplierService.DeleteSupplier(supplierId))
                    {
                        MessageBox.Show("Xóa nhà cung cấp thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ClearInputs();
                        LoadData();
                    }
                    else
                    {
                        MessageBox.Show("Xóa nhà cung cấp thất bại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn nhà cung cấp cần xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void dgvSuppliers_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvSuppliers.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvSuppliers.SelectedRows[0];
                editingSupplierId = (int)row.Cells["SupplierID"].Value;
                txtSupplierName.Text = row.Cells["SupplierName"].Value?.ToString() ?? "";
                txtPhone.Text = row.Cells["Phone"].Value?.ToString() ?? "";
                txtEmail.Text = row.Cells["Email"].Value?.ToString() ?? "";
                txtAddress.Text = row.Cells["Address"].Value?.ToString() ?? "";
                isEditing = true;
                
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearInputs();
        }

        private void ClearInputs()
        {
            txtSupplierName.Clear();
            txtPhone.Clear();
            txtEmail.Clear();
            txtAddress.Clear();
            isEditing = false;
            editingSupplierId = 0;
            
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            
            if (dgvSuppliers.Rows.Count > 0)
            {
                dgvSuppliers.ClearSelection();
            }
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(txtSupplierName.Text))
            {
                MessageBox.Show("Vui lòng nhập tên nhà cung cấp!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSupplierName.Focus();
                return false;
            }

            if (!string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                if (!IsValidEmail(txtEmail.Text.Trim()))
                {
                    MessageBox.Show("Email không hợp lệ!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtEmail.Focus();
                    return false;
                }
            }

            return true;
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}