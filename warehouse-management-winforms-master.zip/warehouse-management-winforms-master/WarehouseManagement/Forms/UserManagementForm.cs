using WarehouseManagement.Models;
using WarehouseManagement.Services;

namespace WarehouseManagement.Forms
{
    public partial class UserManagementForm : Form
    {
        private UserService userService;
        private bool isEditing = false;
        private int editingUserId = 0;

        public UserManagementForm()
        {
            InitializeComponent();
            userService = new UserService();
            LoadData();
            SetupUI();
        }

        private void SetupUI()
        {
            this.Text = "Quản lý người dùng";
            this.WindowState = FormWindowState.Maximized;
            this.StartPosition = FormStartPosition.CenterScreen;
            
            // Setup DataGridView
            dgvUsers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvUsers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvUsers.MultiSelect = false;
            dgvUsers.AllowUserToAddRows = false;
            dgvUsers.ReadOnly = true;
            
            // Setup role combobox
            cmbRole.Items.Clear();
            cmbRole.Items.Add("Admin");
            cmbRole.Items.Add("Staff");
            cmbRole.SelectedIndex = 1; // Default to Staff
            
            ClearInputs();
        }

        private void LoadData()
        {
            try
            {
                var users = userService.GetAllUsers();
                dgvUsers.DataSource = users;
                
                // Setup columns after data is loaded
                if (dgvUsers.Columns.Count > 0)
                {
                    dgvUsers.Columns["UserID"].HeaderText = "Mã người dùng";
                    dgvUsers.Columns["UserID"].Width = 100;
                    dgvUsers.Columns["Username"].HeaderText = "Tên đăng nhập";
                    dgvUsers.Columns["Username"].Width = 150;
                    dgvUsers.Columns["FullName"].HeaderText = "Họ tên";
                    dgvUsers.Columns["FullName"].Width = 200;
                    dgvUsers.Columns["Role"].HeaderText = "Vai trò";
                    dgvUsers.Columns["Role"].Width = 100;
                    
                    // Hide password column
                    if (dgvUsers.Columns.Contains("Password"))
                        dgvUsers.Columns["Password"].Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi tải dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearInputs()
        {
            txtUsername.Clear();
            txtPassword.Clear();
            txtConfirmPassword.Clear();
            txtFullName.Clear();
            cmbRole.SelectedIndex = 1; // Staff
            isEditing = false;
            editingUserId = 0;
            
            btnAdd.Text = "Thêm";
            btnAdd.Enabled = true;
            txtUsername.Enabled = true;
            txtPassword.Enabled = true;
            txtConfirmPassword.Enabled = true;
            lblPasswordNote.Text = "Mật khẩu (tối thiểu 6 ký tự)";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (ValidateInputs())
            {
                try
                {
                    if (isEditing)
                    {
                        // Update user
                        var user = new User
                        {
                            UserID = editingUserId,
                            Username = txtUsername.Text.Trim(),
                            FullName = txtFullName.Text.Trim(),
                            Role = cmbRole.Text
                        };

                        if (!string.IsNullOrEmpty(txtPassword.Text))
                        {
                            user.Password = txtPassword.Text;
                        }

                        if (userService.UpdateUser(user, !string.IsNullOrEmpty(txtPassword.Text)))
                        {
                            MessageBox.Show("Cập nhật người dùng thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadData();
                            ClearInputs();
                        }
                        else
                        {
                            MessageBox.Show("Cập nhật người dùng thất bại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        // Add new user
                        if (userService.IsUsernameExists(txtUsername.Text.Trim()))
                        {
                            MessageBox.Show("Tên đăng nhập đã tồn tại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txtUsername.Focus();
                            return;
                        }

                        if (userService.Register(txtUsername.Text.Trim(), txtPassword.Text, txtFullName.Text.Trim(), cmbRole.Text))
                        {
                            MessageBox.Show("Thêm người dùng thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadData();
                            ClearInputs();
                        }
                        else
                        {
                            MessageBox.Show("Thêm người dùng thất bại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text))
            {
                MessageBox.Show("Vui lòng nhập tên đăng nhập!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtUsername.Focus();
                return false;
            }

            if (!isEditing && string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Vui lòng nhập mật khẩu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPassword.Focus();
                return false;
            }

            if (!string.IsNullOrEmpty(txtPassword.Text))
            {
                if (txtPassword.Text.Length < 6)
                {
                    MessageBox.Show("Mật khẩu phải có ít nhất 6 ký tự!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtPassword.Focus();
                    return false;
                }

                if (txtPassword.Text != txtConfirmPassword.Text)
                {
                    MessageBox.Show("Mật khẩu xác nhận không khớp!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtConfirmPassword.Focus();
                    return false;
                }
            }

            if (string.IsNullOrWhiteSpace(txtFullName.Text))
            {
                MessageBox.Show("Vui lòng nhập họ tên!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtFullName.Focus();
                return false;
            }

            return true;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgvUsers.SelectedRows.Count > 0)
            {
                var selectedRow = dgvUsers.SelectedRows[0];
                editingUserId = (int)selectedRow.Cells["UserID"].Value;
                
                txtUsername.Text = selectedRow.Cells["Username"].Value.ToString();
                txtFullName.Text = selectedRow.Cells["FullName"].Value.ToString();
                cmbRole.Text = selectedRow.Cells["Role"].Value.ToString();
                
                txtPassword.Clear();
                txtConfirmPassword.Clear();
                
                isEditing = true;
                btnAdd.Text = "Cập nhật";
                txtUsername.Enabled = false; // Don't allow changing username
                lblPasswordNote.Text = "Mật khẩu (để trống nếu không đổi)";
            }
            else
            {
                MessageBox.Show("Vui lòng chọn người dùng cần sửa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvUsers.SelectedRows.Count > 0)
            {
                var selectedRow = dgvUsers.SelectedRows[0];
                var userId = (int)selectedRow.Cells["UserID"].Value;
                var username = selectedRow.Cells["Username"].Value?.ToString() ?? "";
                
                // Don't allow deleting admin user
                if (username.ToLower() == "admin")
                {
                    MessageBox.Show("Không thể xóa tài khoản admin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                
                var result = MessageBox.Show($"Bạn có chắc chắn muốn xóa người dùng '{username}'?", 
                    "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                
                if (result == DialogResult.Yes)
                {
                    try
                    {
                        if (userService.DeleteUser(userId))
                        {
                            MessageBox.Show("Xóa người dùng thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadData();
                            ClearInputs();
                        }
                        else
                        {
                            MessageBox.Show("Xóa người dùng thất bại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn người dùng cần xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearInputs();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
            ClearInputs();
        }

        private void dgvUsers_SelectionChanged(object sender, EventArgs e)
        {
            btnEdit.Enabled = dgvUsers.SelectedRows.Count > 0;
            btnDelete.Enabled = dgvUsers.SelectedRows.Count > 0;
        }

        private void UserManagementForm_Load(object sender, EventArgs e)
        {
            // Form is already initialized in constructor
        }
    }
}