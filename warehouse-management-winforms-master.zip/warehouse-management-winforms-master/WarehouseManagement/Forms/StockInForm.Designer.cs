namespace WarehouseManagement.Forms
{
    partial class StockInForm
    {
        private System.ComponentModel.IContainer components = null;
        private GroupBox gbStockInInfo;
        private GroupBox gbProductInfo;
        private GroupBox gbDetails;
        private Label lblStockInID;
        private TextBox txtStockInID;
        private Label lblDateImport;
        private DateTimePicker dtpDateImport;
        private Label lblSupplier;
        private ComboBox cmbSupplier;
        private Label lblUser;
        private Label lblProduct;
        private ComboBox cmbProduct;
        private Label lblQuantity;
        private TextBox txtQuantity;
        private Label lblUnitPrice;
        private TextBox txtUnitPrice;
        private Label lblAmount;
        private TextBox txtAmount;
        private Button btnAddProduct;
        private Button btnRemoveProduct;
        private DataGridView dgvDetails;
        private Label lblTotal;
        private Label lblNotes;
        private TextBox txtNotes;
        private Button btnSave;
        private Button btnCancel;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.gbStockInInfo = new GroupBox();
            this.gbProductInfo = new GroupBox();
            this.gbDetails = new GroupBox();
            this.lblStockInID = new Label();
            this.txtStockInID = new TextBox();
            this.lblDateImport = new Label();
            this.dtpDateImport = new DateTimePicker();
            this.lblSupplier = new Label();
            this.cmbSupplier = new ComboBox();
            this.lblUser = new Label();
            this.lblProduct = new Label();
            this.cmbProduct = new ComboBox();
            this.lblQuantity = new Label();
            this.txtQuantity = new TextBox();
            this.lblUnitPrice = new Label();
            this.txtUnitPrice = new TextBox();
            this.lblAmount = new Label();
            this.txtAmount = new TextBox();
            this.btnAddProduct = new Button();
            this.btnRemoveProduct = new Button();
            this.dgvDetails = new DataGridView();
            this.lblTotal = new Label();
            this.lblNotes = new Label();
            this.txtNotes = new TextBox();
            this.btnSave = new Button();
            this.btnCancel = new Button();
            this.gbStockInInfo.SuspendLayout();
            this.gbProductInfo.SuspendLayout();
            this.gbDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetails)).BeginInit();
            this.SuspendLayout();

            // gbStockInInfo
            this.gbStockInInfo.Controls.Add(this.lblStockInID);
            this.gbStockInInfo.Controls.Add(this.txtStockInID);
            this.gbStockInInfo.Controls.Add(this.lblDateImport);
            this.gbStockInInfo.Controls.Add(this.dtpDateImport);
            this.gbStockInInfo.Controls.Add(this.lblSupplier);
            this.gbStockInInfo.Controls.Add(this.cmbSupplier);
            this.gbStockInInfo.Controls.Add(this.lblUser);
            this.gbStockInInfo.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.gbStockInInfo.ForeColor = Color.DarkBlue;
            this.gbStockInInfo.Location = new Point(12, 12);
            this.gbStockInInfo.Name = "gbStockInInfo";
            this.gbStockInInfo.Size = new Size(960, 120);
            this.gbStockInInfo.TabIndex = 0;
            this.gbStockInInfo.TabStop = false;
            this.gbStockInInfo.Text = "Thông tin phiếu nhập";

            // lblStockInID
            this.lblStockInID.AutoSize = true;
            this.lblStockInID.Font = new Font("Segoe UI", 9F);
            this.lblStockInID.ForeColor = Color.Black;
            this.lblStockInID.Location = new Point(20, 30);
            this.lblStockInID.Name = "lblStockInID";
            this.lblStockInID.Size = new Size(80, 15);
            this.lblStockInID.TabIndex = 0;
            this.lblStockInID.Text = "Mã phiếu nhập:";

            // txtStockInID
            this.txtStockInID.Font = new Font("Segoe UI", 9F);
            this.txtStockInID.Location = new Point(120, 27);
            this.txtStockInID.Name = "txtStockInID";
            this.txtStockInID.ReadOnly = true;
            this.txtStockInID.Size = new Size(150, 23);
            this.txtStockInID.TabIndex = 1;
            this.txtStockInID.BackColor = Color.LightGray;

            // lblDateImport
            this.lblDateImport.AutoSize = true;
            this.lblDateImport.Font = new Font("Segoe UI", 9F);
            this.lblDateImport.ForeColor = Color.Black;
            this.lblDateImport.Location = new Point(300, 30);
            this.lblDateImport.Name = "lblDateImport";
            this.lblDateImport.Size = new Size(70, 15);
            this.lblDateImport.TabIndex = 2;
            this.lblDateImport.Text = "Ngày nhập:";

            // dtpDateImport
            this.dtpDateImport.Font = new Font("Segoe UI", 9F);
            this.dtpDateImport.Format = DateTimePickerFormat.Short;
            this.dtpDateImport.Location = new Point(380, 27);
            this.dtpDateImport.Name = "dtpDateImport";
            this.dtpDateImport.Size = new Size(150, 23);
            this.dtpDateImport.TabIndex = 3;

            // lblSupplier
            this.lblSupplier.AutoSize = true;
            this.lblSupplier.Font = new Font("Segoe UI", 9F);
            this.lblSupplier.ForeColor = Color.Black;
            this.lblSupplier.Location = new Point(20, 70);
            this.lblSupplier.Name = "lblSupplier";
            this.lblSupplier.Size = new Size(90, 15);
            this.lblSupplier.TabIndex = 4;
            this.lblSupplier.Text = "Nhà cung cấp:";

            // cmbSupplier
            this.cmbSupplier.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbSupplier.Font = new Font("Segoe UI", 9F);
            this.cmbSupplier.Location = new Point(120, 67);
            this.cmbSupplier.Name = "cmbSupplier";
            this.cmbSupplier.Size = new Size(250, 23);
            this.cmbSupplier.TabIndex = 5;

            // lblUser
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new Font("Segoe UI", 9F);
            this.lblUser.ForeColor = Color.Black;
            this.lblUser.Location = new Point(400, 70);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new Size(80, 15);
            this.lblUser.TabIndex = 6;
            this.lblUser.Text = "Người nhập:";

            // gbProductInfo
            this.gbProductInfo.Controls.Add(this.lblProduct);
            this.gbProductInfo.Controls.Add(this.cmbProduct);
            this.gbProductInfo.Controls.Add(this.lblQuantity);
            this.gbProductInfo.Controls.Add(this.txtQuantity);
            this.gbProductInfo.Controls.Add(this.lblUnitPrice);
            this.gbProductInfo.Controls.Add(this.txtUnitPrice);
            this.gbProductInfo.Controls.Add(this.lblAmount);
            this.gbProductInfo.Controls.Add(this.txtAmount);
            this.gbProductInfo.Controls.Add(this.btnAddProduct);
            this.gbProductInfo.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.gbProductInfo.ForeColor = Color.DarkGreen;
            this.gbProductInfo.Location = new Point(12, 150);
            this.gbProductInfo.Name = "gbProductInfo";
            this.gbProductInfo.Size = new Size(960, 100);
            this.gbProductInfo.TabIndex = 1;
            this.gbProductInfo.TabStop = false;
            this.gbProductInfo.Text = "Thông tin sản phẩm";

            // lblProduct
            this.lblProduct.AutoSize = true;
            this.lblProduct.Font = new Font("Segoe UI", 9F);
            this.lblProduct.ForeColor = Color.Black;
            this.lblProduct.Location = new Point(20, 30);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new Size(70, 15);
            this.lblProduct.TabIndex = 0;
            this.lblProduct.Text = "Sản phẩm:";

            // cmbProduct
            this.cmbProduct.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbProduct.Font = new Font("Segoe UI", 9F);
            this.cmbProduct.Location = new Point(100, 27);
            this.cmbProduct.Name = "cmbProduct";
            this.cmbProduct.Size = new Size(250, 23);
            this.cmbProduct.TabIndex = 1;
            this.cmbProduct.SelectedIndexChanged += new EventHandler(this.cmbProduct_SelectedIndexChanged);

            // lblQuantity
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new Font("Segoe UI", 9F);
            this.lblQuantity.ForeColor = Color.Black;
            this.lblQuantity.Location = new Point(370, 30);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new Size(60, 15);
            this.lblQuantity.TabIndex = 2;
            this.lblQuantity.Text = "Số lượng:";

            // txtQuantity
            this.txtQuantity.Font = new Font("Segoe UI", 9F);
            this.txtQuantity.Location = new Point(440, 27);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new Size(80, 23);
            this.txtQuantity.TabIndex = 3;
            this.txtQuantity.TextAlign = HorizontalAlignment.Right;
            this.txtQuantity.TextChanged += new EventHandler(this.txtQuantity_TextChanged);

            // lblUnitPrice
            this.lblUnitPrice.AutoSize = true;
            this.lblUnitPrice.Font = new Font("Segoe UI", 9F);
            this.lblUnitPrice.ForeColor = Color.Black;
            this.lblUnitPrice.Location = new Point(540, 30);
            this.lblUnitPrice.Name = "lblUnitPrice";
            this.lblUnitPrice.Size = new Size(55, 15);
            this.lblUnitPrice.TabIndex = 4;
            this.lblUnitPrice.Text = "Đơn giá:";

            // txtUnitPrice
            this.txtUnitPrice.Font = new Font("Segoe UI", 9F);
            this.txtUnitPrice.Location = new Point(600, 27);
            this.txtUnitPrice.Name = "txtUnitPrice";
            this.txtUnitPrice.Size = new Size(100, 23);
            this.txtUnitPrice.TabIndex = 5;
            this.txtUnitPrice.TextAlign = HorizontalAlignment.Right;
            this.txtUnitPrice.TextChanged += new EventHandler(this.txtUnitPrice_TextChanged);

            // lblAmount
            this.lblAmount.AutoSize = true;
            this.lblAmount.Font = new Font("Segoe UI", 9F);
            this.lblAmount.ForeColor = Color.Black;
            this.lblAmount.Location = new Point(20, 70);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new Size(70, 15);
            this.lblAmount.TabIndex = 6;
            this.lblAmount.Text = "Thành tiền:";

            // txtAmount
            this.txtAmount.Font = new Font("Segoe UI", 9F);
            this.txtAmount.Location = new Point(100, 67);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.ReadOnly = true;
            this.txtAmount.Size = new Size(120, 23);
            this.txtAmount.TabIndex = 7;
            this.txtAmount.TextAlign = HorizontalAlignment.Right;
            this.txtAmount.BackColor = Color.LightGray;

            // btnAddProduct
            this.btnAddProduct.BackColor = Color.FromArgb(0, 123, 255);
            this.btnAddProduct.FlatStyle = FlatStyle.Flat;
            this.btnAddProduct.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnAddProduct.ForeColor = Color.White;
            this.btnAddProduct.Location = new Point(250, 65);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new Size(100, 28);
            this.btnAddProduct.TabIndex = 8;
            this.btnAddProduct.Text = "Thêm SP";
            this.btnAddProduct.UseVisualStyleBackColor = false;
            this.btnAddProduct.Click += new EventHandler(this.btnAddProduct_Click);

            // gbDetails
            this.gbDetails.Controls.Add(this.dgvDetails);
            this.gbDetails.Controls.Add(this.btnRemoveProduct);
            this.gbDetails.Controls.Add(this.lblTotal);
            this.gbDetails.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.gbDetails.ForeColor = Color.DarkRed;
            this.gbDetails.Location = new Point(12, 270);
            this.gbDetails.Name = "gbDetails";
            this.gbDetails.Size = new Size(960, 300);
            this.gbDetails.TabIndex = 2;
            this.gbDetails.TabStop = false;
            this.gbDetails.Text = "Chi tiết nhập kho";

            // dgvDetails
            this.dgvDetails.AllowUserToAddRows = false;
            this.dgvDetails.AllowUserToDeleteRows = false;
            this.dgvDetails.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDetails.BackgroundColor = Color.White;
            this.dgvDetails.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDetails.Font = new Font("Segoe UI", 9F);
            this.dgvDetails.Location = new Point(20, 30);
            this.dgvDetails.MultiSelect = false;
            this.dgvDetails.Name = "dgvDetails";
            this.dgvDetails.ReadOnly = true;
            this.dgvDetails.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvDetails.Size = new Size(920, 200);
            this.dgvDetails.TabIndex = 0;

            // btnRemoveProduct
            this.btnRemoveProduct.BackColor = Color.FromArgb(220, 53, 69);
            this.btnRemoveProduct.FlatStyle = FlatStyle.Flat;
            this.btnRemoveProduct.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnRemoveProduct.ForeColor = Color.White;
            this.btnRemoveProduct.Location = new Point(20, 240);
            this.btnRemoveProduct.Name = "btnRemoveProduct";
            this.btnRemoveProduct.Size = new Size(100, 28);
            this.btnRemoveProduct.TabIndex = 1;
            this.btnRemoveProduct.Text = "Xóa SP";
            this.btnRemoveProduct.UseVisualStyleBackColor = false;
            this.btnRemoveProduct.Click += new EventHandler(this.btnRemoveProduct_Click);

            // lblTotal
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            this.lblTotal.ForeColor = Color.Red;
            this.lblTotal.Location = new Point(700, 245);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new Size(120, 21);
            this.lblTotal.TabIndex = 2;
            this.lblTotal.Text = "Tổng tiền: 0 VNĐ";

            // lblNotes
            this.lblNotes.AutoSize = true;
            this.lblNotes.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.lblNotes.Location = new Point(32, 590);
            this.lblNotes.Name = "lblNotes";
            this.lblNotes.Size = new Size(60, 15);
            this.lblNotes.TabIndex = 3;
            this.lblNotes.Text = "Ghi chú:";

            // txtNotes
            this.txtNotes.Font = new Font("Segoe UI", 9F);
            this.txtNotes.Location = new Point(100, 587);
            this.txtNotes.Multiline = true;
            this.txtNotes.Name = "txtNotes";
            this.txtNotes.Size = new Size(500, 60);
            this.txtNotes.TabIndex = 4;

            // btnSave
            this.btnSave.BackColor = Color.FromArgb(40, 167, 69);
            this.btnSave.FlatStyle = FlatStyle.Flat;
            this.btnSave.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.btnSave.ForeColor = Color.White;
            this.btnSave.Location = new Point(700, 590);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new Size(120, 35);
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "Lưu phiếu nhập";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new EventHandler(this.btnSave_Click);

            // btnCancel
            this.btnCancel.BackColor = Color.FromArgb(108, 117, 125);
            this.btnCancel.FlatStyle = FlatStyle.Flat;
            this.btnCancel.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.btnCancel.ForeColor = Color.White;
            this.btnCancel.Location = new Point(840, 590);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new Size(120, 35);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "Hủy";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new EventHandler(this.btnCancel_Click);

            // StockInForm
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.FromArgb(248, 249, 250);
            this.ClientSize = new Size(984, 661);
            this.Controls.Add(this.gbStockInInfo);
            this.Controls.Add(this.gbProductInfo);
            this.Controls.Add(this.gbDetails);
            this.Controls.Add(this.lblNotes);
            this.Controls.Add(this.txtNotes);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Font = new Font("Segoe UI", 9F);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "StockInForm";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Nhập kho - Warehouse Management System";
            this.Load += new EventHandler(this.StockInForm_Load);
            this.gbStockInInfo.ResumeLayout(false);
            this.gbStockInInfo.PerformLayout();
            this.gbProductInfo.ResumeLayout(false);
            this.gbProductInfo.PerformLayout();
            this.gbDetails.ResumeLayout(false);
            this.gbDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetails)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}