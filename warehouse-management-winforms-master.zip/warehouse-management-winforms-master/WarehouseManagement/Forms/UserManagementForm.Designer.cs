namespace WarehouseManagement.Forms
{
    partial class UserManagementForm
    {
        private System.ComponentModel.IContainer components = null;
        private DataGridView dgvUsers;
        private GroupBox gbUserInfo;
        private Label lblUsername;
        private TextBox txtUsername;
        private Label lblPassword;
        private TextBox txtPassword;
        private Label lblConfirmPassword;
        private TextBox txtConfirmPassword;
        private Label lblFullName;
        private TextBox txtFullName;
        private Label lblRole;
        private ComboBox cmbRole;
        private Label lblPasswordNote;
        private Button btnAdd;
        private Button btnEdit;
        private Button btnDelete;
        private Button btnCancel;
        private Button btnRefresh;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvUsers = new DataGridView();
            this.gbUserInfo = new GroupBox();
            this.lblUsername = new Label();
            this.txtUsername = new TextBox();
            this.lblPassword = new Label();
            this.txtPassword = new TextBox();
            this.lblConfirmPassword = new Label();
            this.txtConfirmPassword = new TextBox();
            this.lblFullName = new Label();
            this.txtFullName = new TextBox();
            this.lblRole = new Label();
            this.cmbRole = new ComboBox();
            this.lblPasswordNote = new Label();
            this.btnAdd = new Button();
            this.btnEdit = new Button();
            this.btnDelete = new Button();
            this.btnCancel = new Button();
            this.btnRefresh = new Button();
            
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsers)).BeginInit();
            this.gbUserInfo.SuspendLayout();
            this.SuspendLayout();
            
            // dgvUsers
            this.dgvUsers.Anchor = ((AnchorStyles)((((AnchorStyles.Top | AnchorStyles.Bottom) 
            | AnchorStyles.Left) 
            | AnchorStyles.Right)));
            this.dgvUsers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUsers.Location = new Point(12, 12);
            this.dgvUsers.Name = "dgvUsers";
            this.dgvUsers.Size = new Size(760, 300);
            this.dgvUsers.TabIndex = 0;
            this.dgvUsers.SelectionChanged += new EventHandler(this.dgvUsers_SelectionChanged);
            
            // gbUserInfo
            this.gbUserInfo.Anchor = ((AnchorStyles)(((AnchorStyles.Bottom | AnchorStyles.Left) 
            | AnchorStyles.Right)));
            this.gbUserInfo.Controls.Add(this.lblUsername);
            this.gbUserInfo.Controls.Add(this.txtUsername);
            this.gbUserInfo.Controls.Add(this.lblPassword);
            this.gbUserInfo.Controls.Add(this.txtPassword);
            this.gbUserInfo.Controls.Add(this.lblConfirmPassword);
            this.gbUserInfo.Controls.Add(this.txtConfirmPassword);
            this.gbUserInfo.Controls.Add(this.lblFullName);
            this.gbUserInfo.Controls.Add(this.txtFullName);
            this.gbUserInfo.Controls.Add(this.lblRole);
            this.gbUserInfo.Controls.Add(this.cmbRole);
            this.gbUserInfo.Controls.Add(this.lblPasswordNote);
            this.gbUserInfo.Location = new Point(12, 330);
            this.gbUserInfo.Name = "gbUserInfo";
            this.gbUserInfo.Size = new Size(760, 180);
            this.gbUserInfo.TabIndex = 1;
            this.gbUserInfo.TabStop = false;
            this.gbUserInfo.Text = "Thông tin người dùng";
            
            // lblUsername
            this.lblUsername.AutoSize = true;
            this.lblUsername.Location = new Point(20, 30);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new Size(90, 15);
            this.lblUsername.TabIndex = 0;
            this.lblUsername.Text = "Tên đăng nhập:";
            
            // txtUsername
            this.txtUsername.Location = new Point(120, 27);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new Size(200, 23);
            this.txtUsername.TabIndex = 1;
            
            // lblPassword
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new Point(20, 65);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new Size(60, 15);
            this.lblPassword.TabIndex = 2;
            this.lblPassword.Text = "Mật khẩu:";
            
            // txtPassword
            this.txtPassword.Location = new Point(120, 62);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new Size(200, 23);
            this.txtPassword.TabIndex = 3;
            
            // lblConfirmPassword
            this.lblConfirmPassword.AutoSize = true;
            this.lblConfirmPassword.Location = new Point(20, 100);
            this.lblConfirmPassword.Name = "lblConfirmPassword";
            this.lblConfirmPassword.Size = new Size(95, 15);
            this.lblConfirmPassword.TabIndex = 4;
            this.lblConfirmPassword.Text = "Xác nhận MK:";
            
            // txtConfirmPassword
            this.txtConfirmPassword.Location = new Point(120, 97);
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.PasswordChar = '*';
            this.txtConfirmPassword.Size = new Size(200, 23);
            this.txtConfirmPassword.TabIndex = 5;
            
            // lblFullName
            this.lblFullName.AutoSize = true;
            this.lblFullName.Location = new Point(400, 30);
            this.lblFullName.Name = "lblFullName";
            this.lblFullName.Size = new Size(50, 15);
            this.lblFullName.TabIndex = 6;
            this.lblFullName.Text = "Họ tên:";
            
            // txtFullName
            this.txtFullName.Location = new Point(480, 27);
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Size = new Size(250, 23);
            this.txtFullName.TabIndex = 7;
            
            // lblRole
            this.lblRole.AutoSize = true;
            this.lblRole.Location = new Point(400, 65);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new Size(50, 15);
            this.lblRole.TabIndex = 8;
            this.lblRole.Text = "Vai trò:";
            
            // cmbRole
            this.cmbRole.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbRole.Location = new Point(480, 62);
            this.cmbRole.Name = "cmbRole";
            this.cmbRole.Size = new Size(150, 23);
            this.cmbRole.TabIndex = 9;
            
            // lblPasswordNote
            this.lblPasswordNote.AutoSize = true;
            this.lblPasswordNote.Font = new Font("Microsoft Sans Serif", 8F, FontStyle.Italic);
            this.lblPasswordNote.ForeColor = Color.Gray;
            this.lblPasswordNote.Location = new Point(120, 130);
            this.lblPasswordNote.Name = "lblPasswordNote";
            this.lblPasswordNote.Size = new Size(150, 13);
            this.lblPasswordNote.TabIndex = 10;
            this.lblPasswordNote.Text = "Mật khẩu (tối thiểu 6 ký tự)";
            
            // btnAdd
            this.btnAdd.Anchor = ((AnchorStyles)((AnchorStyles.Bottom | AnchorStyles.Left)));
            this.btnAdd.Location = new Point(12, 530);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new Size(80, 30);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new EventHandler(this.btnAdd_Click);
            
            // btnEdit
            this.btnEdit.Anchor = ((AnchorStyles)((AnchorStyles.Bottom | AnchorStyles.Left)));
            this.btnEdit.Enabled = false;
            this.btnEdit.Location = new Point(110, 530);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new Size(80, 30);
            this.btnEdit.TabIndex = 3;
            this.btnEdit.Text = "Sửa";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new EventHandler(this.btnEdit_Click);
            
            // btnDelete
            this.btnDelete.Anchor = ((AnchorStyles)((AnchorStyles.Bottom | AnchorStyles.Left)));
            this.btnDelete.Enabled = false;
            this.btnDelete.Location = new Point(208, 530);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new Size(80, 30);
            this.btnDelete.TabIndex = 4;
            this.btnDelete.Text = "Xóa";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new EventHandler(this.btnDelete_Click);
            
            // btnCancel
            this.btnCancel.Anchor = ((AnchorStyles)((AnchorStyles.Bottom | AnchorStyles.Left)));
            this.btnCancel.Location = new Point(306, 530);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new Size(80, 30);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "Hủy";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new EventHandler(this.btnCancel_Click);
            
            // btnRefresh
            this.btnRefresh.Anchor = ((AnchorStyles)((AnchorStyles.Bottom | AnchorStyles.Right)));
            this.btnRefresh.Location = new Point(692, 530);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new Size(80, 30);
            this.btnRefresh.TabIndex = 6;
            this.btnRefresh.Text = "Làm mới";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new EventHandler(this.btnRefresh_Click);
            
            // UserManagementForm
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new Size(784, 581);
            this.Controls.Add(this.dgvUsers);
            this.Controls.Add(this.gbUserInfo);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnRefresh);
            this.MinimumSize = new Size(800, 620);
            this.Name = "UserManagementForm";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Quản lý người dùng";
            this.Load += new EventHandler(this.UserManagementForm_Load);
            
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsers)).EndInit();
            this.gbUserInfo.ResumeLayout(false);
            this.gbUserInfo.PerformLayout();
            this.ResumeLayout(false);
        }
    }
}