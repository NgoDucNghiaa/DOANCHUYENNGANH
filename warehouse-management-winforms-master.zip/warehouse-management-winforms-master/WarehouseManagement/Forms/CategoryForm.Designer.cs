namespace WarehouseManagement.Forms
{
    partial class CategoryForm
    {
        private System.ComponentModel.IContainer components = null;
        private Panel pnlTop;
        private Panel pnlBottom;
        private GroupBox gbInfo;
        private GroupBox gbList;
        private Label lblCategoryName;
        private Label lblDescription;
        private TextBox txtCategoryName;
        private TextBox txtDescription;
        private Button btnAdd;
        private Button btnUpdate;
        private Button btnDelete;
        private Button btnClear;
        private Button btnClose;
        private DataGridView dgvCategories;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.pnlTop = new Panel();
            this.gbInfo = new GroupBox();
            this.lblCategoryName = new Label();
            this.lblDescription = new Label();
            this.txtCategoryName = new TextBox();
            this.txtDescription = new TextBox();
            this.btnAdd = new Button();
            this.btnUpdate = new Button();
            this.btnDelete = new Button();
            this.btnClear = new Button();
            this.btnClose = new Button();
            this.pnlBottom = new Panel();
            this.gbList = new GroupBox();
            this.dgvCategories = new DataGridView();
            
            this.pnlTop.SuspendLayout();
            this.gbInfo.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.gbList.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCategories)).BeginInit();
            this.SuspendLayout();

            // pnlTop
            this.pnlTop.Controls.Add(this.gbInfo);
            this.pnlTop.Dock = DockStyle.Top;
            this.pnlTop.Location = new Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new Size(1000, 200);
            this.pnlTop.TabIndex = 0;
            this.pnlTop.BackColor = Color.FromArgb(240, 248, 255);

            // gbInfo
            this.gbInfo.Controls.Add(this.lblCategoryName);
            this.gbInfo.Controls.Add(this.txtCategoryName);
            this.gbInfo.Controls.Add(this.lblDescription);
            this.gbInfo.Controls.Add(this.txtDescription);
            this.gbInfo.Controls.Add(this.btnAdd);
            this.gbInfo.Controls.Add(this.btnUpdate);
            this.gbInfo.Controls.Add(this.btnDelete);
            this.gbInfo.Controls.Add(this.btnClear);
            this.gbInfo.Controls.Add(this.btnClose);
            this.gbInfo.Dock = DockStyle.Fill;
            this.gbInfo.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.gbInfo.ForeColor = Color.FromArgb(0, 102, 204);
            this.gbInfo.Location = new Point(10, 10);
            this.gbInfo.Margin = new Padding(10);
            this.gbInfo.Name = "gbInfo";
            this.gbInfo.Padding = new Padding(10);
            this.gbInfo.Size = new Size(980, 180);
            this.gbInfo.TabIndex = 0;
            this.gbInfo.TabStop = false;
            this.gbInfo.Text = "Thông tin danh mục";

            // lblCategoryName
            this.lblCategoryName.AutoSize = true;
            this.lblCategoryName.Font = new Font("Segoe UI", 9F);
            this.lblCategoryName.ForeColor = Color.Black;
            this.lblCategoryName.Location = new Point(20, 35);
            this.lblCategoryName.Name = "lblCategoryName";
            this.lblCategoryName.Size = new Size(90, 15);
            this.lblCategoryName.TabIndex = 0;
            this.lblCategoryName.Text = "Tên danh mục:";

            // txtCategoryName
            this.txtCategoryName.Font = new Font("Segoe UI", 9F);
            this.txtCategoryName.Location = new Point(120, 32);
            this.txtCategoryName.Name = "txtCategoryName";
            this.txtCategoryName.Size = new Size(300, 23);
            this.txtCategoryName.TabIndex = 1;

            // lblDescription
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new Font("Segoe UI", 9F);
            this.lblDescription.ForeColor = Color.Black;
            this.lblDescription.Location = new Point(20, 70);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new Size(44, 15);
            this.lblDescription.TabIndex = 2;
            this.lblDescription.Text = "Mô tả:";

            // txtDescription
            this.txtDescription.Font = new Font("Segoe UI", 9F);
            this.txtDescription.Location = new Point(120, 67);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new Size(400, 60);
            this.txtDescription.TabIndex = 3;

            // btnAdd
            this.btnAdd.BackColor = Color.FromArgb(46, 125, 50);
            this.btnAdd.FlatStyle = FlatStyle.Flat;
            this.btnAdd.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnAdd.ForeColor = Color.White;
            this.btnAdd.Location = new Point(120, 140);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new Size(80, 30);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new EventHandler(this.btnAdd_Click);

            // btnUpdate
            this.btnUpdate.BackColor = Color.FromArgb(255, 152, 0);
            this.btnUpdate.Enabled = false;
            this.btnUpdate.FlatStyle = FlatStyle.Flat;
            this.btnUpdate.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnUpdate.ForeColor = Color.White;
            this.btnUpdate.Location = new Point(210, 140);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new Size(80, 30);
            this.btnUpdate.TabIndex = 5;
            this.btnUpdate.Text = "Sửa";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new EventHandler(this.btnUpdate_Click);

            // btnDelete
            this.btnDelete.BackColor = Color.FromArgb(244, 67, 54);
            this.btnDelete.Enabled = false;
            this.btnDelete.FlatStyle = FlatStyle.Flat;
            this.btnDelete.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnDelete.ForeColor = Color.White;
            this.btnDelete.Location = new Point(300, 140);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new Size(80, 30);
            this.btnDelete.TabIndex = 6;
            this.btnDelete.Text = "Xóa";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new EventHandler(this.btnDelete_Click);

            // btnClear
            this.btnClear.BackColor = Color.FromArgb(96, 125, 139);
            this.btnClear.FlatStyle = FlatStyle.Flat;
            this.btnClear.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnClear.ForeColor = Color.White;
            this.btnClear.Location = new Point(390, 140);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new Size(80, 30);
            this.btnClear.TabIndex = 7;
            this.btnClear.Text = "Làm mới";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new EventHandler(this.btnClear_Click);

            // btnClose
            this.btnClose.BackColor = Color.FromArgb(158, 158, 158);
            this.btnClose.FlatStyle = FlatStyle.Flat;
            this.btnClose.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnClose.ForeColor = Color.White;
            this.btnClose.Location = new Point(480, 140);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new Size(80, 30);
            this.btnClose.TabIndex = 8;
            this.btnClose.Text = "Đóng";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new EventHandler(this.btnClose_Click);

            // pnlBottom
            this.pnlBottom.Controls.Add(this.gbList);
            this.pnlBottom.Dock = DockStyle.Fill;
            this.pnlBottom.Location = new Point(0, 200);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new Size(1000, 400);
            this.pnlBottom.TabIndex = 1;
            this.pnlBottom.BackColor = Color.White;

            // gbList
            this.gbList.Controls.Add(this.dgvCategories);
            this.gbList.Dock = DockStyle.Fill;
            this.gbList.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.gbList.ForeColor = Color.FromArgb(0, 102, 204);
            this.gbList.Location = new Point(10, 10);
            this.gbList.Margin = new Padding(10);
            this.gbList.Name = "gbList";
            this.gbList.Padding = new Padding(10);
            this.gbList.Size = new Size(980, 380);
            this.gbList.TabIndex = 0;
            this.gbList.TabStop = false;
            this.gbList.Text = "Danh sách danh mục";

            // dgvCategories
            this.dgvCategories.BackgroundColor = Color.White;
            this.dgvCategories.BorderStyle = BorderStyle.None;
            this.dgvCategories.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCategories.Dock = DockStyle.Fill;
            this.dgvCategories.Font = new Font("Segoe UI", 9F);
            this.dgvCategories.GridColor = Color.FromArgb(224, 224, 224);
            this.dgvCategories.Location = new Point(10, 26);
            this.dgvCategories.Name = "dgvCategories";
            this.dgvCategories.RowHeadersWidth = 51;
            this.dgvCategories.Size = new Size(960, 344);
            this.dgvCategories.TabIndex = 0;
            this.dgvCategories.SelectionChanged += new EventHandler(this.dgvCategories_SelectionChanged);

            // CategoryForm
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.White;
            this.ClientSize = new Size(1000, 600);
            this.Controls.Add(this.pnlBottom);
            this.Controls.Add(this.pnlTop);
            this.Font = new Font("Segoe UI", 9F);
            this.Name = "CategoryForm";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Quản lý danh mục sản phẩm";
            
            this.pnlTop.ResumeLayout(false);
            this.gbInfo.ResumeLayout(false);
            this.gbInfo.PerformLayout();
            this.pnlBottom.ResumeLayout(false);
            this.gbList.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCategories)).EndInit();
            this.ResumeLayout(false);
        }
    }
}