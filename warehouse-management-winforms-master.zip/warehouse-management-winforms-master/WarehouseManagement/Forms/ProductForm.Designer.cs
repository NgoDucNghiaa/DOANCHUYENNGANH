namespace WarehouseManagement.Forms
{
    partial class ProductForm
    {
        private System.ComponentModel.IContainer components = null;
        private DataGridView dgvProducts;
        private TextBox txtProductId;
        private TextBox txtProductName;
        private TextBox txtUnitPrice;
        private TextBox txtMinStock;
        private ComboBox cmbCategory;
        private ComboBox cmbUnit;
        private Button btnAdd;
        private Button btnUpdate;
        private Button btnDelete;
        private Button btnClear;
        private Label lblProductId;
        private Label lblProductName;
        private Label lblCategory;
        private Label lblUnit;
        private Label lblUnitPrice;
        private Label lblMinStock;
        private GroupBox gbProductInfo;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvProducts = new DataGridView();
            this.txtProductId = new TextBox();
            this.txtProductName = new TextBox();
            this.txtUnitPrice = new TextBox();
            this.txtMinStock = new TextBox();
            this.cmbCategory = new ComboBox();
            this.cmbUnit = new ComboBox();
            this.btnAdd = new Button();
            this.btnUpdate = new Button();
            this.btnDelete = new Button();
            this.btnClear = new Button();
            this.lblProductId = new Label();
            this.lblProductName = new Label();
            this.lblCategory = new Label();
            this.lblUnit = new Label();
            this.lblUnitPrice = new Label();
            this.lblMinStock = new Label();
            this.gbProductInfo = new GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).BeginInit();
            this.gbProductInfo.SuspendLayout();
            this.SuspendLayout();
            
            // dgvProducts
            this.dgvProducts.AllowUserToAddRows = false;
            this.dgvProducts.AllowUserToDeleteRows = false;
            this.dgvProducts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvProducts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProducts.Location = new Point(20, 20);
            this.dgvProducts.MultiSelect = false;
            this.dgvProducts.Name = "dgvProducts";
            this.dgvProducts.ReadOnly = true;
            this.dgvProducts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvProducts.Size = new Size(760, 300);
            this.dgvProducts.TabIndex = 0;
            this.dgvProducts.SelectionChanged += new EventHandler(this.dgvProducts_SelectionChanged);
            
            // gbProductInfo
            this.gbProductInfo.Controls.Add(this.lblProductId);
            this.gbProductInfo.Controls.Add(this.txtProductId);
            this.gbProductInfo.Controls.Add(this.lblProductName);
            this.gbProductInfo.Controls.Add(this.txtProductName);
            this.gbProductInfo.Controls.Add(this.lblCategory);
            this.gbProductInfo.Controls.Add(this.cmbCategory);
            this.gbProductInfo.Controls.Add(this.lblUnit);
            this.gbProductInfo.Controls.Add(this.cmbUnit);
            this.gbProductInfo.Controls.Add(this.lblUnitPrice);
            this.gbProductInfo.Controls.Add(this.txtUnitPrice);
            this.gbProductInfo.Controls.Add(this.lblMinStock);
            this.gbProductInfo.Controls.Add(this.txtMinStock);
            this.gbProductInfo.Controls.Add(this.btnAdd);
            this.gbProductInfo.Controls.Add(this.btnUpdate);
            this.gbProductInfo.Controls.Add(this.btnDelete);
            this.gbProductInfo.Controls.Add(this.btnClear);
            this.gbProductInfo.Location = new Point(20, 340);
            this.gbProductInfo.Name = "gbProductInfo";
            this.gbProductInfo.Size = new Size(760, 200);
            this.gbProductInfo.TabIndex = 1;
            this.gbProductInfo.TabStop = false;
            this.gbProductInfo.Text = "Thông tin sản phẩm";
            
            // lblProductId
            this.lblProductId.AutoSize = true;
            this.lblProductId.Location = new Point(20, 30);
            this.lblProductId.Name = "lblProductId";
            this.lblProductId.Size = new Size(85, 15);
            this.lblProductId.TabIndex = 0;
            this.lblProductId.Text = "Mã sản phẩm:";
            
            // txtProductId
            this.txtProductId.Location = new Point(120, 27);
            this.txtProductId.Name = "txtProductId";
            this.txtProductId.Size = new Size(200, 23);
            this.txtProductId.TabIndex = 1;
            
            // lblProductName
            this.lblProductName.AutoSize = true;
            this.lblProductName.Location = new Point(350, 30);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new Size(89, 15);
            this.lblProductName.TabIndex = 2;
            this.lblProductName.Text = "Tên sản phẩm:";
            
            // txtProductName
            this.txtProductName.Location = new Point(450, 27);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new Size(280, 23);
            this.txtProductName.TabIndex = 3;
            
            // lblCategory
            this.lblCategory.AutoSize = true;
            this.lblCategory.Location = new Point(20, 70);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new Size(64, 15);
            this.lblCategory.TabIndex = 4;
            this.lblCategory.Text = "Danh mục:";
            
            // cmbCategory
            this.cmbCategory.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbCategory.Location = new Point(120, 67);
            this.cmbCategory.Name = "cmbCategory";
            this.cmbCategory.Size = new Size(200, 23);
            this.cmbCategory.TabIndex = 5;
            
            // lblUnit
            this.lblUnit.AutoSize = true;
            this.lblUnit.Location = new Point(350, 70);
            this.lblUnit.Name = "lblUnit";
            this.lblUnit.Size = new Size(70, 15);
            this.lblUnit.TabIndex = 6;
            this.lblUnit.Text = "Đơn vị tính:";
            
            // cmbUnit
            this.cmbUnit.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbUnit.Location = new Point(450, 67);
            this.cmbUnit.Name = "cmbUnit";
            this.cmbUnit.Size = new Size(150, 23);
            this.cmbUnit.TabIndex = 7;
            
            // lblUnitPrice
            this.lblUnitPrice.AutoSize = true;
            this.lblUnitPrice.Location = new Point(20, 110);
            this.lblUnitPrice.Name = "lblUnitPrice";
            this.lblUnitPrice.Size = new Size(54, 15);
            this.lblUnitPrice.TabIndex = 8;
            this.lblUnitPrice.Text = "Giá bán:";
            
            // txtUnitPrice
            this.txtUnitPrice.Location = new Point(120, 107);
            this.txtUnitPrice.Name = "txtUnitPrice";
            this.txtUnitPrice.Size = new Size(200, 23);
            this.txtUnitPrice.TabIndex = 9;
            
            // lblMinStock
            this.lblMinStock.AutoSize = true;
            this.lblMinStock.Location = new Point(350, 110);
            this.lblMinStock.Name = "lblMinStock";
            this.lblMinStock.Size = new Size(94, 15);
            this.lblMinStock.TabIndex = 10;
            this.lblMinStock.Text = "Tồn kho tối thiểu:";
            
            // txtMinStock
            this.txtMinStock.Location = new Point(450, 107);
            this.txtMinStock.Name = "txtMinStock";
            this.txtMinStock.Size = new Size(150, 23);
            this.txtMinStock.TabIndex = 11;
            
            // btnAdd
            this.btnAdd.BackColor = Color.FromArgb(40, 167, 69);
            this.btnAdd.ForeColor = Color.White;
            this.btnAdd.Location = new Point(120, 150);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new Size(100, 35);
            this.btnAdd.TabIndex = 12;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new EventHandler(this.btnAdd_Click);
            
            // btnUpdate
            this.btnUpdate.BackColor = Color.FromArgb(0, 123, 255);
            this.btnUpdate.Enabled = false;
            this.btnUpdate.ForeColor = Color.White;
            this.btnUpdate.Location = new Point(240, 150);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new Size(100, 35);
            this.btnUpdate.TabIndex = 13;
            this.btnUpdate.Text = "Cập nhật";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new EventHandler(this.btnUpdate_Click);
            
            // btnDelete
            this.btnDelete.BackColor = Color.FromArgb(220, 53, 69);
            this.btnDelete.Enabled = false;
            this.btnDelete.ForeColor = Color.White;
            this.btnDelete.Location = new Point(360, 150);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new Size(100, 35);
            this.btnDelete.TabIndex = 14;
            this.btnDelete.Text = "Xóa";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new EventHandler(this.btnDelete_Click);
            
            // btnClear
            this.btnClear.BackColor = Color.FromArgb(108, 117, 125);
            this.btnClear.ForeColor = Color.White;
            this.btnClear.Location = new Point(480, 150);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new Size(100, 35);
            this.btnClear.TabIndex = 15;
            this.btnClear.Text = "Làm mới";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new EventHandler(this.btnClear_Click);
            
            // ProductForm
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new Size(800, 560);
            this.Controls.Add(this.gbProductInfo);
            this.Controls.Add(this.dgvProducts);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "ProductForm";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Quản lý sản phẩm";
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).EndInit();
            this.gbProductInfo.ResumeLayout(false);
            this.gbProductInfo.PerformLayout();
            this.ResumeLayout(false);
        }
    }
}