namespace WarehouseManagement.Forms
{
    partial class RegisterForm
    {
        private System.ComponentModel.IContainer components = null;
        private TextBox txtUsername;
        private TextBox txtPassword;
        private TextBox txtConfirmPassword;
        private TextBox txtFullName;
        private RadioButton rbAdmin;
        private RadioButton rbStaff;
        private Button btnRegister;
        private Button btnCancel;
        private Label lblUsername;
        private Label lblPassword;
        private Label lblConfirmPassword;
        private Label lblFullName;
        private Label lblRole;
        private Label lblTitle;
        private GroupBox gbRole;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtUsername = new TextBox();
            this.txtPassword = new TextBox();
            this.txtConfirmPassword = new TextBox();
            this.txtFullName = new TextBox();
            this.rbAdmin = new RadioButton();
            this.rbStaff = new RadioButton();
            this.btnRegister = new Button();
            this.btnCancel = new Button();
            this.lblUsername = new Label();
            this.lblPassword = new Label();
            this.lblConfirmPassword = new Label();
            this.lblFullName = new Label();
            this.lblRole = new Label();
            this.lblTitle = new Label();
            this.gbRole = new GroupBox();
            this.gbRole.SuspendLayout();
            this.SuspendLayout();
            
            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Bold);
            this.lblTitle.Location = new Point(120, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new Size(160, 24);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "ĐĂNG KÝ TÀI KHOẢN";
            
            // lblUsername
            this.lblUsername.AutoSize = true;
            this.lblUsername.Location = new Point(50, 70);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new Size(98, 15);
            this.lblUsername.TabIndex = 1;
            this.lblUsername.Text = "Tên đăng nhập:";
            
            // txtUsername
            this.txtUsername.Location = new Point(50, 90);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new Size(300, 23);
            this.txtUsername.TabIndex = 2;
            
            // lblFullName
            this.lblFullName.AutoSize = true;
            this.lblFullName.Location = new Point(50, 130);
            this.lblFullName.Name = "lblFullName";
            this.lblFullName.Size = new Size(58, 15);
            this.lblFullName.TabIndex = 3;
            this.lblFullName.Text = "Họ và tên:";
            
            // txtFullName
            this.txtFullName.Location = new Point(50, 150);
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Size = new Size(300, 23);
            this.txtFullName.TabIndex = 4;
            
            // lblPassword
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new Point(50, 190);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new Size(60, 15);
            this.lblPassword.TabIndex = 5;
            this.lblPassword.Text = "Mật khẩu:";
            
            // txtPassword
            this.txtPassword.Location = new Point(50, 210);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new Size(300, 23);
            this.txtPassword.TabIndex = 6;
            
            // lblConfirmPassword
            this.lblConfirmPassword.AutoSize = true;
            this.lblConfirmPassword.Location = new Point(50, 250);
            this.lblConfirmPassword.Name = "lblConfirmPassword";
            this.lblConfirmPassword.Size = new Size(107, 15);
            this.lblConfirmPassword.TabIndex = 7;
            this.lblConfirmPassword.Text = "Xác nhận mật khẩu:";
            
            // txtConfirmPassword
            this.txtConfirmPassword.Location = new Point(50, 270);
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.PasswordChar = '*';
            this.txtConfirmPassword.Size = new Size(300, 23);
            this.txtConfirmPassword.TabIndex = 8;
            
            // gbRole
            this.gbRole.Controls.Add(this.rbStaff);
            this.gbRole.Controls.Add(this.rbAdmin);
            this.gbRole.Location = new Point(50, 310);
            this.gbRole.Name = "gbRole";
            this.gbRole.Size = new Size(300, 60);
            this.gbRole.TabIndex = 9;
            this.gbRole.TabStop = false;
            this.gbRole.Text = "Vai trò";
            
            // rbStaff
            this.rbStaff.AutoSize = true;
            this.rbStaff.Checked = true;
            this.rbStaff.Location = new Point(20, 25);
            this.rbStaff.Name = "rbStaff";
            this.rbStaff.Size = new Size(79, 19);
            this.rbStaff.TabIndex = 0;
            this.rbStaff.TabStop = true;
            this.rbStaff.Text = "Nhân viên";
            this.rbStaff.UseVisualStyleBackColor = true;
            
            // rbAdmin
            this.rbAdmin.AutoSize = true;
            this.rbAdmin.Location = new Point(150, 25);
            this.rbAdmin.Name = "rbAdmin";
            this.rbAdmin.Size = new Size(86, 19);
            this.rbAdmin.TabIndex = 1;
            this.rbAdmin.Text = "Quản trị viên";
            this.rbAdmin.UseVisualStyleBackColor = true;
            
            // btnRegister
            this.btnRegister.BackColor = Color.FromArgb(40, 167, 69);
            this.btnRegister.ForeColor = Color.White;
            this.btnRegister.Location = new Point(50, 390);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new Size(140, 35);
            this.btnRegister.TabIndex = 10;
            this.btnRegister.Text = "Đăng ký";
            this.btnRegister.UseVisualStyleBackColor = false;
            this.btnRegister.Click += new EventHandler(this.btnRegister_Click);
            
            // btnCancel
            this.btnCancel.BackColor = Color.FromArgb(108, 117, 125);
            this.btnCancel.ForeColor = Color.White;
            this.btnCancel.Location = new Point(210, 390);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new Size(140, 35);
            this.btnCancel.TabIndex = 11;
            this.btnCancel.Text = "Hủy";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new EventHandler(this.btnCancel_Click);
            
            // RegisterForm
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new Size(400, 450);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.gbRole);
            this.Controls.Add(this.txtConfirmPassword);
            this.Controls.Add(this.lblConfirmPassword);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.txtFullName);
            this.Controls.Add(this.lblFullName);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.lblTitle);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "RegisterForm";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Đăng ký tài khoản";
            this.gbRole.ResumeLayout(false);
            this.gbRole.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}