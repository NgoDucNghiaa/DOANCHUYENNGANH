using System.Data.SqlClient;
using WarehouseManagement.Data;
using WarehouseManagement.Models;
using WarehouseManagement.Services;

namespace WarehouseManagement.Forms
{
    public partial class StockInForm : Form
    {
        private User currentUser;
        private List<Product>? products;
        private List<Supplier>? suppliers;
        private List<StockInDetail> stockInDetails;
        private decimal totalAmount = 0;

        public StockInForm(User user)
        {
            InitializeComponent();
            currentUser = user;
            stockInDetails = new List<StockInDetail>();
        }

        private void StockInForm_Load(object sender, EventArgs e)
        {
            LoadSuppliers();
            LoadProducts();
            GenerateStockInID();
            dtpDateImport.Value = DateTime.Now;
            lblUser.Text = $"Người nhập: {currentUser.FullName}";
            UpdateTotal();
        }

        private void LoadSuppliers()
        {
            try
            {
                var supplierService = new SupplierService();
                suppliers = supplierService.GetAllSuppliers();
                
                cmbSupplier.DisplayMember = "SupplierName";
                cmbSupplier.ValueMember = "SupplierID";
                cmbSupplier.DataSource = suppliers;
                cmbSupplier.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi tải danh sách nhà cung cấp: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadProducts()
        {
            try
            {
                var productService = new ProductService();
                products = productService.GetAllProducts();
                
                cmbProduct.DisplayMember = "ProductName";
                cmbProduct.ValueMember = "ProductID";
                cmbProduct.DataSource = products;
                cmbProduct.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi tải danh sách sản phẩm: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void GenerateStockInID()
        {
            txtStockInID.Text = "SI" + DateTime.Now.ToString("yyyyMMddHHmmss");
        }

        private void cmbProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProduct.SelectedValue != null && products != null)
            {
                var selectedProduct = products.FirstOrDefault(p => p.ProductID == cmbProduct.SelectedValue.ToString());
                if (selectedProduct != null)
                {
                    txtUnitPrice.Text = selectedProduct.UnitPrice.ToString("N0");
                }
            }
        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            CalculateAmount();
        }

        private void txtUnitPrice_TextChanged(object sender, EventArgs e)
        {
            CalculateAmount();
        }

        private void CalculateAmount()
        {
            if (decimal.TryParse(txtQuantity.Text, out decimal quantity) && 
                decimal.TryParse(txtUnitPrice.Text, out decimal unitPrice))
            {
                txtAmount.Text = (quantity * unitPrice).ToString("N0");
            }
            else
            {
                txtAmount.Text = "0";
            }
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            if (ValidateProductInput())
            {
                var detail = new StockInDetail
                {
                    StockInID = txtStockInID.Text,
                    ProductID = cmbProduct.SelectedValue?.ToString() ?? "",
                    ProductName = cmbProduct.Text,
                    Quantity = int.Parse(txtQuantity.Text),
                    UnitPrice = decimal.Parse(txtUnitPrice.Text),
                    Amount = decimal.Parse(txtAmount.Text)
                };

                // Check if product already exists in list
                var existingDetail = stockInDetails.FirstOrDefault(d => d.ProductID == detail.ProductID);
                if (existingDetail != null)
                {
                    existingDetail.Quantity += detail.Quantity;
                    existingDetail.Amount = existingDetail.Quantity * existingDetail.UnitPrice;
                }
                else
                {
                    stockInDetails.Add(detail);
                }

                RefreshDetailGrid();
                ClearProductInput();
                UpdateTotal();
            }
        }

        private bool ValidateProductInput()
        {
            if (cmbProduct.SelectedValue == null)
            {
                MessageBox.Show("Vui lòng chọn sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!int.TryParse(txtQuantity.Text, out int quantity) || quantity <= 0)
            {
                MessageBox.Show("Vui lòng nhập số lượng hợp lệ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!decimal.TryParse(txtUnitPrice.Text, out decimal unitPrice) || unitPrice <= 0)
            {
                MessageBox.Show("Vui lòng nhập đơn giá hợp lệ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private void RefreshDetailGrid()
        {
            dgvDetails.DataSource = null;
            dgvDetails.DataSource = stockInDetails.Select(d => new
            {
                d.ProductID,
                d.ProductName,
                d.Quantity,
                UnitPrice = d.UnitPrice.ToString("N0"),
                Amount = d.Amount.ToString("N0")
            }).ToList();

            dgvDetails.Columns["ProductID"].HeaderText = "Mã SP";
            dgvDetails.Columns["ProductName"].HeaderText = "Tên sản phẩm";
            dgvDetails.Columns["Quantity"].HeaderText = "Số lượng";
            dgvDetails.Columns["UnitPrice"].HeaderText = "Đơn giá";
            dgvDetails.Columns["Amount"].HeaderText = "Thành tiền";

            dgvDetails.Columns["ProductID"].Width = 80;
            dgvDetails.Columns["ProductName"].Width = 200;
            dgvDetails.Columns["Quantity"].Width = 80;
            dgvDetails.Columns["UnitPrice"].Width = 100;
            dgvDetails.Columns["Amount"].Width = 120;
        }

        private void ClearProductInput()
        {
            cmbProduct.SelectedIndex = -1;
            txtQuantity.Clear();
            txtUnitPrice.Clear();
            txtAmount.Clear();
        }

        private void UpdateTotal()
        {
            totalAmount = stockInDetails.Sum(d => d.Amount);
            lblTotal.Text = $"Tổng tiền: {totalAmount:N0} VNĐ";
        }

        private void btnRemoveProduct_Click(object sender, EventArgs e)
        {
            if (dgvDetails.SelectedRows.Count > 0)
            {
                var selectedRow = dgvDetails.SelectedRows[0];
                var productID = selectedRow.Cells["ProductID"].Value.ToString();
                
                stockInDetails.RemoveAll(d => d.ProductID == productID);
                RefreshDetailGrid();
                UpdateTotal();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateStockIn())
            {
                try
                {
                    var stockIn = new StockIn
                    {
                        StockInID = txtStockInID.Text,
                        DateImport = dtpDateImport.Value,
                        SupplierID = (int)cmbSupplier.SelectedValue,
                        UserID = currentUser.UserID,
                        TotalAmount = totalAmount,
                        Notes = txtNotes.Text
                    };

                    var stockService = new StockService();
                    if (stockService.AddStockIn(stockIn, stockInDetails))
                    {
                        MessageBox.Show("Nhập kho thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ClearForm();
                    }
                    else
                    {
                        MessageBox.Show("Có lỗi xảy ra khi nhập kho!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private bool ValidateStockIn()
        {
            if (cmbSupplier.SelectedValue == null)
            {
                MessageBox.Show("Vui lòng chọn nhà cung cấp!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (stockInDetails.Count == 0)
            {
                MessageBox.Show("Vui lòng thêm ít nhất một sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private void ClearForm()
        {
            GenerateStockInID();
            cmbSupplier.SelectedIndex = -1;
            dtpDateImport.Value = DateTime.Now;
            txtNotes.Clear();
            stockInDetails.Clear();
            RefreshDetailGrid();
            ClearProductInput();
            UpdateTotal();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}