namespace WarehouseManagement.Forms
{
    public partial class SimpleLoginForm : Form
    {
        public SimpleLoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "admin" && txtPassword.Text == "123")
            {
                MessageBox.Show("Đăng nhập thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
                SimpleMainForm mainForm = new SimpleMainForm();
                this.Hide();
                mainForm.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Sai tên đăng nhập hoặc mật khẩu!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SimpleLoginForm_Load(object sender, EventArgs e)
        {
            lblInfo.Text = "Tên đăng nhập: admin, Mật khẩu: 123";
        }
    }
}