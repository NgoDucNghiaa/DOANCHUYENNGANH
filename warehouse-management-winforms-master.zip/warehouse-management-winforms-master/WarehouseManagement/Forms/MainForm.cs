using WarehouseManagement.Models;

namespace WarehouseManagement.Forms
{
    public partial class MainForm : Form
    {
        private User currentUser;

        public MainForm(User user)
        {
            InitializeComponent();
            currentUser = user;
            SetupUserInterface();
        }

        private void SetupUserInterface()
        {
            lblWelcome.Text = $"👤 Chào mừng: {currentUser.FullName} ({currentUser.Role})";
            
            // Ẩn một số chức năng nếu không phải Admin
            if (currentUser.Role != "Admin")
            {
                btnUserManagement.Visible = false;
            }
        }

        // Hiệu ứng hover cho buttons
        private void Button_MouseEnter(object sender, EventArgs e)
        {
            if (sender is Button btn)
            {
                btn.Font = new Font(btn.Font.FontFamily, btn.Font.Size + 1, btn.Font.Style);
            }
        }

        private void Button_MouseLeave(object sender, EventArgs e)
        {
            if (sender is Button btn)
            {
                btn.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            }
        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            ProductForm productForm = new ProductForm(currentUser);
            productForm.ShowDialog();
        }

        private void btnStockIn_Click(object sender, EventArgs e)
        {
            StockInForm stockInForm = new StockInForm(currentUser);
            stockInForm.ShowDialog();
        }

        private void btnStockOut_Click(object sender, EventArgs e)
        {
            StockOutForm stockOutForm = new StockOutForm(currentUser);
            stockOutForm.ShowDialog();
        }

        private void btnInventory_Click(object sender, EventArgs e)
        {
            InventoryForm inventoryForm = new InventoryForm();
            inventoryForm.ShowDialog();
        }

        private void btnSuppliers_Click(object sender, EventArgs e)
        {
            SupplierForm supplierForm = new SupplierForm();
            supplierForm.ShowDialog();
        }

        private void btnCustomers_Click(object sender, EventArgs e)
        {
            CustomerForm customerForm = new CustomerForm();
            customerForm.ShowDialog();
        }

        private void btnCategories_Click(object sender, EventArgs e)
        {
            CategoryForm categoryForm = new CategoryForm();
            categoryForm.ShowDialog();
        }

        private void btnUserManagement_Click(object sender, EventArgs e)
        {
            if (currentUser.Role == "Admin")
            {
                UserManagementForm userForm = new UserManagementForm();
                userForm.ShowDialog();
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn đăng xuất?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}