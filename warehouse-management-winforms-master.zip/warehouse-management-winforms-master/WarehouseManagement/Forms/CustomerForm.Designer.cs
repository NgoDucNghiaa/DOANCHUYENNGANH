namespace WarehouseManagement.Forms
{
    partial class CustomerForm
    {
        private System.ComponentModel.IContainer components = null;
        private DataGridView dgvCustomers;
        private GroupBox gbCustomerInfo;
        private Label lblCustomerName;
        private TextBox txtCustomerName;
        private Label lblPhone;
        private TextBox txtPhone;
        private Label lblEmail;
        private TextBox txtEmail;
        private Label lblAddress;
        private TextBox txtAddress;
        private Button btnAdd;
        private Button btnUpdate;
        private Button btnDelete;
        private Button btnClear;
        private Button btnClose;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvCustomers = new DataGridView();
            this.gbCustomerInfo = new GroupBox();
            this.lblCustomerName = new Label();
            this.txtCustomerName = new TextBox();
            this.lblPhone = new Label();
            this.txtPhone = new TextBox();
            this.lblEmail = new Label();
            this.txtEmail = new TextBox();
            this.lblAddress = new Label();
            this.txtAddress = new TextBox();
            this.btnAdd = new Button();
            this.btnUpdate = new Button();
            this.btnDelete = new Button();
            this.btnClear = new Button();
            this.btnClose = new Button();
            
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomers)).BeginInit();
            this.gbCustomerInfo.SuspendLayout();
            this.SuspendLayout();
            
            // dgvCustomers
            this.dgvCustomers.Anchor = ((AnchorStyles)((((AnchorStyles.Top | AnchorStyles.Bottom) 
            | AnchorStyles.Left) 
            | AnchorStyles.Right)));
            this.dgvCustomers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustomers.Location = new Point(12, 12);
            this.dgvCustomers.Name = "dgvCustomers";
            this.dgvCustomers.Size = new Size(760, 300);
            this.dgvCustomers.TabIndex = 0;
            this.dgvCustomers.SelectionChanged += new EventHandler(this.dgvCustomers_SelectionChanged);
            
            // gbCustomerInfo
            this.gbCustomerInfo.Anchor = ((AnchorStyles)(((AnchorStyles.Bottom | AnchorStyles.Left) 
            | AnchorStyles.Right)));
            this.gbCustomerInfo.Controls.Add(this.lblCustomerName);
            this.gbCustomerInfo.Controls.Add(this.txtCustomerName);
            this.gbCustomerInfo.Controls.Add(this.lblPhone);
            this.gbCustomerInfo.Controls.Add(this.txtPhone);
            this.gbCustomerInfo.Controls.Add(this.lblEmail);
            this.gbCustomerInfo.Controls.Add(this.txtEmail);
            this.gbCustomerInfo.Controls.Add(this.lblAddress);
            this.gbCustomerInfo.Controls.Add(this.txtAddress);
            this.gbCustomerInfo.Location = new Point(12, 330);
            this.gbCustomerInfo.Name = "gbCustomerInfo";
            this.gbCustomerInfo.Size = new Size(760, 150);
            this.gbCustomerInfo.TabIndex = 1;
            this.gbCustomerInfo.TabStop = false;
            this.gbCustomerInfo.Text = "Thông tin khách hàng";
            
            // lblCustomerName
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Location = new Point(20, 30);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new Size(100, 15);
            this.lblCustomerName.TabIndex = 0;
            this.lblCustomerName.Text = "Tên khách hàng:";
            
            // txtCustomerName
            this.txtCustomerName.Location = new Point(130, 27);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new Size(250, 23);
            this.txtCustomerName.TabIndex = 1;
            
            // lblPhone
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new Point(400, 30);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new Size(70, 15);
            this.lblPhone.TabIndex = 2;
            this.lblPhone.Text = "Điện thoại:";
            
            // txtPhone
            this.txtPhone.Location = new Point(480, 27);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new Size(200, 23);
            this.txtPhone.TabIndex = 3;
            
            // lblEmail
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new Point(20, 70);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new Size(39, 15);
            this.lblEmail.TabIndex = 4;
            this.lblEmail.Text = "Email:";
            
            // txtEmail
            this.txtEmail.Location = new Point(130, 67);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new Size(250, 23);
            this.txtEmail.TabIndex = 5;
            
            // lblAddress
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new Point(400, 70);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new Size(50, 15);
            this.lblAddress.TabIndex = 6;
            this.lblAddress.Text = "Địa chỉ:";
            
            // txtAddress
            this.txtAddress.Location = new Point(480, 67);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new Size(250, 60);
            this.txtAddress.TabIndex = 7;
            
            // btnAdd
            this.btnAdd.Anchor = ((AnchorStyles)((AnchorStyles.Bottom | AnchorStyles.Left)));
            this.btnAdd.BackColor = Color.FromArgb(40, 167, 69);
            this.btnAdd.ForeColor = Color.White;
            this.btnAdd.Location = new Point(12, 500);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new Size(80, 30);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new EventHandler(this.btnAdd_Click);
            
            // btnUpdate
            this.btnUpdate.Anchor = ((AnchorStyles)((AnchorStyles.Bottom | AnchorStyles.Left)));
            this.btnUpdate.BackColor = Color.FromArgb(0, 123, 255);
            this.btnUpdate.Enabled = false;
            this.btnUpdate.ForeColor = Color.White;
            this.btnUpdate.Location = new Point(110, 500);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new Size(80, 30);
            this.btnUpdate.TabIndex = 3;
            this.btnUpdate.Text = "Sửa";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new EventHandler(this.btnUpdate_Click);
            
            // btnDelete
            this.btnDelete.Anchor = ((AnchorStyles)((AnchorStyles.Bottom | AnchorStyles.Left)));
            this.btnDelete.BackColor = Color.FromArgb(220, 53, 69);
            this.btnDelete.Enabled = false;
            this.btnDelete.ForeColor = Color.White;
            this.btnDelete.Location = new Point(208, 500);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new Size(80, 30);
            this.btnDelete.TabIndex = 4;
            this.btnDelete.Text = "Xóa";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new EventHandler(this.btnDelete_Click);
            
            // btnClear
            this.btnClear.Anchor = ((AnchorStyles)((AnchorStyles.Bottom | AnchorStyles.Left)));
            this.btnClear.BackColor = Color.FromArgb(108, 117, 125);
            this.btnClear.ForeColor = Color.White;
            this.btnClear.Location = new Point(306, 500);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new Size(80, 30);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Làm mới";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new EventHandler(this.btnClear_Click);
            
            // btnClose
            this.btnClose.Anchor = ((AnchorStyles)((AnchorStyles.Bottom | AnchorStyles.Right)));
            this.btnClose.BackColor = Color.FromArgb(108, 117, 125);
            this.btnClose.ForeColor = Color.White;
            this.btnClose.Location = new Point(692, 500);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new Size(80, 30);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "Đóng";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new EventHandler(this.btnClose_Click);
            
            // CustomerForm
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new Size(784, 561);
            this.Controls.Add(this.dgvCustomers);
            this.Controls.Add(this.gbCustomerInfo);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnClose);
            this.MinimumSize = new Size(800, 600);
            this.Name = "CustomerForm";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Quản lý khách hàng";
            this.Load += new EventHandler(this.CustomerForm_Load);
            
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomers)).EndInit();
            this.gbCustomerInfo.ResumeLayout(false);
            this.gbCustomerInfo.PerformLayout();
            this.ResumeLayout(false);
        }

        private void CustomerForm_Load(object sender, EventArgs e)
        {
            // This method is called when form loads
        }
    }
}