namespace WarehouseManagement.Forms
{
    partial class SimpleLoginForm
    {
        private System.ComponentModel.IContainer components = null;
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Button btnLogin;
        private Label lblUsername;
        private Label lblPassword;
        private Label lblTitle;
        private Label lblInfo;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtUsername = new TextBox();
            this.txtPassword = new TextBox();
            this.btnLogin = new Button();
            this.lblUsername = new Label();
            this.lblPassword = new Label();
            this.lblTitle = new Label();
            this.lblInfo = new Label();
            this.SuspendLayout();
            
            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Bold);
            this.lblTitle.ForeColor = Color.Blue;
            this.lblTitle.Location = new Point(80, 30);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new Size(240, 26);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "QUẢN LÝ KHO HÀNG";
            
            // lblInfo
            this.lblInfo.AutoSize = true;
            this.lblInfo.ForeColor = Color.Red;
            this.lblInfo.Location = new Point(50, 70);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new Size(200, 15);
            this.lblInfo.TabIndex = 1;
            this.lblInfo.Text = "Thông tin đăng nhập...";
            
            // lblUsername
            this.lblUsername.AutoSize = true;
            this.lblUsername.Location = new Point(50, 110);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new Size(98, 15);
            this.lblUsername.TabIndex = 2;
            this.lblUsername.Text = "Tên đăng nhập:";
            
            // txtUsername
            this.txtUsername.Location = new Point(50, 130);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new Size(300, 23);
            this.txtUsername.TabIndex = 3;
            this.txtUsername.Text = "admin";
            
            // lblPassword
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new Point(50, 170);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new Size(60, 15);
            this.lblPassword.TabIndex = 4;
            this.lblPassword.Text = "Mật khẩu:";
            
            // txtPassword
            this.txtPassword.Location = new Point(50, 190);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new Size(300, 23);
            this.txtPassword.TabIndex = 5;
            this.txtPassword.Text = "123";
            
            // btnLogin
            this.btnLogin.BackColor = Color.FromArgb(0, 123, 255);
            this.btnLogin.ForeColor = Color.White;
            this.btnLogin.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold);
            this.btnLogin.Location = new Point(125, 240);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new Size(150, 40);
            this.btnLogin.TabIndex = 6;
            this.btnLogin.Text = "ĐĂNG NHẬP";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new EventHandler(this.btnLogin_Click);
            
            // SimpleLoginForm
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.LightBlue;
            this.ClientSize = new Size(400, 320);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.lblTitle);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "SimpleLoginForm";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Đăng nhập - Quản lý kho hàng";
            this.Load += new EventHandler(this.SimpleLoginForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}