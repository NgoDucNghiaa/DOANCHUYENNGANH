using WarehouseManagement.Services;

namespace WarehouseManagement.Forms
{
    public partial class InventoryForm : Form
    {
        private InventoryService inventoryService;

        public InventoryForm()
        {
            InitializeComponent();
            inventoryService = new InventoryService();
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                dgvInventory.DataSource = inventoryService.GetAllInventories();
                
                // Highlight low stock items
                foreach (DataGridViewRow row in dgvInventory.Rows)
                {
                    if (row.Cells["Quantity"].Value != null && row.Cells["MinStock"].Value != null)
                    {
                        int quantity = Convert.ToInt32(row.Cells["Quantity"].Value);
                        int minStock = Convert.ToInt32(row.Cells["MinStock"].Value);
                        
                        if (quantity <= minStock)
                        {
                            row.DefaultCellStyle.BackColor = Color.LightCoral;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi tải dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnLowStock_Click(object sender, EventArgs e)
        {
            try
            {
                dgvInventory.DataSource = inventoryService.GetLowStockProducts();
                
                foreach (DataGridViewRow row in dgvInventory.Rows)
                {
                    row.DefaultCellStyle.BackColor = Color.LightCoral;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi tải dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}