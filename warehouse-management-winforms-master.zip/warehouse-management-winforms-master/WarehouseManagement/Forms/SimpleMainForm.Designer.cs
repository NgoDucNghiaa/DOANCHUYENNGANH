namespace WarehouseManagement.Forms
{
    partial class SimpleMainForm
    {
        private System.ComponentModel.IContainer components = null;
        private Button btnProducts;
        private Button btnInventory;
        private Button btnStockIn;
        private Button btnStockOut;
        private Button btnLogout;
        private Label lblTitle;
        private Label lblWelcome;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnProducts = new Button();
            this.btnInventory = new Button();
            this.btnStockIn = new Button();
            this.btnStockOut = new Button();
            this.btnLogout = new Button();
            this.lblTitle = new Label();
            this.lblWelcome = new Label();
            this.SuspendLayout();
            
            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            this.lblTitle.ForeColor = Color.Blue;
            this.lblTitle.Location = new Point(200, 30);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new Size(300, 29);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "HỆ THỐNG QUẢN LÝ KHO";
            
            // lblWelcome
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new Font("Microsoft Sans Serif", 12F);
            this.lblWelcome.Location = new Point(50, 80);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new Size(200, 20);
            this.lblWelcome.TabIndex = 1;
            this.lblWelcome.Text = "Chào mừng bạn đến với hệ thống!";
            
            // btnProducts
            this.btnProducts.BackColor = Color.FromArgb(0, 123, 255);
            this.btnProducts.ForeColor = Color.White;
            this.btnProducts.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold);
            this.btnProducts.Location = new Point(100, 150);
            this.btnProducts.Name = "btnProducts";
            this.btnProducts.Size = new Size(180, 60);
            this.btnProducts.TabIndex = 2;
            this.btnProducts.Text = "QUẢN LÝ SẢN PHẨM";
            this.btnProducts.UseVisualStyleBackColor = false;
            this.btnProducts.Click += new EventHandler(this.btnProducts_Click);
            
            // btnInventory
            this.btnInventory.BackColor = Color.FromArgb(40, 167, 69);
            this.btnInventory.ForeColor = Color.White;
            this.btnInventory.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold);
            this.btnInventory.Location = new Point(320, 150);
            this.btnInventory.Name = "btnInventory";
            this.btnInventory.Size = new Size(180, 60);
            this.btnInventory.TabIndex = 3;
            this.btnInventory.Text = "QUẢN LÝ TỒN KHO";
            this.btnInventory.UseVisualStyleBackColor = false;
            this.btnInventory.Click += new EventHandler(this.btnInventory_Click);
            
            // btnStockIn
            this.btnStockIn.BackColor = Color.FromArgb(255, 193, 7);
            this.btnStockIn.ForeColor = Color.Black;
            this.btnStockIn.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold);
            this.btnStockIn.Location = new Point(100, 240);
            this.btnStockIn.Name = "btnStockIn";
            this.btnStockIn.Size = new Size(180, 60);
            this.btnStockIn.TabIndex = 4;
            this.btnStockIn.Text = "NHẬP KHO";
            this.btnStockIn.UseVisualStyleBackColor = false;
            this.btnStockIn.Click += new EventHandler(this.btnStockIn_Click);
            
            // btnStockOut
            this.btnStockOut.BackColor = Color.FromArgb(220, 53, 69);
            this.btnStockOut.ForeColor = Color.White;
            this.btnStockOut.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold);
            this.btnStockOut.Location = new Point(320, 240);
            this.btnStockOut.Name = "btnStockOut";
            this.btnStockOut.Size = new Size(180, 60);
            this.btnStockOut.TabIndex = 5;
            this.btnStockOut.Text = "XUẤT KHO";
            this.btnStockOut.UseVisualStyleBackColor = false;
            this.btnStockOut.Click += new EventHandler(this.btnStockOut_Click);
            
            // btnLogout
            this.btnLogout.BackColor = Color.FromArgb(108, 117, 125);
            this.btnLogout.ForeColor = Color.White;
            this.btnLogout.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold);
            this.btnLogout.Location = new Point(500, 350);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new Size(100, 40);
            this.btnLogout.TabIndex = 6;
            this.btnLogout.Text = "ĐĂNG XUẤT";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new EventHandler(this.btnLogout_Click);
            
            // SimpleMainForm
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.LightGray;
            this.ClientSize = new Size(700, 450);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnStockOut);
            this.Controls.Add(this.btnStockIn);
            this.Controls.Add(this.btnInventory);
            this.Controls.Add(this.btnProducts);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.lblTitle);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "SimpleMainForm";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Hệ thống quản lý kho hàng - Demo";
            this.FormClosing += new FormClosingEventHandler(this.SimpleMainForm_FormClosing);
            this.Load += new EventHandler(this.SimpleMainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}