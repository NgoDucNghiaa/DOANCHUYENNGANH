namespace WarehouseManagement.Forms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private Button btnProducts;
        private Button btnStockIn;
        private Button btnStockOut;
        private Button btnInventory;
        private Button btnSuppliers;
        private Button btnCustomers;
        private Button btnCategories;
        private Button btnUserManagement;
        private Button btnLogout;
        private Label lblWelcome;
        private Label lblTitle;
        private Panel panelMenu;
        private Panel panelHeader;
        private Panel panelFooter;
        private Label lblSubtitle;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnProducts = new Button();
            this.btnStockIn = new Button();
            this.btnStockOut = new Button();
            this.btnInventory = new Button();
            this.btnSuppliers = new Button();
            this.btnCustomers = new Button();
            this.btnCategories = new Button();
            this.btnUserManagement = new Button();
            this.btnLogout = new Button();
            this.lblWelcome = new Label();
            this.lblTitle = new Label();
            this.lblSubtitle = new Label();
            this.panelMenu = new Panel();
            this.panelHeader = new Panel();
            this.panelFooter = new Panel();
            this.panelHeader.SuspendLayout();
            this.panelMenu.SuspendLayout();
            this.panelFooter.SuspendLayout();
            this.SuspendLayout();
            
            // panelHeader
            this.panelHeader.BackColor = Color.FromArgb(52, 58, 64);
            this.panelHeader.Controls.Add(this.lblTitle);
            this.panelHeader.Controls.Add(this.lblSubtitle);
            this.panelHeader.Controls.Add(this.lblWelcome);
            this.panelHeader.Dock = DockStyle.Top;
            this.panelHeader.Location = new Point(0, 0);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new Size(1000, 120);
            this.panelHeader.TabIndex = 0;
            
            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            this.lblTitle.ForeColor = Color.White;
            this.lblTitle.Location = new Point(50, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new Size(450, 45);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "🏢 HỆ THỐNG QUẢN LÝ KHO";
            
            // lblSubtitle
            this.lblSubtitle.AutoSize = true;
            this.lblSubtitle.Font = new Font("Segoe UI", 12F);
            this.lblSubtitle.ForeColor = Color.FromArgb(173, 181, 189);
            this.lblSubtitle.Location = new Point(50, 70);
            this.lblSubtitle.Name = "lblSubtitle";
            this.lblSubtitle.Size = new Size(300, 21);
            this.lblSubtitle.TabIndex = 1;
            this.lblSubtitle.Text = "Quản lý hiệu quả - Kiểm soát chính xác";
            
            // lblWelcome
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new Font("Segoe UI", 11F);
            this.lblWelcome.ForeColor = Color.FromArgb(255, 193, 7);
            this.lblWelcome.Location = new Point(700, 45);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new Size(200, 20);
            this.lblWelcome.TabIndex = 2;
            this.lblWelcome.Text = "👤 Chào mừng: [Tên người dùng]";
            
            // panelMenu
            this.panelMenu.BackColor = Color.FromArgb(248, 249, 250);
            this.panelMenu.Controls.Add(this.btnProducts);
            this.panelMenu.Controls.Add(this.btnStockIn);
            this.panelMenu.Controls.Add(this.btnStockOut);
            this.panelMenu.Controls.Add(this.btnInventory);
            this.panelMenu.Controls.Add(this.btnSuppliers);
            this.panelMenu.Controls.Add(this.btnCustomers);
            this.panelMenu.Controls.Add(this.btnCategories);
            this.panelMenu.Controls.Add(this.btnUserManagement);
            this.panelMenu.Dock = DockStyle.Fill;
            this.panelMenu.Location = new Point(0, 120);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Padding = new Padding(50, 40, 50, 40);
            this.panelMenu.Size = new Size(1000, 480);
            this.panelMenu.TabIndex = 1;
            
            // btnProducts
            this.btnProducts.BackColor = Color.FromArgb(0, 123, 255);
            this.btnProducts.FlatAppearance.BorderSize = 0;
            this.btnProducts.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 86, 179);
            this.btnProducts.FlatStyle = FlatStyle.Flat;
            this.btnProducts.ForeColor = Color.White;
            this.btnProducts.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            this.btnProducts.Location = new Point(80, 60);
            this.btnProducts.Name = "btnProducts";
            this.btnProducts.Size = new Size(180, 80);
            this.btnProducts.TabIndex = 0;
            this.btnProducts.Text = "📦 QUẢN LÝ\nSẢN PHẨM";
            this.btnProducts.UseVisualStyleBackColor = false;
            this.btnProducts.Click += new EventHandler(this.btnProducts_Click);
            this.btnProducts.MouseEnter += new EventHandler(this.Button_MouseEnter);
            this.btnProducts.MouseLeave += new EventHandler(this.Button_MouseLeave);
            
            // btnStockIn
            this.btnStockIn.BackColor = Color.FromArgb(40, 167, 69);
            this.btnStockIn.FlatAppearance.BorderSize = 0;
            this.btnStockIn.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 136, 56);
            this.btnStockIn.FlatStyle = FlatStyle.Flat;
            this.btnStockIn.ForeColor = Color.White;
            this.btnStockIn.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            this.btnStockIn.Location = new Point(290, 60);
            this.btnStockIn.Name = "btnStockIn";
            this.btnStockIn.Size = new Size(180, 80);
            this.btnStockIn.TabIndex = 1;
            this.btnStockIn.Text = "📥 NHẬP KHO";
            this.btnStockIn.UseVisualStyleBackColor = false;
            this.btnStockIn.Click += new EventHandler(this.btnStockIn_Click);
            this.btnStockIn.MouseEnter += new EventHandler(this.Button_MouseEnter);
            this.btnStockIn.MouseLeave += new EventHandler(this.Button_MouseLeave);
            
            // btnStockOut
            this.btnStockOut.BackColor = Color.FromArgb(220, 53, 69);
            this.btnStockOut.FlatAppearance.BorderSize = 0;
            this.btnStockOut.FlatAppearance.MouseOverBackColor = Color.FromArgb(200, 35, 51);
            this.btnStockOut.FlatStyle = FlatStyle.Flat;
            this.btnStockOut.ForeColor = Color.White;
            this.btnStockOut.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            this.btnStockOut.Location = new Point(500, 60);
            this.btnStockOut.Name = "btnStockOut";
            this.btnStockOut.Size = new Size(180, 80);
            this.btnStockOut.TabIndex = 2;
            this.btnStockOut.Text = "📤 XUẤT KHO";
            this.btnStockOut.UseVisualStyleBackColor = false;
            this.btnStockOut.Click += new EventHandler(this.btnStockOut_Click);
            this.btnStockOut.MouseEnter += new EventHandler(this.Button_MouseEnter);
            this.btnStockOut.MouseLeave += new EventHandler(this.Button_MouseLeave);
            
            // btnInventory
            this.btnInventory.BackColor = Color.FromArgb(255, 193, 7);
            this.btnInventory.FlatAppearance.BorderSize = 0;
            this.btnInventory.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 173, 0);
            this.btnInventory.FlatStyle = FlatStyle.Flat;
            this.btnInventory.ForeColor = Color.Black;
            this.btnInventory.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            this.btnInventory.Location = new Point(710, 60);
            this.btnInventory.Name = "btnInventory";
            this.btnInventory.Size = new Size(180, 80);
            this.btnInventory.TabIndex = 3;
            this.btnInventory.Text = "📊 TỒN KHO";
            this.btnInventory.UseVisualStyleBackColor = false;
            this.btnInventory.Click += new EventHandler(this.btnInventory_Click);
            this.btnInventory.MouseEnter += new EventHandler(this.Button_MouseEnter);
            this.btnInventory.MouseLeave += new EventHandler(this.Button_MouseLeave);
            
            // btnSuppliers
            this.btnSuppliers.BackColor = Color.FromArgb(23, 162, 184);
            this.btnSuppliers.FlatAppearance.BorderSize = 0;
            this.btnSuppliers.FlatAppearance.MouseOverBackColor = Color.FromArgb(19, 132, 150);
            this.btnSuppliers.FlatStyle = FlatStyle.Flat;
            this.btnSuppliers.ForeColor = Color.White;
            this.btnSuppliers.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            this.btnSuppliers.Location = new Point(80, 170);
            this.btnSuppliers.Name = "btnSuppliers";
            this.btnSuppliers.Size = new Size(180, 80);
            this.btnSuppliers.TabIndex = 4;
            this.btnSuppliers.Text = "🏭 NHÀ CUNG CẤP";
            this.btnSuppliers.UseVisualStyleBackColor = false;
            this.btnSuppliers.Click += new EventHandler(this.btnSuppliers_Click);
            this.btnSuppliers.MouseEnter += new EventHandler(this.Button_MouseEnter);
            this.btnSuppliers.MouseLeave += new EventHandler(this.Button_MouseLeave);
            
            // btnCustomers
            this.btnCustomers.BackColor = Color.FromArgb(108, 117, 125);
            this.btnCustomers.FlatAppearance.BorderSize = 0;
            this.btnCustomers.FlatAppearance.MouseOverBackColor = Color.FromArgb(90, 98, 104);
            this.btnCustomers.FlatStyle = FlatStyle.Flat;
            this.btnCustomers.ForeColor = Color.White;
            this.btnCustomers.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            this.btnCustomers.Location = new Point(290, 170);
            this.btnCustomers.Name = "btnCustomers";
            this.btnCustomers.Size = new Size(180, 80);
            this.btnCustomers.TabIndex = 5;
            this.btnCustomers.Text = "👥 KHÁCH HÀNG";
            this.btnCustomers.UseVisualStyleBackColor = false;
            this.btnCustomers.Click += new EventHandler(this.btnCustomers_Click);
            this.btnCustomers.MouseEnter += new EventHandler(this.Button_MouseEnter);
            this.btnCustomers.MouseLeave += new EventHandler(this.Button_MouseLeave);
            
            // btnCategories
            this.btnCategories.BackColor = Color.FromArgb(111, 66, 193);
            this.btnCategories.FlatAppearance.BorderSize = 0;
            this.btnCategories.FlatAppearance.MouseOverBackColor = Color.FromArgb(95, 56, 165);
            this.btnCategories.FlatStyle = FlatStyle.Flat;
            this.btnCategories.ForeColor = Color.White;
            this.btnCategories.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            this.btnCategories.Location = new Point(500, 170);
            this.btnCategories.Name = "btnCategories";
            this.btnCategories.Size = new Size(180, 80);
            this.btnCategories.TabIndex = 6;
            this.btnCategories.Text = "🏷️ DANH MỤC";
            this.btnCategories.UseVisualStyleBackColor = false;
            this.btnCategories.Click += new EventHandler(this.btnCategories_Click);
            this.btnCategories.MouseEnter += new EventHandler(this.Button_MouseEnter);
            this.btnCategories.MouseLeave += new EventHandler(this.Button_MouseLeave);
            
            // btnUserManagement
            this.btnUserManagement.BackColor = Color.FromArgb(220, 53, 69);
            this.btnUserManagement.FlatAppearance.BorderSize = 0;
            this.btnUserManagement.FlatAppearance.MouseOverBackColor = Color.FromArgb(200, 35, 51);
            this.btnUserManagement.FlatStyle = FlatStyle.Flat;
            this.btnUserManagement.ForeColor = Color.White;
            this.btnUserManagement.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            this.btnUserManagement.Location = new Point(710, 170);
            this.btnUserManagement.Name = "btnUserManagement";
            this.btnUserManagement.Size = new Size(180, 80);
            this.btnUserManagement.TabIndex = 7;
            this.btnUserManagement.Text = "⚙️ QUẢN LÝ\nNGƯỜI DÙNG";
            this.btnUserManagement.UseVisualStyleBackColor = false;
            this.btnUserManagement.Click += new EventHandler(this.btnUserManagement_Click);
            this.btnUserManagement.MouseEnter += new EventHandler(this.Button_MouseEnter);
            this.btnUserManagement.MouseLeave += new EventHandler(this.Button_MouseLeave);
            
            // panelFooter
            this.panelFooter.BackColor = Color.FromArgb(52, 58, 64);
            this.panelFooter.Controls.Add(this.btnLogout);
            this.panelFooter.Dock = DockStyle.Bottom;
            this.panelFooter.Location = new Point(0, 600);
            this.panelFooter.Name = "panelFooter";
            this.panelFooter.Size = new Size(1000, 80);
            this.panelFooter.TabIndex = 2;
            
            // btnLogout
            this.btnLogout.BackColor = Color.FromArgb(220, 53, 69);
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatAppearance.MouseOverBackColor = Color.FromArgb(200, 35, 51);
            this.btnLogout.FlatStyle = FlatStyle.Flat;
            this.btnLogout.ForeColor = Color.White;
            this.btnLogout.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            this.btnLogout.Location = new Point(850, 20);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new Size(120, 40);
            this.btnLogout.TabIndex = 0;
            this.btnLogout.Text = "🚪 ĐĂNG XUẤT";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new EventHandler(this.btnLogout_Click);
            this.btnLogout.MouseEnter += new EventHandler(this.Button_MouseEnter);
            this.btnLogout.MouseLeave += new EventHandler(this.Button_MouseLeave);
            
            // MainForm
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.White;
            this.ClientSize = new Size(1000, 680);
            this.Controls.Add(this.panelMenu);
            this.Controls.Add(this.panelHeader);
            this.Controls.Add(this.panelFooter);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "🏢 Hệ thống quản lý kho hàng";
            this.FormClosing += new FormClosingEventHandler(this.MainForm_FormClosing);
            this.panelHeader.ResumeLayout(false);
            this.panelHeader.PerformLayout();
            this.panelMenu.ResumeLayout(false);
            this.panelFooter.ResumeLayout(false);
            this.ResumeLayout(false);
        }
    }
}