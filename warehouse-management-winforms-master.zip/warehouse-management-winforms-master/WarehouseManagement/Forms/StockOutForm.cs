using System.Data.SqlClient;
using WarehouseManagement.Data;
using WarehouseManagement.Models;
using WarehouseManagement.Services;

namespace WarehouseManagement.Forms
{
    public partial class StockOutForm : Form
    {
        private User currentUser;
        private List<Product>? products;
        private List<Customer>? customers;
        private List<StockOutDetail> stockOutDetails;
        private decimal totalAmount = 0;

        public StockOutForm(User user)
        {
            InitializeComponent();
            currentUser = user;
            stockOutDetails = new List<StockOutDetail>();
        }

        private void StockOutForm_Load(object sender, EventArgs e)
        {
            LoadCustomers();
            LoadProducts();
            GenerateStockOutID();
            dtpDateExport.Value = DateTime.Now;
            lblUser.Text = $"Người xuất: {currentUser.FullName}";
            UpdateTotal();
        }

        private void LoadCustomers()
        {
            try
            {
                var customerService = new CustomerService();
                customers = customerService.GetAllCustomers();
                
                cmbCustomer.DisplayMember = "CustomerName";
                cmbCustomer.ValueMember = "CustomerID";
                cmbCustomer.DataSource = customers;
                cmbCustomer.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi tải danh sách khách hàng: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadProducts()
        {
            try
            {
                var productService = new ProductService();
                products = productService.GetAllProducts();
                
                cmbProduct.DisplayMember = "ProductName";
                cmbProduct.ValueMember = "ProductID";
                cmbProduct.DataSource = products;
                cmbProduct.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi tải danh sách sản phẩm: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void GenerateStockOutID()
        {
            txtStockOutID.Text = "SO" + DateTime.Now.ToString("yyyyMMddHHmmss");
        }

        private void cmbProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProduct.SelectedValue != null)
            {
                var selectedProduct = products.FirstOrDefault(p => p.ProductID == cmbProduct.SelectedValue.ToString());
                if (selectedProduct != null)
                {
                    txtUnitPrice.Text = selectedProduct.UnitPrice.ToString("N0");
                    LoadAvailableStock(selectedProduct.ProductID);
                }
            }
        }

        private void LoadAvailableStock(string productID)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    string query = "SELECT ISNULL(Quantity, 0) FROM Inventories WHERE ProductID = @ProductID";
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ProductID", productID);
                        var result = command.ExecuteScalar();
                        int availableStock = result != null ? (int)result : 0;
                        lblAvailableStock.Text = $"Tồn kho: {availableStock}";
                        lblAvailableStock.ForeColor = availableStock > 0 ? Color.Green : Color.Red;
                    }
                }
            }
            catch (Exception ex)
            {
                lblAvailableStock.Text = "Tồn kho: 0";
                lblAvailableStock.ForeColor = Color.Red;
            }
        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            CalculateAmount();
        }

        private void txtUnitPrice_TextChanged(object sender, EventArgs e)
        {
            CalculateAmount();
        }

        private void CalculateAmount()
        {
            if (decimal.TryParse(txtQuantity.Text, out decimal quantity) && 
                decimal.TryParse(txtUnitPrice.Text, out decimal unitPrice))
            {
                txtAmount.Text = (quantity * unitPrice).ToString("N0");
            }
            else
            {
                txtAmount.Text = "0";
            }
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            if (ValidateProductInput())
            {
                var detail = new StockOutDetail
                {
                    StockOutID = txtStockOutID.Text,
                    ProductID = cmbProduct.SelectedValue.ToString(),
                    ProductName = cmbProduct.Text,
                    Quantity = int.Parse(txtQuantity.Text),
                    UnitPrice = decimal.Parse(txtUnitPrice.Text),
                    Amount = decimal.Parse(txtAmount.Text)
                };

                // Check if product already exists in list
                var existingDetail = stockOutDetails.FirstOrDefault(d => d.ProductID == detail.ProductID);
                if (existingDetail != null)
                {
                    existingDetail.Quantity += detail.Quantity;
                    existingDetail.Amount = existingDetail.Quantity * existingDetail.UnitPrice;
                }
                else
                {
                    stockOutDetails.Add(detail);
                }

                RefreshDetailGrid();
                ClearProductInput();
                UpdateTotal();
            }
        }

        private bool ValidateProductInput()
        {
            if (cmbProduct.SelectedValue == null)
            {
                MessageBox.Show("Vui lòng chọn sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!int.TryParse(txtQuantity.Text, out int quantity) || quantity <= 0)
            {
                MessageBox.Show("Vui lòng nhập số lượng hợp lệ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // Check available stock
            int availableStock = GetAvailableStock(cmbProduct.SelectedValue.ToString());
            int totalRequestedQuantity = quantity;
            
            // Add existing quantity in the list for the same product
            var existingDetail = stockOutDetails.FirstOrDefault(d => d.ProductID == cmbProduct.SelectedValue.ToString());
            if (existingDetail != null)
            {
                totalRequestedQuantity += existingDetail.Quantity;
            }

            if (totalRequestedQuantity > availableStock)
            {
                MessageBox.Show($"Số lượng xuất ({totalRequestedQuantity}) vượt quá tồn kho ({availableStock})!", 
                    "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!decimal.TryParse(txtUnitPrice.Text, out decimal unitPrice) || unitPrice <= 0)
            {
                MessageBox.Show("Vui lòng nhập đơn giá hợp lệ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private int GetAvailableStock(string productID)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    string query = "SELECT ISNULL(Quantity, 0) FROM Inventories WHERE ProductID = @ProductID";
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ProductID", productID);
                        var result = command.ExecuteScalar();
                        return result != null ? (int)result : 0;
                    }
                }
            }
            catch
            {
                return 0;
            }
        }

        private void RefreshDetailGrid()
        {
            dgvDetails.DataSource = null;
            dgvDetails.DataSource = stockOutDetails.Select(d => new
            {
                d.ProductID,
                d.ProductName,
                d.Quantity,
                UnitPrice = d.UnitPrice.ToString("N0"),
                Amount = d.Amount.ToString("N0")
            }).ToList();

            dgvDetails.Columns["ProductID"].HeaderText = "Mã SP";
            dgvDetails.Columns["ProductName"].HeaderText = "Tên sản phẩm";
            dgvDetails.Columns["Quantity"].HeaderText = "Số lượng";
            dgvDetails.Columns["UnitPrice"].HeaderText = "Đơn giá";
            dgvDetails.Columns["Amount"].HeaderText = "Thành tiền";

            dgvDetails.Columns["ProductID"].Width = 80;
            dgvDetails.Columns["ProductName"].Width = 200;
            dgvDetails.Columns["Quantity"].Width = 80;
            dgvDetails.Columns["UnitPrice"].Width = 100;
            dgvDetails.Columns["Amount"].Width = 120;
        }

        private void ClearProductInput()
        {
            cmbProduct.SelectedIndex = -1;
            txtQuantity.Clear();
            txtUnitPrice.Clear();
            txtAmount.Clear();
            lblAvailableStock.Text = "Tồn kho: 0";
        }

        private void UpdateTotal()
        {
            totalAmount = stockOutDetails.Sum(d => d.Amount);
            lblTotal.Text = $"Tổng tiền: {totalAmount:N0} VNĐ";
        }

        private void btnRemoveProduct_Click(object sender, EventArgs e)
        {
            if (dgvDetails.SelectedRows.Count > 0)
            {
                var selectedRow = dgvDetails.SelectedRows[0];
                var productID = selectedRow.Cells["ProductID"].Value.ToString();
                
                stockOutDetails.RemoveAll(d => d.ProductID == productID);
                RefreshDetailGrid();
                UpdateTotal();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateStockOut())
            {
                try
                {
                    var stockOut = new StockOut
                    {
                        StockOutID = txtStockOutID.Text,
                        DateExport = dtpDateExport.Value,
                        CustomerID = (int)cmbCustomer.SelectedValue,
                        UserID = currentUser.UserID,
                        TotalAmount = totalAmount,
                        Notes = txtNotes.Text
                    };

                    var stockService = new StockService();
                    if (stockService.AddStockOut(stockOut, stockOutDetails))
                    {
                        MessageBox.Show("Xuất kho thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ClearForm();
                    }
                    else
                    {
                        MessageBox.Show("Có lỗi xảy ra khi xuất kho!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private bool ValidateStockOut()
        {
            if (cmbCustomer.SelectedValue == null)
            {
                MessageBox.Show("Vui lòng chọn khách hàng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (stockOutDetails.Count == 0)
            {
                MessageBox.Show("Vui lòng thêm ít nhất một sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // Final stock validation
            foreach (var detail in stockOutDetails)
            {
                int availableStock = GetAvailableStock(detail.ProductID);
                if (detail.Quantity > availableStock)
                {
                    MessageBox.Show($"Sản phẩm {detail.ProductName} không đủ tồn kho để xuất!", 
                        "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }

            return true;
        }

        private void ClearForm()
        {
            GenerateStockOutID();
            cmbCustomer.SelectedIndex = -1;
            dtpDateExport.Value = DateTime.Now;
            txtNotes.Clear();
            stockOutDetails.Clear();
            RefreshDetailGrid();
            ClearProductInput();
            UpdateTotal();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}