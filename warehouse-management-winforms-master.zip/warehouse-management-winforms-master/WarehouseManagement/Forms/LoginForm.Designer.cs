namespace WarehouseManagement.Forms
{
    partial class LoginForm
    {
        private System.ComponentModel.IContainer components = null;
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Button btnLogin;
        private Button btnRegister;
        private Button btnResetAdmin;
        private Label lblUsername;
        private Label lblPassword;
        private Label lblTitle;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtUsername = new TextBox();
            this.txtPassword = new TextBox();
            this.btnLogin = new Button();
            this.btnRegister = new Button();
            this.btnResetAdmin = new Button();
            this.lblUsername = new Label();
            this.lblPassword = new Label();
            this.lblTitle = new Label();
            this.SuspendLayout();
            
            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Bold);
            this.lblTitle.Location = new Point(80, 30);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new Size(240, 26);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "QUẢN LÝ KHO HÀNG";
            
            // lblUsername
            this.lblUsername.AutoSize = true;
            this.lblUsername.Location = new Point(50, 80);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new Size(98, 15);
            this.lblUsername.TabIndex = 1;
            this.lblUsername.Text = "Tên đăng nhập:";
            
            // txtUsername
            this.txtUsername.Location = new Point(50, 100);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new Size(300, 23);
            this.txtUsername.TabIndex = 2;
            
            // lblPassword
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new Point(50, 140);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new Size(60, 15);
            this.lblPassword.TabIndex = 3;
            this.lblPassword.Text = "Mật khẩu:";
            
            // txtPassword
            this.txtPassword.Location = new Point(50, 160);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new Size(300, 23);
            this.txtPassword.TabIndex = 4;
            
            // btnLogin
            this.btnLogin.BackColor = Color.FromArgb(0, 123, 255);
            this.btnLogin.ForeColor = Color.White;
            this.btnLogin.Location = new Point(50, 210);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new Size(140, 35);
            this.btnLogin.TabIndex = 5;
            this.btnLogin.Text = "Đăng nhập";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new EventHandler(this.btnLogin_Click);
            
            // btnRegister
            this.btnRegister.BackColor = Color.FromArgb(40, 167, 69);
            this.btnRegister.ForeColor = Color.White;
            this.btnRegister.Location = new Point(210, 210);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new Size(140, 35);
            this.btnRegister.TabIndex = 6;
            this.btnRegister.Text = "Đăng ký";
            this.btnRegister.UseVisualStyleBackColor = false;
            this.btnRegister.Click += new EventHandler(this.btnRegister_Click);
            
            // btnResetAdmin
            this.btnResetAdmin.BackColor = Color.FromArgb(220, 53, 69);
            this.btnResetAdmin.ForeColor = Color.White;
            this.btnResetAdmin.Location = new Point(130, 260);
            this.btnResetAdmin.Name = "btnResetAdmin";
            this.btnResetAdmin.Size = new Size(140, 30);
            this.btnResetAdmin.TabIndex = 7;
            this.btnResetAdmin.Text = "Reset Admin Password";
            this.btnResetAdmin.UseVisualStyleBackColor = false;
            this.btnResetAdmin.Click += new EventHandler(this.btnResetAdmin_Click);
            
            // LoginForm
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new Size(400, 320);
            this.Controls.Add(this.btnResetAdmin);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.lblTitle);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "LoginForm";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Đăng nhập - Quản lý kho hàng";
            this.Load += new EventHandler(this.LoginForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}