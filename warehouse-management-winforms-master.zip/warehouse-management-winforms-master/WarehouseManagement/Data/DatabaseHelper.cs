using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

namespace WarehouseManagement.Data
{
    public static class DatabaseHelper
    {
        private static string connectionString = "Server=.;Database=WarehouseManagement;Integrated Security=true;TrustServerCertificate=true;";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }

        public static string HashPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        public static bool TestConnection()
        {
            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        public static bool CreateDatabaseAndTables()
        {
            try
            {
                // Create database
                string masterConnString = "Server=.;Database=master;Integrated Security=true;TrustServerCertificate=true;";
                using (var connection = new SqlConnection(masterConnString))
                {
                    connection.Open();
                    
                    string checkDb = "SELECT COUNT(*) FROM sys.databases WHERE name = 'WarehouseManagement'";
                    using (var cmd = new SqlCommand(checkDb, connection))
                    {
                        if ((int)cmd.ExecuteScalar() == 0)
                        {
                            string createDb = "CREATE DATABASE WarehouseManagement";
                            using (var createCmd = new SqlCommand(createDb, connection))
                            {
                                createCmd.ExecuteNonQuery();
                            }
                        }
                    }
                }

                // Create tables
                using (var connection = GetConnection())
                {
                    connection.Open();
                    
                    string createTables = @"
                        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Users' AND xtype='U')
                        CREATE TABLE Users (
                            UserID INT PRIMARY KEY IDENTITY(1,1),
                            Username VARCHAR(50) UNIQUE NOT NULL,
                            Password VARCHAR(255) NOT NULL,
                            FullName NVARCHAR(100),
                            Role NVARCHAR(50) DEFAULT 'Staff'
                        );

                        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Categories' AND xtype='U')
                        CREATE TABLE Categories (
                            CategoryID INT PRIMARY KEY IDENTITY(1,1),
                            CategoryName NVARCHAR(100) NOT NULL,
                            Description NVARCHAR(500)
                        );

                        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Units' AND xtype='U')
                        CREATE TABLE Units (
                            UnitID INT PRIMARY KEY IDENTITY(1,1),
                            UnitName NVARCHAR(50) NOT NULL
                        );

                        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Products' AND xtype='U')
                        CREATE TABLE Products (
                            ProductID NVARCHAR(50) PRIMARY KEY,
                            ProductName NVARCHAR(200) NOT NULL,
                            CategoryID INT,
                            UnitID INT,
                            UnitPrice DECIMAL(18, 2) DEFAULT 0,
                            MinStock INT DEFAULT 0,
                            IsActive BIT DEFAULT 1
                        );

                        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Suppliers' AND xtype='U')
                        CREATE TABLE Suppliers (
                            SupplierID INT PRIMARY KEY IDENTITY(1,1),
                            SupplierName NVARCHAR(200) NOT NULL,
                            Phone NVARCHAR(20),
                            Email NVARCHAR(100),
                            Address NVARCHAR(500)
                        );

                        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Customers' AND xtype='U')
                        CREATE TABLE Customers (
                            CustomerID INT PRIMARY KEY IDENTITY(1,1),
                            CustomerName NVARCHAR(200) NOT NULL,
                            Phone NVARCHAR(20),
                            Email NVARCHAR(100),
                            Address NVARCHAR(500)
                        );

                        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='StockIns' AND xtype='U')
                        CREATE TABLE StockIns (
                            StockInID NVARCHAR(50) PRIMARY KEY,
                            DateImport DATETIME DEFAULT GETDATE(),
                            SupplierID INT,
                            UserID INT,
                            TotalAmount DECIMAL(18, 2) DEFAULT 0,
                            Notes NVARCHAR(500)
                        );

                        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='StockInDetails' AND xtype='U')
                        CREATE TABLE StockInDetails (
                            StockInID NVARCHAR(50),
                            ProductID NVARCHAR(50),
                            Quantity INT,
                            UnitPrice DECIMAL(18, 2),
                            Amount DECIMAL(18, 2)
                        );

                        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='StockOuts' AND xtype='U')
                        CREATE TABLE StockOuts (
                            StockOutID NVARCHAR(50) PRIMARY KEY,
                            DateExport DATETIME DEFAULT GETDATE(),
                            CustomerID INT,
                            UserID INT,
                            TotalAmount DECIMAL(18, 2) DEFAULT 0,
                            Notes NVARCHAR(500)
                        );

                        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='StockOutDetails' AND xtype='U')
                        CREATE TABLE StockOutDetails (
                            StockOutID NVARCHAR(50),
                            ProductID NVARCHAR(50),
                            Quantity INT,
                            UnitPrice DECIMAL(18, 2),
                            Amount DECIMAL(18, 2)
                        );

                        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Inventories' AND xtype='U')
                        CREATE TABLE Inventories (
                            ProductID NVARCHAR(50) PRIMARY KEY,
                            Quantity INT DEFAULT 0,
                            LastUpdated DATETIME DEFAULT GETDATE()
                        );
                    ";

                    using (var cmd = new SqlCommand(createTables, connection))
                    {
                        cmd.ExecuteNonQuery();
                    }

                    // Insert sample data
                    string sampleData = @"
                        IF NOT EXISTS (SELECT * FROM Users WHERE Username = 'admin')
                            INSERT INTO Users (Username, Password, FullName, Role) 
                            VALUES ('admin', 'admin123', N'Administrator', 'Admin');

                        IF NOT EXISTS (SELECT * FROM Categories WHERE CategoryName = N'Điện tử')
                            INSERT INTO Categories (CategoryName, Description) VALUES (N'Điện tử', N'Các sản phẩm điện tử');

                        IF NOT EXISTS (SELECT * FROM Units WHERE UnitName = N'Cái')
                            INSERT INTO Units (UnitName) VALUES (N'Cái');
                    ";

                    using (var cmd = new SqlCommand(sampleData, connection))
                    {
                        cmd.ExecuteNonQuery();
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Database Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        // Method để reset password admin nếu cần
        public static bool ResetAdminPassword()
        {
            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    
                    // Xóa user admin cũ nếu có
                    string deleteQuery = "DELETE FROM Users WHERE Username = 'admin'";
                    using (var deleteCommand = new SqlCommand(deleteQuery, connection))
                    {
                        deleteCommand.ExecuteNonQuery();
                    }
                    
                    // Tạo lại user admin với password mới (không hash)
                    string insertQuery = "INSERT INTO Users (Username, Password, FullName, Role) VALUES (@username, @password, @fullName, @role)";
                    using (var command = new SqlCommand(insertQuery, connection))
                    {
                        command.Parameters.AddWithValue("@username", "admin");
                        command.Parameters.AddWithValue("@password", "admin123"); // Không hash nữa
                        command.Parameters.AddWithValue("@fullName", "Administrator");
                        command.Parameters.AddWithValue("@role", "Admin");
                        
                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch
            {
                return false;
            }
        }
    }
}