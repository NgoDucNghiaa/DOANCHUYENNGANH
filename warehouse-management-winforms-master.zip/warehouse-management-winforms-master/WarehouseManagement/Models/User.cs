namespace WarehouseManagement.Models
{
    public class User
    {
        public int UserID { get; set; }
        public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public string Role { get; set; } = "Staff";
    }

    public class Category
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; } = string.Empty;
        public string? Description { get; set; }
    }

    public class Unit
    {
        public int UnitID { get; set; }
        public string UnitName { get; set; } = string.Empty;
    }

    public class Supplier
    {
        public int SupplierID { get; set; }
        public string SupplierName { get; set; } = string.Empty;
        public string? Phone { get; set; }
        public string? Email { get; set; }
        public string? Address { get; set; }
    }

    public class Customer
    {
        public int CustomerID { get; set; }
        public string CustomerName { get; set; } = string.Empty;
        public string? Phone { get; set; }
        public string? Email { get; set; }
        public string? Address { get; set; }
    }

    public class Product
    {
        public string ProductID { get; set; } = string.Empty;
        public string ProductName { get; set; } = string.Empty;
        public int CategoryID { get; set; }
        public int UnitID { get; set; }
        public decimal UnitPrice { get; set; }
        public int MinStock { get; set; }
        public bool IsActive { get; set; } = true;
        
        // Navigation properties
        public string? CategoryName { get; set; }
        public string? UnitName { get; set; }
    }

    public class StockIn
    {
        public string StockInID { get; set; } = string.Empty;
        public DateTime DateImport { get; set; }
        public int SupplierID { get; set; }
        public int UserID { get; set; }
        public decimal TotalAmount { get; set; }
        public string? Notes { get; set; }
        
        // Navigation properties
        public string? SupplierName { get; set; }
        public string? UserName { get; set; }
    }

    public class StockOut
    {
        public string StockOutID { get; set; } = string.Empty;
        public DateTime DateExport { get; set; }
        public int CustomerID { get; set; }
        public int UserID { get; set; }
        public decimal TotalAmount { get; set; }
        public string? Notes { get; set; }
        
        // Navigation properties
        public string? CustomerName { get; set; }
        public string? UserName { get; set; }
    }

    public class Inventory
    {
        public string ProductID { get; set; } = string.Empty;
        public string ProductName { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public DateTime LastUpdated { get; set; }
        public int MinStock { get; set; }
        public string UnitName { get; set; } = string.Empty;
    }

    public class StockInDetail
    {
        public string StockInID { get; set; } = string.Empty;
        public string ProductID { get; set; } = string.Empty;
        public string ProductName { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Amount { get; set; }
    }

    public class StockOutDetail
    {
        public string StockOutID { get; set; } = string.Empty;
        public string ProductID { get; set; } = string.Empty;
        public string ProductName { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Amount { get; set; }
    }
}