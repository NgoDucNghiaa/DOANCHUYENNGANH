using System.Data.SqlClient;
using WarehouseManagement.Data;
using WarehouseManagement.Models;

namespace WarehouseManagement.Services
{
    public class SupplierService
    {
        public List<Supplier> GetAllSuppliers()
        {
            List<Supplier> suppliers = new List<Supplier>();
            
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = @"SELECT SupplierID, SupplierName, 
                                ISNULL(Phone, '') as Phone, 
                                ISNULL(Email, '') as Email, 
                                ISNULL(Address, '') as Address 
                                FROM Suppliers ORDER BY SupplierName";
                
                using (var command = new SqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        suppliers.Add(new Supplier
                        {
                            SupplierID = (int)reader["SupplierID"],
                            SupplierName = (string)reader["SupplierName"],
                            Phone = (string)reader["Phone"],
                            Email = (string)reader["Email"],
                            Address = (string)reader["Address"]
                        });
                    }
                }
            }
            return suppliers;
        }

        public bool AddSupplier(Supplier supplier)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    string query = @"INSERT INTO Suppliers (SupplierName, Phone, Email, Address)
                                    VALUES (@supplierName, @phone, @email, @address)";
                    
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@supplierName", supplier.SupplierName);
                        command.Parameters.AddWithValue("@phone", supplier.Phone ?? "");
                        command.Parameters.AddWithValue("@email", supplier.Email ?? "");
                        command.Parameters.AddWithValue("@address", supplier.Address ?? "");
                        
                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public bool UpdateSupplier(Supplier supplier)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    string query = @"UPDATE Suppliers SET SupplierName = @supplierName, 
                                    Phone = @phone, Email = @email, Address = @address
                                    WHERE SupplierID = @supplierId";
                    
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@supplierId", supplier.SupplierID);
                        command.Parameters.AddWithValue("@supplierName", supplier.SupplierName);
                        command.Parameters.AddWithValue("@phone", supplier.Phone ?? "");
                        command.Parameters.AddWithValue("@email", supplier.Email ?? "");
                        command.Parameters.AddWithValue("@address", supplier.Address ?? "");
                        
                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteSupplier(int supplierId)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    string query = "DELETE FROM Suppliers WHERE SupplierID = @supplierId";
                    
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@supplierId", supplierId);
                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public bool IsSupplierNameExists(string supplierName, int excludeId = 0)
        {
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM Suppliers WHERE SupplierName = @supplierName AND SupplierID != @excludeId";
                
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@supplierName", supplierName);
                    command.Parameters.AddWithValue("@excludeId", excludeId);
                    return (int)command.ExecuteScalar() > 0;
                }
            }
        }
    }
}