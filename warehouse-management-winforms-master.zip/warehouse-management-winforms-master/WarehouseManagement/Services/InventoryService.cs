using System.Data.SqlClient;
using WarehouseManagement.Data;
using WarehouseManagement.Models;

namespace WarehouseManagement.Services
{
    public class InventoryService
    {
        public List<Inventory> GetAllInventories()
        {
            List<Inventory> inventories = new List<Inventory>();
            
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = @"SELECT i.ProductID, p.ProductName, i.Quantity, i.LastUpdated, 
                                p.MinStock, ISNULL(u.UnitName, '') as UnitName
                                FROM Inventories i
                                INNER JOIN Products p ON i.ProductID = p.ProductID
                                LEFT JOIN Units u ON p.UnitID = u.UnitID
                                WHERE p.IsActive = 1
                                ORDER BY p.ProductName";
                
                using (var command = new SqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        inventories.Add(new Inventory
                        {
                            ProductID = (string)reader["ProductID"],
                            ProductName = (string)reader["ProductName"],
                            Quantity = (int)reader["Quantity"],
                            LastUpdated = (DateTime)reader["LastUpdated"],
                            MinStock = (int)reader["MinStock"],
                            UnitName = (string)reader["UnitName"]
                        });
                    }
                }
            }
            return inventories;
        }

        public List<Inventory> GetLowStockProducts()
        {
            List<Inventory> lowStockProducts = new List<Inventory>();
            
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = @"SELECT i.ProductID, p.ProductName, i.Quantity, i.LastUpdated, 
                                p.MinStock, ISNULL(u.UnitName, '') as UnitName
                                FROM Inventories i
                                INNER JOIN Products p ON i.ProductID = p.ProductID
                                LEFT JOIN Units u ON p.UnitID = u.UnitID
                                WHERE p.IsActive = 1 AND i.Quantity <= p.MinStock
                                ORDER BY i.Quantity ASC";
                
                using (var command = new SqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        lowStockProducts.Add(new Inventory
                        {
                            ProductID = (string)reader["ProductID"],
                            ProductName = (string)reader["ProductName"],
                            Quantity = (int)reader["Quantity"],
                            LastUpdated = (DateTime)reader["LastUpdated"],
                            MinStock = (int)reader["MinStock"],
                            UnitName = (string)reader["UnitName"]
                        });
                    }
                }
            }
            return lowStockProducts;
        }

        public bool UpdateInventory(string productId, int quantity)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    string query = @"UPDATE Inventories SET Quantity = @quantity, LastUpdated = GETDATE() 
                                    WHERE ProductID = @productId";
                    
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@productId", productId);
                        command.Parameters.AddWithValue("@quantity", quantity);
                        
                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public int GetCurrentStock(string productId)
        {
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = "SELECT ISNULL(Quantity, 0) FROM Inventories WHERE ProductID = @productId";
                
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@productId", productId);
                    object result = command.ExecuteScalar();
                    return result != null ? (int)result : 0;
                }
            }
        }
    }
}