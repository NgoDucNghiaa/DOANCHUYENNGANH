using System.Data.SqlClient;
using WarehouseManagement.Data;
using WarehouseManagement.Models;

namespace WarehouseManagement.Services
{
    public class CategoryService
    {
        public List<Category> GetAllCategories()
        {
            List<Category> categories = new List<Category>();
            
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = @"SELECT CategoryID, CategoryName, 
                                ISNULL(Description, '') as Description 
                                FROM Categories ORDER BY CategoryName";
                
                using (var command = new SqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        categories.Add(new Category
                        {
                            CategoryID = (int)reader["CategoryID"],
                            CategoryName = (string)reader["CategoryName"],
                            Description = (string)reader["Description"]
                        });
                    }
                }
            }
            return categories;
        }

        public bool AddCategory(Category category)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    string query = @"INSERT INTO Categories (CategoryName, Description)
                                    VALUES (@categoryName, @description)";
                    
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@categoryName", category.CategoryName);
                        command.Parameters.AddWithValue("@description", category.Description ?? "");
                        
                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public bool UpdateCategory(Category category)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    string query = @"UPDATE Categories SET CategoryName = @categoryName, 
                                    Description = @description
                                    WHERE CategoryID = @categoryId";
                    
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@categoryId", category.CategoryID);
                        command.Parameters.AddWithValue("@categoryName", category.CategoryName);
                        command.Parameters.AddWithValue("@description", category.Description ?? "");
                        
                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteCategory(int categoryId)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    
                    // Kiểm tra xem có sản phẩm nào đang sử dụng category này không
                    string checkQuery = "SELECT COUNT(*) FROM Products WHERE CategoryID = @categoryId";
                    using (var checkCmd = new SqlCommand(checkQuery, connection))
                    {
                        checkCmd.Parameters.AddWithValue("@categoryId", categoryId);
                        int productCount = (int)checkCmd.ExecuteScalar();
                        
                        if (productCount > 0)
                        {
                            return false; // Không thể xóa vì có sản phẩm đang sử dụng
                        }
                    }
                    
                    string query = "DELETE FROM Categories WHERE CategoryID = @categoryId";
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@categoryId", categoryId);
                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public bool IsCategoryNameExists(string categoryName, int excludeId = 0)
        {
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM Categories WHERE CategoryName = @categoryName AND CategoryID != @excludeId";
                
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@categoryName", categoryName);
                    command.Parameters.AddWithValue("@excludeId", excludeId);
                    return (int)command.ExecuteScalar() > 0;
                }
            }
        }
    }
}