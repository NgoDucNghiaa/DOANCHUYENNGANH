using System.Data.SqlClient;
using WarehouseManagement.Data;
using WarehouseManagement.Models;

namespace WarehouseManagement.Services
{
    public class CustomerService
    {
        public List<Customer> GetAllCustomers()
        {
            List<Customer> customers = new List<Customer>();
            
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = @"SELECT CustomerID, CustomerName, 
                                ISNULL(Phone, '') as Phone, 
                                ISNULL(Email, '') as Email, 
                                ISNULL(Address, '') as Address 
                                FROM Customers ORDER BY CustomerName";
                
                using (var command = new SqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        customers.Add(new Customer
                        {
                            CustomerID = (int)reader["CustomerID"],
                            CustomerName = (string)reader["CustomerName"],
                            Phone = (string)reader["Phone"],
                            Email = (string)reader["Email"],
                            Address = (string)reader["Address"]
                        });
                    }
                }
            }
            return customers;
        }

        public bool AddCustomer(Customer customer)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    string query = @"INSERT INTO Customers (CustomerName, Phone, Email, Address)
                                    VALUES (@customerName, @phone, @email, @address)";
                    
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@customerName", customer.CustomerName);
                        command.Parameters.AddWithValue("@phone", customer.Phone ?? "");
                        command.Parameters.AddWithValue("@email", customer.Email ?? "");
                        command.Parameters.AddWithValue("@address", customer.Address ?? "");
                        
                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public bool UpdateCustomer(Customer customer)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    string query = @"UPDATE Customers SET CustomerName = @customerName, 
                                    Phone = @phone, Email = @email, Address = @address
                                    WHERE CustomerID = @customerId";
                    
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@customerId", customer.CustomerID);
                        command.Parameters.AddWithValue("@customerName", customer.CustomerName);
                        command.Parameters.AddWithValue("@phone", customer.Phone ?? "");
                        command.Parameters.AddWithValue("@email", customer.Email ?? "");
                        command.Parameters.AddWithValue("@address", customer.Address ?? "");
                        
                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteCustomer(int customerId)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    string query = "DELETE FROM Customers WHERE CustomerID = @customerId";
                    
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@customerId", customerId);
                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public bool IsCustomerNameExists(string customerName, int excludeId = 0)
        {
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM Customers WHERE CustomerName = @customerName AND CustomerID != @excludeId";
                
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@customerName", customerName);
                    command.Parameters.AddWithValue("@excludeId", excludeId);
                    return (int)command.ExecuteScalar() > 0;
                }
            }
        }
    }
}