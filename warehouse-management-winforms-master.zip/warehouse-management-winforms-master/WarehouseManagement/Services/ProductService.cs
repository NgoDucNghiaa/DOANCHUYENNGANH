using System.Data.SqlClient;
using WarehouseManagement.Data;
using WarehouseManagement.Models;

namespace WarehouseManagement.Services
{
    public class ProductService
    {
        public List<Product> GetAllProducts()
        {
            List<Product> products = new List<Product>();
            
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = @"SELECT p.ProductID, p.ProductName, p.CategoryID, p.UnitID, 
                                p.UnitPrice, p.MinStock, p.IsActive,
                                ISNULL(c.CategoryName, '') as CategoryName, 
                                ISNULL(u.UnitName, '') as UnitName
                                FROM Products p
                                LEFT JOIN Categories c ON p.CategoryID = c.CategoryID
                                LEFT JOIN Units u ON p.UnitID = u.UnitID
                                WHERE p.IsActive = 1";
                
                using (var command = new SqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        products.Add(new Product
                        {
                            ProductID = (string)reader["ProductID"],
                            ProductName = (string)reader["ProductName"],
                            CategoryID = (int)reader["CategoryID"],
                            UnitID = (int)reader["UnitID"],
                            UnitPrice = (decimal)reader["UnitPrice"],
                            MinStock = (int)reader["MinStock"],
                            IsActive = (bool)reader["IsActive"],
                            CategoryName = (string)reader["CategoryName"],
                            UnitName = (string)reader["UnitName"]
                        });
                    }
                }
            }
            return products;
        }

        public bool AddProduct(Product product)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    using (var transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Thêm sản phẩm
                            string query = @"INSERT INTO Products (ProductID, ProductName, CategoryID, UnitID, UnitPrice, MinStock, IsActive)
                                            VALUES (@productId, @productName, @categoryId, @unitId, @unitPrice, @minStock, @isActive)";
                            
                            using (var command = new SqlCommand(query, connection, transaction))
                            {
                                command.Parameters.AddWithValue("@productId", product.ProductID);
                                command.Parameters.AddWithValue("@productName", product.ProductName);
                                command.Parameters.AddWithValue("@categoryId", product.CategoryID);
                                command.Parameters.AddWithValue("@unitId", product.UnitID);
                                command.Parameters.AddWithValue("@unitPrice", product.UnitPrice);
                                command.Parameters.AddWithValue("@minStock", product.MinStock);
                                command.Parameters.AddWithValue("@isActive", product.IsActive);
                                
                                command.ExecuteNonQuery();
                            }
                            
                            // Thêm vào bảng Inventories
                            string inventoryQuery = "INSERT INTO Inventories (ProductID, Quantity) VALUES (@productId, 0)";
                            using (var invCommand = new SqlCommand(inventoryQuery, connection, transaction))
                            {
                                invCommand.Parameters.AddWithValue("@productId", product.ProductID);
                                invCommand.ExecuteNonQuery();
                            }
                            
                            transaction.Commit();
                            return true;
                        }
                        catch
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public bool UpdateProduct(Product product)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    string query = @"UPDATE Products SET ProductName = @productName, CategoryID = @categoryId, 
                                    UnitID = @unitId, UnitPrice = @unitPrice, MinStock = @minStock, IsActive = @isActive
                                    WHERE ProductID = @productId";
                    
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@productId", product.ProductID);
                        command.Parameters.AddWithValue("@productName", product.ProductName);
                        command.Parameters.AddWithValue("@categoryId", product.CategoryID);
                        command.Parameters.AddWithValue("@unitId", product.UnitID);
                        command.Parameters.AddWithValue("@unitPrice", product.UnitPrice);
                        command.Parameters.AddWithValue("@minStock", product.MinStock);
                        command.Parameters.AddWithValue("@isActive", product.IsActive);
                        
                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public bool IsProductIdExists(string productId)
        {
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM Products WHERE ProductID = @productId";
                
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@productId", productId);
                    return (int)command.ExecuteScalar() > 0;
                }
            }
        }

        public List<Category> GetAllCategories()
        {
            List<Category> categories = new List<Category>();
            
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = "SELECT CategoryID, CategoryName, ISNULL(Description, '') as Description FROM Categories";
                
                using (var command = new SqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        categories.Add(new Category
                        {
                            CategoryID = (int)reader["CategoryID"],
                            CategoryName = (string)reader["CategoryName"],
                            Description = (string)reader["Description"]
                        });
                    }
                }
            }
            return categories;
        }

        public List<Unit> GetAllUnits()
        {
            List<Unit> units = new List<Unit>();
            
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = "SELECT UnitID, UnitName FROM Units";
                
                using (var command = new SqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        units.Add(new Unit
                        {
                            UnitID = (int)reader["UnitID"],
                            UnitName = (string)reader["UnitName"]
                        });
                    }
                }
            }
            return units;
        }

        public bool DeleteProduct(string productId)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    using (var transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Kiểm tra xem sản phẩm có đang được sử dụng trong giao dịch không
                            string checkQuery = @"SELECT COUNT(*) FROM 
                                                (SELECT ProductID FROM StockInDetails WHERE ProductID = @productId
                                                 UNION ALL
                                                 SELECT ProductID FROM StockOutDetails WHERE ProductID = @productId) AS UsedProducts";
                            
                            using (var checkCommand = new SqlCommand(checkQuery, connection, transaction))
                            {
                                checkCommand.Parameters.AddWithValue("@productId", productId);
                                int usageCount = (int)checkCommand.ExecuteScalar();
                                
                                if (usageCount > 0)
                                {
                                    // Nếu sản phẩm đã được sử dụng, chỉ đánh dấu IsActive = false
                                    string deactivateQuery = "UPDATE Products SET IsActive = 0 WHERE ProductID = @productId";
                                    using (var deactivateCommand = new SqlCommand(deactivateQuery, connection, transaction))
                                    {
                                        deactivateCommand.Parameters.AddWithValue("@productId", productId);
                                        deactivateCommand.ExecuteNonQuery();
                                    }
                                }
                                else
                                {
                                    // Nếu sản phẩm chưa được sử dụng, xóa hoàn toàn
                                    // Xóa từ Inventories trước
                                    string deleteInventoryQuery = "DELETE FROM Inventories WHERE ProductID = @productId";
                                    using (var deleteInvCommand = new SqlCommand(deleteInventoryQuery, connection, transaction))
                                    {
                                        deleteInvCommand.Parameters.AddWithValue("@productId", productId);
                                        deleteInvCommand.ExecuteNonQuery();
                                    }
                                    
                                    // Xóa sản phẩm
                                    string deleteProductQuery = "DELETE FROM Products WHERE ProductID = @productId";
                                    using (var deleteCommand = new SqlCommand(deleteProductQuery, connection, transaction))
                                    {
                                        deleteCommand.Parameters.AddWithValue("@productId", productId);
                                        deleteCommand.ExecuteNonQuery();
                                    }
                                }
                            }
                            
                            transaction.Commit();
                            return true;
                        }
                        catch
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch
            {
                return false;
            }
        }
    }
}