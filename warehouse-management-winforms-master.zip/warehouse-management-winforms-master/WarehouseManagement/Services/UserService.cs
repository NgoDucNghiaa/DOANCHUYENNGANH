using System.Data.SqlClient;
using WarehouseManagement.Data;
using WarehouseManagement.Models;

namespace WarehouseManagement.Services
{
    public class UserService
    {
        public User? Login(string username, string password)
        {
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = "SELECT UserID, Username, FullName, Role FROM Users WHERE Username = @username AND Password = @password";
                
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@password", password); // Không hash nữa
                    
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new User
                            {
                                UserID = (int)reader["UserID"],
                                Username = (string)reader["Username"],
                                FullName = (string)reader["FullName"],
                                Role = (string)reader["Role"]
                            };
                        }
                    }
                }
            }
            return null;
        }

        public bool Register(string username, string password, string fullName, string role = "Staff")
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    string query = "INSERT INTO Users (Username, Password, FullName, Role) VALUES (@username, @password, @fullName, @role)";
                    
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@username", username);
                        command.Parameters.AddWithValue("@password", password); // Không hash nữa
                        command.Parameters.AddWithValue("@fullName", fullName);
                        command.Parameters.AddWithValue("@role", role);
                        
                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public bool IsUsernameExists(string username)
        {
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM Users WHERE Username = @username";
                
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    return (int)command.ExecuteScalar() > 0;
                }
            }
        }

        public List<User> GetAllUsers()
        {
            var users = new List<User>();
            
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = "SELECT UserID, Username, FullName, Role FROM Users ORDER BY Username";
                
                using (var command = new SqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        users.Add(new User
                        {
                            UserID = (int)reader["UserID"],
                            Username = (string)reader["Username"],
                            FullName = (string)reader["FullName"],
                            Role = (string)reader["Role"]
                        });
                    }
                }
            }
            
            return users;
        }

        public bool UpdateUser(User user, bool updatePassword = false)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    string query;
                    
                    if (updatePassword)
                    {
                        query = "UPDATE Users SET FullName = @fullName, Role = @role, Password = @password WHERE UserID = @userID";
                        
                        using (var command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@userID", user.UserID);
                            command.Parameters.AddWithValue("@fullName", user.FullName);
                            command.Parameters.AddWithValue("@role", user.Role);
                            command.Parameters.AddWithValue("@password", user.Password); // Không hash nữa
                            
                            return command.ExecuteNonQuery() > 0;
                        }
                    }
                    else
                    {
                        query = "UPDATE Users SET FullName = @fullName, Role = @role WHERE UserID = @userID";
                        
                        using (var command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@userID", user.UserID);
                            command.Parameters.AddWithValue("@fullName", user.FullName);
                            command.Parameters.AddWithValue("@role", user.Role);
                            
                            return command.ExecuteNonQuery() > 0;
                        }
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteUser(int userId)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    string query = "DELETE FROM Users WHERE UserID = @userID";
                    
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@userID", userId);
                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public User? GetUserById(int userId)
        {
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = "SELECT UserID, Username, FullName, Role FROM Users WHERE UserID = @userID";
                
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@userID", userId);
                    
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new User
                            {
                                UserID = (int)reader["UserID"],
                                Username = (string)reader["Username"],
                                FullName = (string)reader["FullName"],
                                Role = (string)reader["Role"]
                            };
                        }
                    }
                }
            }
            return null;
        }
    }
}