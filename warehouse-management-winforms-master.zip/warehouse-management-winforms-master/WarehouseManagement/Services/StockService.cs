using System.Data.SqlClient;
using WarehouseManagement.Data;
using WarehouseManagement.Models;

namespace WarehouseManagement.Services
{
    public class StockService
    {
        public List<StockIn> GetAllStockIns()
        {
            List<StockIn> stockIns = new List<StockIn>();
            
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = @"SELECT si.StockInID, si.DateImport, si.SupplierID, si.UserID, 
                                si.TotalAmount, ISNULL(si.Notes, '') as Notes,
                                ISNULL(s.SupplierName, '') as SupplierName,
                                ISNULL(u.FullName, '') as UserName
                                FROM StockIns si
                                LEFT JOIN Suppliers s ON si.SupplierID = s.SupplierID
                                LEFT JOIN Users u ON si.UserID = u.UserID
                                ORDER BY si.DateImport DESC";
                
                using (var command = new SqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        stockIns.Add(new StockIn
                        {
                            StockInID = (string)reader["StockInID"],
                            DateImport = (DateTime)reader["DateImport"],
                            SupplierID = (int)reader["SupplierID"],
                            UserID = (int)reader["UserID"],
                            TotalAmount = (decimal)reader["TotalAmount"],
                            Notes = (string)reader["Notes"],
                            SupplierName = (string)reader["SupplierName"],
                            UserName = (string)reader["UserName"]
                        });
                    }
                }
            }
            return stockIns;
        }

        public List<StockOut> GetAllStockOuts()
        {
            List<StockOut> stockOuts = new List<StockOut>();
            
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                string query = @"SELECT so.StockOutID, so.DateExport, so.CustomerID, so.UserID, 
                                so.TotalAmount, ISNULL(so.Notes, '') as Notes,
                                ISNULL(c.CustomerName, '') as CustomerName,
                                ISNULL(u.FullName, '') as UserName
                                FROM StockOuts so
                                LEFT JOIN Customers c ON so.CustomerID = c.CustomerID
                                LEFT JOIN Users u ON so.UserID = u.UserID
                                ORDER BY so.DateExport DESC";
                
                using (var command = new SqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        stockOuts.Add(new StockOut
                        {
                            StockOutID = (string)reader["StockOutID"],
                            DateExport = (DateTime)reader["DateExport"],
                            CustomerID = (int)reader["CustomerID"],
                            UserID = (int)reader["UserID"],
                            TotalAmount = (decimal)reader["TotalAmount"],
                            Notes = (string)reader["Notes"],
                            CustomerName = (string)reader["CustomerName"],
                            UserName = (string)reader["UserName"]
                        });
                    }
                }
            }
            return stockOuts;
        }

        public bool AddStockIn(StockIn stockIn, List<StockInDetail> details)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    using (var transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Thêm phiếu nhập
                            string stockInQuery = @"INSERT INTO StockIns (StockInID, DateImport, SupplierID, UserID, TotalAmount, Notes)
                                                   VALUES (@stockInId, @dateImport, @supplierId, @userId, @totalAmount, @notes)";
                            
                            using (var command = new SqlCommand(stockInQuery, connection, transaction))
                            {
                                command.Parameters.AddWithValue("@stockInId", stockIn.StockInID);
                                command.Parameters.AddWithValue("@dateImport", stockIn.DateImport);
                                command.Parameters.AddWithValue("@supplierId", stockIn.SupplierID);
                                command.Parameters.AddWithValue("@userId", stockIn.UserID);
                                command.Parameters.AddWithValue("@totalAmount", stockIn.TotalAmount);
                                command.Parameters.AddWithValue("@notes", stockIn.Notes ?? "");
                                
                                command.ExecuteNonQuery();
                            }
                            
                            // Thêm chi tiết phiếu nhập và cập nhật tồn kho
                            foreach (var detail in details)
                            {
                                // Thêm chi tiết
                                string detailQuery = @"INSERT INTO StockInDetails (StockInID, ProductID, Quantity, UnitPrice, Amount)
                                                      VALUES (@stockInId, @productId, @quantity, @unitPrice, @amount)";
                                
                                using (var detailCmd = new SqlCommand(detailQuery, connection, transaction))
                                {
                                    detailCmd.Parameters.AddWithValue("@stockInId", stockIn.StockInID);
                                    detailCmd.Parameters.AddWithValue("@productId", detail.ProductID);
                                    detailCmd.Parameters.AddWithValue("@quantity", detail.Quantity);
                                    detailCmd.Parameters.AddWithValue("@unitPrice", detail.UnitPrice);
                                    detailCmd.Parameters.AddWithValue("@amount", detail.Amount);
                                    
                                    detailCmd.ExecuteNonQuery();
                                }
                                
                                // Cập nhật tồn kho
                                string updateInventoryQuery = @"UPDATE Inventories SET Quantity = Quantity + @quantity, LastUpdated = GETDATE()
                                                               WHERE ProductID = @productId";
                                
                                using (var invCmd = new SqlCommand(updateInventoryQuery, connection, transaction))
                                {
                                    invCmd.Parameters.AddWithValue("@productId", detail.ProductID);
                                    invCmd.Parameters.AddWithValue("@quantity", detail.Quantity);
                                    
                                    invCmd.ExecuteNonQuery();
                                }
                            }
                            
                            transaction.Commit();
                            return true;
                        }
                        catch
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public bool AddStockOut(StockOut stockOut, List<StockOutDetail> details)
        {
            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    using (var transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Thêm phiếu xuất
                            string stockOutQuery = @"INSERT INTO StockOuts (StockOutID, DateExport, CustomerID, UserID, TotalAmount, Notes)
                                                    VALUES (@stockOutId, @dateExport, @customerId, @userId, @totalAmount, @notes)";
                            
                            using (var command = new SqlCommand(stockOutQuery, connection, transaction))
                            {
                                command.Parameters.AddWithValue("@stockOutId", stockOut.StockOutID);
                                command.Parameters.AddWithValue("@dateExport", stockOut.DateExport);
                                command.Parameters.AddWithValue("@customerId", stockOut.CustomerID);
                                command.Parameters.AddWithValue("@userId", stockOut.UserID);
                                command.Parameters.AddWithValue("@totalAmount", stockOut.TotalAmount);
                                command.Parameters.AddWithValue("@notes", stockOut.Notes ?? "");
                                
                                command.ExecuteNonQuery();
                            }
                            
                            // Thêm chi tiết phiếu xuất và cập nhật tồn kho
                            foreach (var detail in details)
                            {
                                // Kiểm tra tồn kho
                                string checkStockQuery = "SELECT Quantity FROM Inventories WHERE ProductID = @productId";
                                using (var checkCmd = new SqlCommand(checkStockQuery, connection, transaction))
                                {
                                    checkCmd.Parameters.AddWithValue("@productId", detail.ProductID);
                                    object result = checkCmd.ExecuteScalar();
                                    int currentStock = result != null ? (int)result : 0;
                                    
                                    if (currentStock < detail.Quantity)
                                    {
                                        throw new Exception($"Không đủ tồn kho cho sản phẩm {detail.ProductID}");
                                    }
                                }
                                
                                // Thêm chi tiết
                                string detailQuery = @"INSERT INTO StockOutDetails (StockOutID, ProductID, Quantity, UnitPrice, Amount)
                                                      VALUES (@stockOutId, @productId, @quantity, @unitPrice, @amount)";
                                
                                using (var detailCmd = new SqlCommand(detailQuery, connection, transaction))
                                {
                                    detailCmd.Parameters.AddWithValue("@stockOutId", stockOut.StockOutID);
                                    detailCmd.Parameters.AddWithValue("@productId", detail.ProductID);
                                    detailCmd.Parameters.AddWithValue("@quantity", detail.Quantity);
                                    detailCmd.Parameters.AddWithValue("@unitPrice", detail.UnitPrice);
                                    detailCmd.Parameters.AddWithValue("@amount", detail.Amount);
                                    
                                    detailCmd.ExecuteNonQuery();
                                }
                                
                                // Cập nhật tồn kho
                                string updateInventoryQuery = @"UPDATE Inventories SET Quantity = Quantity - @quantity, LastUpdated = GETDATE()
                                                               WHERE ProductID = @productId";
                                
                                using (var invCmd = new SqlCommand(updateInventoryQuery, connection, transaction))
                                {
                                    invCmd.Parameters.AddWithValue("@productId", detail.ProductID);
                                    invCmd.Parameters.AddWithValue("@quantity", detail.Quantity);
                                    
                                    invCmd.ExecuteNonQuery();
                                }
                            }
                            
                            transaction.Commit();
                            return true;
                        }
                        catch
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public string GenerateStockInId()
        {
            return "SI" + DateTime.Now.ToString("yyyyMMddHHmmss");
        }

        public string GenerateStockOutId()
        {
            return "SO" + DateTime.Now.ToString("yyyyMMddHHmmss");
        }
    }
}