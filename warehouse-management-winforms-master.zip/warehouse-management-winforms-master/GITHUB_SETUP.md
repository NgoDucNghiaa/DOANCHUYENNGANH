# 🚀 Hướng dẫn đẩy project lên GitHub

## 📋 Bước 1: Cài đặt Git

### Tải Git for Windows:
1. Truy cập: **https://git-scm.com/download/win**
2. Click **"Download for Windows"**
3. Chạy file `.exe` đã tải
4. Cài đặt với các tùy chọn mặc định
5. **Restart Command Prompt/PowerShell**

## 📋 Bước 2: Tạo GitHub repository

### Trên GitHub.com:
1. Đăng nhập **GitHub.com**
2. Click **"New repository"** (nút xanh)
3. **Repository name:** `warehouse-management-winforms`
4. **Description:** `Hệ thống quản lý kho hàng C# WinForms`
5. Chọn **Public** (hoặc Private nếu muốn)
6. ✅ **Add a README file** (bỏ tick - chúng ta đã có)
7. ✅ **Add .gitignore** → chọn **VisualStudio**
8. ✅ **Choose a license** → chọn **MIT License**
9. Click **"Create repository"**

## 📋 Bước 3: Khởi tạo Git local

Mở **Command Prompt** hoặc **PowerShell** trong thư mục project:

```bash
# Khởi tạo git repository
git init

# Cấu hình thông tin (lần đầu tiên)
git config --global user.name "Tên của bạn"
git config --global user.email "email@example.com"

# Thêm tất cả files
git add .

# Commit đầu tiên
git commit -m "Initial commit: Warehouse Management System"

# Kết nối với GitHub repository
git remote add origin https://github.com/USERNAME/warehouse-management-winforms.git

# Đẩy code lên GitHub
git push -u origin main
```

## 📋 Bước 4: Cập nhật thông tin trong README

Sửa file `README.md`:
- Thay `yourusername` bằng username GitHub của bạn
- Thay `Your Name` và `your.email@example.com` bằng thông tin thật

## 📋 Bước 5: Các lệnh Git hữu ích

```bash
# Kiểm tra trạng thái
git status

# Thêm files mới/thay đổi
git add .
git commit -m "Mô tả thay đổi"
git push

# Tạo branch mới
git checkout -b feature/new-feature

# Merge branch
git checkout main
git merge feature/new-feature

# Pull updates từ GitHub
git pull origin main
```

## 🎯 Kết quả mong đợi:

Sau khi hoàn thành:
- ✅ Code được lưu trên GitHub
- ✅ README đẹp với badges và screenshots
- ✅ .gitignore loại bỏ files không cần thiết
- ✅ MIT License cho open source
- ✅ Có thể clone và chạy trên máy khác

## 🔧 Xử lý sự cố:

### Lỗi "git not found":
- Cài lại Git và restart terminal
- Kiểm tra PATH environment variable

### Lỗi authentication:
- Sử dụng **Personal Access Token** thay vì password
- Hoặc setup **SSH keys**

### Lỗi "repository not found":
- Kiểm tra URL repository đúng chưa
- Kiểm tra quyền truy cập repository

**Chúc bạn thành công! 🎉**